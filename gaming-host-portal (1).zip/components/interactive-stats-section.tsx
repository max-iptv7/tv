"use client"

import { useEffect, useState, useRef } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Server, Users, Globe, Zap, TrendingUp, Shield, Clock, Star } from "lucide-react"

export function InteractiveStatsSection() {
  const [isVisible, setIsVisible] = useState(false)
  const [counters, setCounters] = useState({
    servers: 0,
    users: 0,
    uptime: 0,
    countries: 0,
  })
  const sectionRef = useRef<HTMLDivElement>(null)

  const finalStats = {
    servers: 50247,
    users: 125000,
    uptime: 99.99,
    countries: 25,
  }

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.3 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    if (!isVisible) return

    const duration = 2000
    const steps = 60
    const stepDuration = duration / steps

    let currentStep = 0
    const timer = setInterval(() => {
      currentStep++
      const progress = currentStep / steps

      setCounters({
        servers: Math.floor(finalStats.servers * progress),
        users: Math.floor(finalStats.users * progress),
        uptime: Math.min(finalStats.uptime, finalStats.uptime * progress),
        countries: Math.floor(finalStats.countries * progress),
      })

      if (currentStep >= steps) {
        clearInterval(timer)
        setCounters(finalStats)
      }
    }, stepDuration)

    return () => clearInterval(timer)
  }, [isVisible])

  const stats = [
    {
      icon: <Server className="w-8 h-8" />,
      value: counters.servers.toLocaleString(),
      label: "Active Servers",
      gradient: "from-blue-500 to-cyan-500",
      description: "Servers running worldwide",
    },
    {
      icon: <Users className="w-8 h-8" />,
      value: counters.users.toLocaleString() + "+",
      label: "Happy Customers",
      gradient: "from-purple-500 to-pink-500",
      description: "Satisfied gaming communities",
    },
    {
      icon: <TrendingUp className="w-8 h-8" />,
      value: counters.uptime.toFixed(2) + "%",
      label: "Uptime SLA",
      gradient: "from-green-500 to-emerald-500",
      description: "Guaranteed availability",
    },
    {
      icon: <Globe className="w-8 h-8" />,
      value: counters.countries.toString(),
      label: "Global Locations",
      gradient: "from-orange-500 to-red-500",
      description: "Data centers worldwide",
    },
  ]

  const features = [
    {
      icon: <Zap className="w-6 h-6 text-yellow-400" />,
      title: "Lightning Fast",
      description: "NVMe SSD storage with up to 7GB/s speeds",
    },
    {
      icon: <Shield className="w-6 h-6 text-red-400" />,
      title: "DDoS Protected",
      description: "17Tbps protection capacity",
    },
    {
      icon: <Clock className="w-6 h-6 text-blue-400" />,
      title: "Instant Setup",
      description: "Servers deployed in under 60 seconds",
    },
    {
      icon: <Star className="w-6 h-6 text-purple-400" />,
      title: "5-Star Support",
      description: "24/7 expert gaming specialists",
    },
  ]

  return (
    <section ref={sectionRef} className="py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_40%,rgba(59,130,246,0.1),transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_60%,rgba(147,51,234,0.1),transparent_50%)]" />

      <div className="container mx-auto px-4 relative z-10">
        {/* Header */}
        <div className="text-center mb-20">
          <div className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-full border border-blue-500/30 backdrop-blur-sm mb-8">
            <TrendingUp className="w-5 h-5 text-green-400 mr-2" />
            <span className="text-blue-300 font-semibold">Real-Time Statistics</span>
          </div>

          <h2 className="text-4xl lg:text-6xl font-black mb-6">
            <span className="text-white">Trusted by</span>
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500">
              Gaming Communities
            </span>
          </h2>
          <div className="w-32 h-1 bg-gradient-to-r from-blue-500 to-purple-500 mx-auto mb-8 rounded-full" />
          <p className="text-xl text-slate-300 max-w-4xl mx-auto leading-relaxed">
            Join thousands of gaming communities worldwide who trust Avox Hosting for their server infrastructure needs.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {stats.map((stat, index) => (
            <Card
              key={index}
              className={`group relative bg-gradient-to-br from-slate-900/80 to-slate-800/80 backdrop-blur-xl border border-slate-700/50 hover:border-slate-600/50 transition-all duration-700 transform-gpu hover:scale-105 ${
                isVisible ? "animate-fade-in-up" : "opacity-0"
              }`}
              style={{ animationDelay: `${index * 200}ms` }}
            >
              {/* Glow Effect */}
              <div
                className={`absolute inset-0 bg-gradient-to-r ${stat.gradient} opacity-0 group-hover:opacity-10 rounded-lg blur-xl transition-opacity duration-500`}
              />

              <CardContent className="p-8 text-center relative">
                <div
                  className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${stat.gradient} flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-all duration-500 shadow-lg`}
                >
                  {stat.icon}
                </div>

                <div
                  className={`text-4xl lg:text-5xl font-black mb-2 text-transparent bg-clip-text bg-gradient-to-r ${stat.gradient}`}
                >
                  {stat.value}
                </div>

                <h3 className="text-white font-bold text-lg mb-2">{stat.label}</h3>
                <p className="text-slate-400 text-sm">{stat.description}</p>
              </CardContent>

              {/* Floating Particles */}
              <div className="absolute inset-0 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                {[...Array(6)].map((_, i) => (
                  <div
                    key={i}
                    className="absolute w-1 h-1 bg-blue-400 rounded-full animate-ping"
                    style={{
                      left: `${Math.random() * 100}%`,
                      top: `${Math.random() * 100}%`,
                      animationDelay: `${Math.random() * 2}s`,
                    }}
                  />
                ))}
              </div>
            </Card>
          ))}
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <div
              key={index}
              className={`group bg-slate-800/30 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/30 hover:border-slate-600/50 transition-all duration-500 transform hover:scale-105 ${
                isVisible ? "animate-fade-in-up" : "opacity-0"
              }`}
              style={{ animationDelay: `${(index + 4) * 200}ms` }}
            >
              <div className="flex items-center space-x-4 mb-4">
                <div className="group-hover:scale-110 transition-transform duration-300">{feature.icon}</div>
                <h3 className="text-white font-bold">{feature.title}</h3>
              </div>
              <p className="text-slate-400 text-sm">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>

      <style jsx>{`
        @keyframes fade-in-up {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-fade-in-up {
          animation: fade-in-up 0.8s ease-out forwards;
        }
      `}</style>
    </section>
  )
}
