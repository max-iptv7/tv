"use client"

import { useEffect, useState } from "react"
import { Zap, Server, Globe, Shield } from "lucide-react"

interface EnhancedLoadingScreenProps {
  onLoadingComplete: () => void
}

export function EnhancedLoadingScreen({ onLoadingComplete }: EnhancedLoadingScreenProps) {
  const [progress, setProgress] = useState(0)
  const [currentStep, setCurrentStep] = useState(0)

  const loadingSteps = [
    { icon: <Server className="w-8 h-8" />, text: "Initializing Servers", color: "text-blue-400" },
    { icon: <Globe className="w-8 h-8" />, text: "Connecting Networks", color: "text-green-400" },
    { icon: <Shield className="w-8 h-8" />, text: "Activating Security", color: "text-red-400" },
    { icon: <Zap className="w-8 h-8" />, text: "Optimizing Performance", color: "text-yellow-400" },
  ]

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        const newProgress = prev + 1

        // Update current step based on progress
        const stepIndex = Math.floor((newProgress / 100) * loadingSteps.length)
        setCurrentStep(Math.min(stepIndex, loadingSteps.length - 1))

        if (newProgress >= 100) {
          clearInterval(timer)
          setTimeout(onLoadingComplete, 800)
          return 100
        }
        return newProgress
      })
    }, 30)

    return () => clearInterval(timer)
  }, [onLoadingComplete, loadingSteps.length])

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center z-50 overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_50%,rgba(59,130,246,0.15),transparent_70%)] animate-pulse" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(147,51,234,0.15),transparent_70%)] animate-pulse" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_40%_80%,rgba(236,72,153,0.15),transparent_70%)] animate-pulse" />
      </div>

      {/* Floating Particles */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(30)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-blue-400 rounded-full animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${2 + Math.random() * 2}s`,
            }}
          />
        ))}
      </div>

      <div className="text-center relative z-10">
        {/* 3D Logo */}
        <div className="relative mb-12">
          <div
            className="w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-600 rounded-3xl flex items-center justify-center mx-auto shadow-2xl transform-gpu"
            style={{
              transform: `perspective(1000px) rotateX(${Math.sin(progress * 0.1) * 10}deg) rotateY(${Math.cos(progress * 0.1) * 10}deg)`,
              animation: "float 3s ease-in-out infinite",
            }}
          >
            <span className="text-white font-black text-3xl">AH</span>
          </div>
          <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-3xl blur-3xl animate-pulse" />
        </div>

        {/* Brand Name */}
        <h1 className="text-4xl font-black mb-2">
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 animate-gradient">
            Avox Hosting
          </span>
        </h1>
        <p className="text-slate-400 text-lg mb-12">Next-Generation Gaming Infrastructure</p>

        {/* Loading Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div
              className={`${loadingSteps[currentStep]?.color || "text-blue-400"} transform transition-all duration-500`}
            >
              {loadingSteps[currentStep]?.icon}
            </div>
            <span className="text-white font-semibold text-lg">{loadingSteps[currentStep]?.text || "Loading..."}</span>
          </div>
        </div>

        {/* Enhanced Progress Bar */}
        <div className="w-80 mx-auto mb-6">
          <div className="relative">
            <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden shadow-inner">
              <div
                className="h-full bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 transition-all duration-300 ease-out relative"
                style={{ width: `${progress}%` }}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-pulse" />
              </div>
            </div>
            <div
              className="absolute -top-1 -bottom-1 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full blur-sm opacity-50"
              style={{ width: `${progress}%`, transition: "width 0.3s ease-out" }}
            />
          </div>
        </div>

        {/* Progress Percentage */}
        <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500 mb-4">
          {progress}%
        </div>

        {/* Loading Dots */}
        <div className="flex justify-center space-x-2">
          {[...Array(3)].map((_, i) => (
            <div
              key={i}
              className="w-2 h-2 bg-blue-400 rounded-full animate-bounce"
              style={{ animationDelay: `${i * 0.2}s` }}
            />
          ))}
        </div>
      </div>

      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) perspective(1000px) rotateX(0deg) rotateY(0deg); }
          50% { transform: translateY(-10px) perspective(1000px) rotateX(5deg) rotateY(5deg); }
        }
        @keyframes gradient {
          0%, 100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }
        .animate-gradient {
          background-size: 200% 200%;
          animation: gradient 3s ease infinite;
        }
      `}</style>
    </div>
  )
}
