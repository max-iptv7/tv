"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Cpu,
  HardDrive,
  Zap,
  Globe,
  ArrowRight,
  Play,
  Star,
  Shield,
  Clock,
  Users,
  Rocket,
  Crown,
  Sparkles,
} from "lucide-react"
import { useEffect, useRef, useState } from "react"
import Link from "next/link"

export function PremiumHeroSection() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const [isVisible, setIsVisible] = useState(false)
  const heroRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    setIsVisible(true)

    const handleMouseMove = (e: MouseEvent) => {
      if (heroRef.current) {
        const rect = heroRef.current.getBoundingClientRect()
        setMousePosition({
          x: (e.clientX - rect.left) / rect.width,
          y: (e.clientY - rect.top) / rect.height,
        })
      }
    }

    const heroElement = heroRef.current
    if (heroElement) {
      heroElement.addEventListener("mousemove", handleMouseMove)
    }

    return () => {
      if (heroElement) {
        heroElement.removeEventListener("mousemove", handleMouseMove)
      }
    }
  }, [])

  return (
    <section
      ref={heroRef}
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20 px-4 sm:px-6 lg:px-8"
      style={{
        background: `
          radial-gradient(circle at ${mousePosition.x * 100}% ${mousePosition.y * 100}%, 
          rgba(59, 130, 246, 0.15) 0%, 
          rgba(147, 51, 234, 0.1) 25%, 
          rgba(236, 72, 153, 0.08) 50%,
          transparent 70%),
          linear-gradient(135deg, #0f172a 0%, #1e293b 30%, #0f172a 70%, #1e293b 100%)
        `,
      }}
    >
      {/* Premium Background Effects */}
      <div className="absolute inset-0">
        {/* Animated Grid */}
        <div
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: `
              linear-gradient(rgba(59, 130, 246, 0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(59, 130, 246, 0.1) 1px, transparent 1px)
            `,
            backgroundSize: "60px 60px",
            transform: `translate(${mousePosition.x * 30}px, ${mousePosition.y * 30}px)`,
            transition: "transform 0.3s ease-out",
          }}
        />

        {/* Premium Floating Elements */}
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full opacity-40"
            style={{
              width: `${8 + Math.random() * 16}px`,
              height: `${8 + Math.random() * 16}px`,
              background: `radial-gradient(circle, 
                ${["#3b82f6", "#8b5cf6", "#ec4899", "#10b981", "#f59e0b"][Math.floor(Math.random() * 5)]}, 
                transparent)`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `float ${6 + Math.random() * 8}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 4}s`,
              boxShadow: `0 0 30px ${["#3b82f6", "#8b5cf6", "#ec4899", "#10b981", "#f59e0b"][Math.floor(Math.random() * 5)]}40`,
            }}
          />
        ))}
      </div>

      <div className="container mx-auto relative z-10">
        {/* Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-orange-500/10 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-red-500/10 rounded-full blur-3xl" />
        </div>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          <div
            className={`space-y-8 text-center lg:text-left transition-all duration-1000 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
          >
            {/* Premium Trust Badges */}
            <div className="flex flex-wrap justify-center lg:justify-start gap-3">
              <Badge variant="secondary" className="bg-slate-800/50 text-orange-400 border-orange-500/20 px-4 py-2">
                <Shield className="w-4 h-4 mr-2" />
                DDoS Protected
              </Badge>
              <Badge variant="secondary" className="bg-slate-800/50 text-red-400 border-red-500/20 px-4 py-2">
                <Zap className="w-4 h-4 mr-2" />
                Instant Setup
              </Badge>
              <Badge variant="secondary" className="bg-slate-800/50 text-orange-400 border-orange-500/20 px-4 py-2">
                <Globe className="w-4 h-4 mr-2" />
                Global Network
              </Badge>
            </div>

            {/* Premium Title */}
            <div className="space-y-4">
              <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl xl:text-8xl font-black leading-tight">
                <span className="block text-white mb-2">Premium</span>
                <span className="block bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent mb-2 animate-gradient">
                  Gaming Cloud
                </span>
                <span className="block bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 bg-clip-text text-transparent animate-gradient">
                  Infrastructure
                </span>
              </h1>

              <p className="text-lg sm:text-xl md:text-2xl text-slate-300 leading-relaxed max-w-2xl mx-auto lg:mx-0">
                Experience next-generation gaming infrastructure with{" "}
                <span className="bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent font-bold">
                  Avox Hosting
                </span>
                . Enterprise-grade performance, instant deployment, and 24/7 expert support for the ultimate gaming
                experience.
              </p>
            </div>

            {/* Premium Features */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 py-6">
              {[
                {
                  icon: <Shield className="w-5 h-5" />,
                  text: "99.99% Uptime",
                  color: "text-emerald-400",
                  bg: "bg-emerald-500/10",
                },
                {
                  icon: <Zap className="w-5 h-5" />,
                  text: "Instant Setup",
                  color: "text-blue-400",
                  bg: "bg-blue-500/10",
                },
                {
                  icon: <Clock className="w-5 h-5" />,
                  text: "24/7 Support",
                  color: "text-purple-400",
                  bg: "bg-purple-500/10",
                },
              ].map((feature, index) => (
                <div
                  key={index}
                  className={`flex items-center justify-center lg:justify-start space-x-3 ${feature.bg} border border-slate-700/30 px-4 py-3 rounded-xl backdrop-blur-sm hover:scale-105 transition-all duration-300`}
                >
                  <div className={feature.color}>{feature.icon}</div>
                  <span className="text-slate-300 font-semibold">{feature.text}</span>
                </div>
              ))}
            </div>

            {/* Premium CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button
                size="lg"
                className="group bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 hover:from-blue-700 hover:via-purple-700 hover:to-pink-700 text-white text-lg px-8 py-4 rounded-xl shadow-2xl hover:shadow-blue-500/25 transition-all duration-300 transform hover:scale-105"
                asChild
              >
                <Link href="https://billing.avoxhosting.com/cart.php">
                  <Rocket className="mr-3 w-5 h-5" />
                  <span>Start Gaming Now</span>
                  <ArrowRight className="ml-3 w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="group border-2 border-slate-600 text-slate-300 hover:text-white hover:bg-slate-800/50 text-lg px-8 py-4 rounded-xl backdrop-blur-sm hover:border-blue-500/50 transition-all duration-300 bg-transparent"
                asChild
              >
                <Link href="#demo">
                  <Play className="mr-3 w-5 h-5" />
                  <span>Watch Demo</span>
                </Link>
              </Button>
            </div>

            {/* Premium Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-8 border-t border-slate-800/50">
              {[
                {
                  value: "99.99%",
                  label: "Uptime SLA",
                  color: "from-emerald-400 to-green-500",
                  icon: <Shield className="w-4 h-4" />,
                },
                {
                  value: "100K+",
                  label: "Active Servers",
                  color: "from-blue-400 to-cyan-500",
                  icon: <Users className="w-4 h-4" />,
                },
                {
                  value: "<30s",
                  label: "Setup Time",
                  color: "from-purple-400 to-pink-500",
                  icon: <Zap className="w-4 h-4" />,
                },
              ].map((stat, index) => (
                <div key={index} className="text-center group">
                  <div className="flex items-center justify-center space-x-2 mb-2">
                    <div className={`bg-gradient-to-r ${stat.color} bg-clip-text text-transparent`}>{stat.icon}</div>
                    <div
                      className={`text-3xl sm:text-4xl font-black bg-gradient-to-r ${stat.color} bg-clip-text text-transparent`}
                    >
                      {stat.value}
                    </div>
                  </div>
                  <div className="text-sm text-slate-400 group-hover:text-slate-300 transition-colors">
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Premium Server Visualization */}
          <div
            className={`relative transition-all duration-1000 delay-300 ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-10"}`}
          >
            <div className="relative w-full max-w-lg mx-auto">
              {/* Premium Server Card */}
              <div
                className="relative bg-gradient-to-br from-slate-900/90 to-slate-800/90 backdrop-blur-xl rounded-2xl p-8 border border-slate-700/50 shadow-2xl"
                style={{
                  transform: `
                    perspective(1000px) 
                    rotateX(${mousePosition.y * 8 - 4}deg) 
                    rotateY(${mousePosition.x * 8 - 4}deg)
                  `,
                  transition: "transform 0.3s ease-out",
                }}
              >
                {/* Premium Header */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-3">
                    <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
                      <Crown className="w-7 h-7 text-white" />
                    </div>
                    <div>
                      <h3 className="font-bold text-white text-lg">Premium Gaming</h3>
                      <p className="text-slate-400">Enterprise Infrastructure</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-emerald-400 rounded-full animate-pulse" />
                    <span className="text-emerald-400 font-medium">Online</span>
                  </div>
                </div>

                {/* Premium Specs */}
                <div className="grid grid-cols-2 gap-4 mb-6">
                  {[
                    {
                      icon: <Cpu className="w-5 h-5 text-blue-400" />,
                      label: "AMD Ryzen™ 9",
                      value: "7950X3D Gaming",
                      gradient: "from-blue-500 to-cyan-500",
                    },
                    {
                      icon: <HardDrive className="w-5 h-5 text-purple-400" />,
                      label: "NVMe SSD",
                      value: "Up to 8TB",
                      gradient: "from-purple-500 to-pink-500",
                    },
                    {
                      icon: <Zap className="w-5 h-5 text-emerald-400" />,
                      label: "DDR5 RAM",
                      value: "Up to 128GB",
                      gradient: "from-emerald-500 to-green-500",
                    },
                    {
                      icon: <Globe className="w-5 h-5 text-amber-400" />,
                      label: "Network",
                      value: "10 Gbps",
                      gradient: "from-amber-500 to-orange-500",
                    },
                  ].map((spec, index) => (
                    <div
                      key={index}
                      className={`bg-gradient-to-br ${spec.gradient}/10 border border-slate-700/30 rounded-xl p-4 hover:scale-105 transition-all duration-300`}
                    >
                      <div className="flex items-center space-x-2 mb-2">
                        {spec.icon}
                        <span className="text-xs text-slate-400">{spec.label}</span>
                      </div>
                      <div className="text-sm font-bold text-white">{spec.value}</div>
                    </div>
                  ))}
                </div>

                {/* Premium Performance Metrics */}
                <div className="space-y-4">
                  {[
                    { label: "CPU Performance", value: 98, color: "from-blue-500 to-purple-500" },
                    { label: "Memory Usage", value: 67, color: "from-emerald-500 to-green-500" },
                    { label: "Network Speed", value: 95, color: "from-amber-500 to-orange-500" },
                  ].map((metric, index) => (
                    <div key={index}>
                      <div className="flex justify-between text-sm mb-2">
                        <span className="text-slate-400">{metric.label}</span>
                        <span className="text-white font-semibold">{metric.value}%</span>
                      </div>
                      <div className="w-full bg-slate-700/50 rounded-full h-2">
                        <div
                          className={`bg-gradient-to-r ${metric.color} h-2 rounded-full transition-all duration-1000 relative overflow-hidden`}
                          style={{ width: `${metric.value}%` }}
                        >
                          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-pulse" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Premium Floating Elements */}
              <div className="absolute -top-4 -right-4 w-8 h-8 bg-gradient-to-br from-pink-500 to-red-500 rounded-xl animate-bounce flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <div className="absolute -bottom-3 -left-3 w-6 h-6 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-xl animate-pulse flex items-center justify-center">
                <Star className="w-3 h-3 text-white fill-current" />
              </div>

              {/* Premium Glow Effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 via-purple-600/20 to-pink-600/20 rounded-2xl blur-3xl -z-10 animate-pulse" />
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes float {
          0%, 100% {
            transform: translateY(0px) rotate(0deg);
          }
          50% {
            transform: translateY(-30px) rotate(180deg);
          }
        }
        @keyframes gradient {
          0%, 100% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
        }
        .animate-gradient {
          background-size: 200% 200%;
          animation: gradient 4s ease infinite;
        }
      `}</style>
    </section>
  )
}
