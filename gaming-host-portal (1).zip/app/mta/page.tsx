import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, Gamepad2, Users, Zap, Code, Database } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import Link from "next/link"

export default function MTAPage() {
  const plans = [
    {
      name: "MTA Starter",
      players: "32 Players",
      ram: "1 GB",
      cpu: "1 vCPU",
      storage: "10 GB SSD",
      price: "€6.99",
      popular: false,
      productId: "61",
      features: [
        "Lua Scripting",
        "Resource Manager",
        "DDoS Protection",
        "24/7 Support",
        "Control Panel",
        "Auto Restart",
      ],
    },
    {
      name: "MTA Basic",
      players: "64 Players",
      ram: "2 GB",
      cpu: "2 vCPU",
      storage: "20 GB SSD",
      price: "€11.99",
      popular: false,
      productId: "62",
      features: [
        "Lua Scripting",
        "Resource Manager",
        "DDoS Protection",
        "24/7 Support",
        "Control Panel",
        "Auto Restart",
        "MySQL Database",
      ],
    },
    {
      name: "MTA Standard",
      players: "128 Players",
      ram: "4 GB",
      cpu: "3 vCPU",
      storage: "40 GB SSD",
      price: "€18.99",
      popular: true,
      productId: "63",
      features: [
        "Lua Scripting",
        "Resource Manager",
        "DDoS Protection",
        "24/7 Support",
        "Control Panel",
        "Auto Restart",
        "MySQL Database",
        "Custom Resources",
      ],
    },
    {
      name: "MTA Advanced",
      players: "200 Players",
      ram: "6 GB",
      cpu: "4 vCPU",
      storage: "60 GB SSD",
      price: "€28.99",
      popular: false,
      productId: "64",
      features: [
        "Lua Scripting",
        "Resource Manager",
        "DDoS Protection",
        "24/7 Support",
        "Control Panel",
        "Auto Restart",
        "MySQL Database",
        "Custom Resources",
        "Priority Support",
      ],
    },
    {
      name: "MTA Professional",
      players: "300 Players",
      ram: "8 GB",
      cpu: "5 vCPU",
      storage: "80 GB SSD",
      price: "€39.99",
      popular: false,
      productId: "65",
      features: [
        "Lua Scripting",
        "Resource Manager",
        "DDoS Protection",
        "24/7 Support",
        "Control Panel",
        "Auto Restart",
        "MySQL Database",
        "Custom Resources",
        "Priority Support",
        "Dedicated IP",
      ],
    },
    {
      name: "MTA Enterprise",
      players: "500 Players",
      ram: "12 GB",
      cpu: "6 vCPU",
      storage: "120 GB SSD",
      price: "€54.99",
      popular: false,
      productId: "66",
      features: [
        "Lua Scripting",
        "Resource Manager",
        "DDoS Protection",
        "24/7 Support",
        "Control Panel",
        "Auto Restart",
        "MySQL Database",
        "Custom Resources",
        "Priority Support",
        "Dedicated IP",
        "Custom Setup",
      ],
    },
  ]

  const features = [
    {
      icon: <Code className="w-6 h-6 sm:w-8 sm:h-8 text-green-400" />,
      title: "Lua Scripting",
      description: "Full Lua scripting support for creating custom game modes, maps, and interactive experiences.",
    },
    {
      icon: <Database className="w-6 h-6 sm:w-8 sm:h-8 text-blue-400" />,
      title: "Resource Manager",
      description: "Advanced resource management system for easy installation and management of custom content.",
    },
    {
      icon: <Users className="w-6 h-6 sm:w-8 sm:h-8 text-purple-400" />,
      title: "High Capacity",
      description: "Support for up to 500 concurrent players with stable performance and low latency.",
    },
    {
      icon: <Zap className="w-6 h-6 sm:w-8 sm:h-8 text-yellow-400" />,
      title: "Instant Setup",
      description: "Get your MTA server running within minutes with our automated deployment and configuration.",
    },
  ]

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <Header />

      <main className="pt-16">
        {/* Hero Section */}
        <section className="py-12 sm:py-20 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12 sm:mb-16">
              <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-green-500 to-emerald-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Gamepad2 className="w-8 h-8 sm:w-10 sm:h-10 text-white" />
              </div>
              <h1 className="text-3xl sm:text-4xl lg:text-6xl font-bold mb-6">
                MTA <span className="text-green-400">Server Hosting</span>
              </h1>
              <p className="text-base sm:text-xl text-slate-300 max-w-4xl mx-auto leading-relaxed px-4">
                Premium Multi Theft Auto server hosting with advanced Lua scripting capabilities and resource
                management. Perfect for roleplay servers, racing communities, and custom game modes. Get your MTA server
                online with high performance, MySQL database support, and comprehensive resource management tools.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 max-w-6xl mx-auto">
              {features.map((feature, index) => (
                <Card
                  key={index}
                  className="bg-slate-900/50 border-slate-800 hover:border-green-500/50 transition-all duration-300"
                >
                  <CardHeader className="text-center p-4 sm:p-6">
                    <div className="mb-3 sm:mb-4">{feature.icon}</div>
                    <CardTitle className="text-white text-base sm:text-lg">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="p-4 sm:p-6 pt-0">
                    <p className="text-slate-300 text-sm text-center">{feature.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Pricing Section */}
        <section className="py-12 sm:py-20">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12 sm:mb-16">
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold mb-4">MTA Hosting Plans</h2>
              <div className="w-24 h-1 bg-green-500 mx-auto mb-6"></div>
              <p className="text-base sm:text-xl text-slate-300 max-w-3xl mx-auto px-4">
                Choose the perfect MTA hosting plan for your server. All plans include Lua scripting, resource manager,
                and 24/7 support.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
              {plans.map((plan, index) => (
                <Card
                  key={index}
                  className={`relative bg-slate-900/50 border-slate-800 hover:border-slate-700 transition-all duration-300 ${
                    plan.popular ? "ring-2 ring-green-500 scale-105" : ""
                  }`}
                >
                  {plan.popular && (
                    <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-green-600 text-white text-xs sm:text-sm">
                      Most Popular
                    </Badge>
                  )}

                  <CardHeader className="text-center p-4 sm:p-6">
                    <CardTitle className="text-white text-lg sm:text-xl">{plan.name}</CardTitle>
                    <div className="text-2xl sm:text-3xl font-bold text-white mt-4">
                      {plan.price}
                      <span className="text-slate-400 text-base sm:text-lg font-normal">/month</span>
                    </div>
                    <p className="text-green-400 font-semibold text-sm sm:text-base">{plan.players}</p>
                  </CardHeader>

                  <CardContent className="space-y-4 p-4 sm:p-6">
                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div>
                        <p className="text-slate-400 text-xs">RAM</p>
                        <p className="text-white font-semibold text-xs sm:text-sm">{plan.ram}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-xs">CPU</p>
                        <p className="text-white font-semibold text-xs sm:text-sm">{plan.cpu}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-xs">Storage</p>
                        <p className="text-white font-semibold text-xs sm:text-sm">{plan.storage}</p>
                      </div>
                    </div>

                    <div className="space-y-2 pt-4">
                      {plan.features.map((feature, featureIndex) => (
                        <div key={featureIndex} className="flex items-center space-x-2">
                          <Check className="w-3 h-3 sm:w-4 sm:h-4 text-green-400 flex-shrink-0" />
                          <span className="text-slate-300 text-xs sm:text-sm">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>

                  <CardFooter className="p-4 sm:p-6">
                    <Button className="w-full bg-green-600 hover:bg-green-700 py-3 text-sm sm:text-base" asChild>
                      <Link href={`https://billing.avoxhosting.com/cart.php?a=add&pid=${plan.productId}`}>
                        Order Now
                      </Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
