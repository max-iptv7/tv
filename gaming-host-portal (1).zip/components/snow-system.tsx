"use client"

import { useEffect, useRef } from "react"

interface Snowflake {
  x: number
  y: number
  size: number
  speed: number
  opacity: number
  drift: number
}

export function SnowSystem() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const snowflakesRef = useRef<Snowflake[]>([])
  const animationRef = useRef<number>()

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const resizeCanvas = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    resizeCanvas()
    window.addEventListener("resize", resizeCanvas)

    // Create snowflakes
    const createSnowflake = (): Snowflake => ({
      x: Math.random() * canvas.width,
      y: -10,
      size: Math.random() * 3 + 1,
      speed: Math.random() * 2 + 0.5,
      opacity: Math.random() * 0.6 + 0.2,
      drift: Math.random() * 0.5 - 0.25,
    })

    // Initialize snowflakes
    for (let i = 0; i < 100; i++) {
      snowflakesRef.current.push({
        ...createSnowflake(),
        y: Math.random() * canvas.height,
      })
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      snowflakesRef.current.forEach((snowflake, index) => {
        // Update position
        snowflake.y += snowflake.speed
        snowflake.x += snowflake.drift

        // Reset if off screen
        if (snowflake.y > canvas.height) {
          snowflakesRef.current[index] = createSnowflake()
        }

        if (snowflake.x > canvas.width) {
          snowflake.x = 0
        } else if (snowflake.x < 0) {
          snowflake.x = canvas.width
        }

        // Draw snowflake
        ctx.save()
        ctx.globalAlpha = snowflake.opacity
        ctx.fillStyle = "#ffffff"
        ctx.shadowBlur = 10
        ctx.shadowColor = "#ffffff"
        ctx.beginPath()
        ctx.arc(snowflake.x, snowflake.y, snowflake.size, 0, Math.PI * 2)
        ctx.fill()
        ctx.restore()
      })

      animationRef.current = requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener("resize", resizeCanvas)
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [])

  return (
    <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none z-10" style={{ mixBlendMode: "screen" }} />
  )
}
