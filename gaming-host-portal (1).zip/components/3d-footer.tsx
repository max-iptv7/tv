"use client"

import Link from "next/link"
import { useState } from "react"
import { Zap, Mail, Phone, MapPin } from "lucide-react"

export function Footer3D() {
  const [hoveredSection, setHoveredSection] = useState<string | null>(null)

  return (
    <footer className="relative bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 border-t border-slate-800/50 overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_80%,rgba(59,130,246,0.08),transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(147,51,234,0.08),transparent_50%)]" />

      <div className="container mx-auto px-4 py-16 relative z-10">
        {/* Top Section */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Brand Section */}
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <span className="font-black text-xl text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">
                Avox Hosting
              </span>
            </div>
            <p className="text-slate-300 leading-relaxed mb-6 text-sm">
              The future of gaming hosting. Premium infrastructure, cutting-edge technology, and unparalleled
              performance for the ultimate gaming experience.
            </p>

            {/* Contact Info */}
            <div className="space-y-3 text-sm">
              <div className="flex items-center space-x-3 text-slate-400">
                <Mail className="w-4 h-4" />
                <span>support@avoxhosting.com</span>
              </div>
              <div className="flex items-center space-x-3 text-slate-400">
                <Phone className="w-4 h-4" />
                <span>+1 (555) 123-4567</span>
              </div>
              <div className="flex items-center space-x-3 text-slate-400">
                <MapPin className="w-4 h-4" />
                <span>Global Infrastructure</span>
              </div>
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-white font-bold mb-4 text-sm uppercase tracking-wide">Gaming Services</h3>
            <ul className="space-y-2 text-sm">
              {[
                { name: "SA-MP Servers", href: "/samp" },
                { name: "MTA Servers", href: "/mta" },
                { name: "Minecraft Hosting", href: "/minecraft" },
                { name: "FiveM Servers", href: "/fivem" },
                { name: "Discord Bots", href: "/discord-bots" },
                { name: "VPS Hosting", href: "/vps" },
                { name: "RDP Servers", href: "/rdp" },
              ].map((service, index) => (
                <li key={index}>
                  <Link href={service.href} className="text-slate-400 hover:text-blue-400 transition-colors">
                    {service.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="text-white font-bold mb-4 text-sm uppercase tracking-wide">Support & Help</h3>
            <ul className="space-y-2 text-sm">
              {[
                { name: "24/7 Live Support", href: "https://billing.avoxhosting.com/submitticket.php" },
                { name: "Knowledge Base", href: "https://billing.avoxhosting.com/knowledgebase" },
                { name: "Server Status", href: "https://status.avoxhosting.com" },
                { name: "Contact Support", href: "https://billing.avoxhosting.com/contact.php" },
                { name: "Discord Community", href: "https://discord.gg/avoxhosting" },
                { name: "API Documentation", href: "https://billing.avoxhosting.com/developer-api" },
              ].map((item, index) => (
                <li key={index}>
                  <Link href={item.href} className="text-slate-400 hover:text-purple-400 transition-colors">
                    {item.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company & Legal */}
          <div>
            <h3 className="text-white font-bold mb-4 text-sm uppercase tracking-wide">Company</h3>
            <ul className="space-y-2 text-sm mb-6">
              {[
                { name: "About Avox", href: "https://avoxhosting.com/about" },
                { name: "Careers", href: "https://avoxhosting.com/careers" },
                { name: "Terms of Service", href: "https://avoxhosting.com/terms" },
                { name: "Privacy Policy", href: "https://avoxhosting.com/privacy" },
                { name: "Refund Policy", href: "https://avoxhosting.com/refunds" },
              ].map((item, index) => (
                <li key={index}>
                  <Link href={item.href} className="text-slate-400 hover:text-green-400 transition-colors">
                    {item.name}
                  </Link>
                </li>
              ))}
            </ul>

            {/* Social Links */}
            <div className="space-y-3">
              <h4 className="text-white font-medium text-sm">Follow Us</h4>
              <div className="flex space-x-3">
                {["Discord", "Twitter", "YouTube"].map((social, index) => (
                  <Link
                    key={index}
                    href="#"
                    className="w-8 h-8 bg-slate-800/50 rounded-lg flex items-center justify-center hover:bg-gradient-to-r hover:from-blue-500 hover:to-purple-500 transition-all duration-300 transform hover:scale-110"
                  >
                    <span className="text-xs font-bold">{social[0]}</span>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12 py-8 border-y border-slate-800/50">
          {[
            { value: "50K+", label: "Active Servers" },
            { value: "99.99%", label: "Uptime SLA" },
            { value: "24/7", label: "Expert Support" },
            { value: "15+", label: "Global Locations" },
          ].map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500 mb-1">
                {stat.value}
              </div>
              <div className="text-sm text-slate-400">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Payment Methods */}
        <div className="text-center mb-8">
          <h4 className="text-white font-medium mb-4 text-sm">Secure Payment Methods</h4>
          <div className="flex justify-center items-center flex-wrap gap-3">
            {[
              { name: "VISA", gradient: "from-blue-600 to-blue-700" },
              { name: "PayPal", gradient: "from-blue-500 to-blue-600" },
              { name: "Mastercard", gradient: "from-orange-500 to-red-500" },
              { name: "Stripe", gradient: "from-purple-500 to-indigo-500" },
              { name: "Crypto", gradient: "from-yellow-500 to-orange-500" },
            ].map((payment, index) => (
              <div
                key={index}
                className={`bg-gradient-to-r ${payment.gradient} px-3 py-1 rounded-lg text-white text-xs font-bold shadow-lg`}
              >
                {payment.name}
              </div>
            ))}
          </div>
        </div>

        {/* Bottom Section */}
        <div className="pt-6 border-t border-slate-800/50">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-center md:text-left">
              <p className="text-slate-400 text-sm">
                © 2025{" "}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500 font-semibold">
                  Avox Hosting
                </span>
                . All rights reserved.
              </p>
            </div>

            <div className="flex items-center space-x-4 text-sm">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                <span className="text-slate-400">All Systems Online</span>
              </div>
              <div className="text-slate-400">
                <span className="text-green-400 font-semibold">99.99%</span> Uptime
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
