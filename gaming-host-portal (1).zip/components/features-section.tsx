import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { HardDrive, Shield, Clock, Star, Cpu, Headphones } from "lucide-react"

export function FeaturesSection() {
  const features = [
    {
      icon: <HardDrive className="w-12 h-12 text-blue-400" />,
      title: "Optimized Storage",
      description:
        "Unlock lightning-fast speeds with our NVMe SSD technology, ensuring rapid data access and seamless performance for all your tasks!",
      borderColor: "border-blue-500/30",
    },
    {
      icon: <Shield className="w-12 h-12 text-red-400" />,
      title: "DDoS Protection",
      description:
        "Our services are protected by enterprise-level security against DDoS attacks, with a capacity of up to 17Tbps, ensuring your services remain online seamlessly.",
      borderColor: "border-red-500/30",
    },
    {
      icon: <Clock className="w-12 h-12 text-green-400" />,
      title: "Instant Setup",
      description:
        "Once an order is placed and payment is confirmed, the installation process for our services begins immediately.",
      borderColor: "border-green-500/30",
    },
    {
      icon: <Star className="w-12 h-12 text-yellow-400" />,
      title: "Highly Reviewed",
      description:
        "Our clients highly rate us for top-quality service. Join our community and experience what sets us apart!",
      borderColor: "border-yellow-500/30",
    },
    {
      icon: <Cpu className="w-12 h-12 text-purple-400" />,
      title: "Fast Processors",
      description:
        "Our hosting network is powered by high-performance AMD Ryzen 9 dedicated servers, delivering unparalleled game server performance.",
      borderColor: "border-purple-500/30",
    },
    {
      icon: <Headphones className="w-12 h-12 text-orange-400" />,
      title: "Support 24/7",
      description:
        "We are dedicated to supporting you at all times. Our 24/7 Support Team is available to address any commercial or technical issues you may encounter.",
      borderColor: "border-orange-500/30",
    },
  ]

  return (
    <section className="py-20 bg-slate-900/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4 text-white">Why choose Leora-Host?</h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto"></div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card
              key={index}
              className={`bg-slate-900/30 border ${feature.borderColor} hover:bg-slate-900/50 transition-all duration-300 group`}
            >
              <CardHeader>
                <div className="mb-4 group-hover:scale-110 transition-transform duration-300">{feature.icon}</div>
                <CardTitle className="text-white text-xl">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-300 leading-relaxed">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
