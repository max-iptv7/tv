"use client"

import { useEffect, useRef } from "react"

interface Snowflake {
  x: number
  y: number
  size: number
  speed: number
  opacity: number
}

export function OptimizedSnowSystem() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const snowflakesRef = useRef<Snowflake[]>([])
  const animationRef = useRef<number>()

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const resizeCanvas = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    resizeCanvas()
    window.addEventListener("resize", resizeCanvas)

    // Create fewer snowflakes for better performance
    const createSnowflake = (): Snowflake => ({
      x: Math.random() * canvas.width,
      y: -10,
      size: Math.random() * 2 + 1,
      speed: Math.random() * 1 + 0.5,
      opacity: Math.random() * 0.4 + 0.2,
    })

    // Initialize with fewer snowflakes
    for (let i = 0; i < 50; i++) {
      snowflakesRef.current.push({
        ...createSnowflake(),
        y: Math.random() * canvas.height,
      })
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      snowflakesRef.current.forEach((snowflake, index) => {
        snowflake.y += snowflake.speed

        if (snowflake.y > canvas.height) {
          snowflakesRef.current[index] = createSnowflake()
        }

        ctx.save()
        ctx.globalAlpha = snowflake.opacity
        ctx.fillStyle = "#ffffff"
        ctx.beginPath()
        ctx.arc(snowflake.x, snowflake.y, snowflake.size, 0, Math.PI * 2)
        ctx.fill()
        ctx.restore()
      })

      animationRef.current = requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener("resize", resizeCanvas)
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [])

  return <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none z-10 opacity-60" />
}
