"use client"

import type React from "react"

import { ResponsiveHeader } from "@/components/responsive-header"
import { Footer } from "@/components/footer"
import { SimpleSnowSystem } from "@/components/simple-snow-system"
import { Mail, Phone, MapPin, Clock, MessageCircle, Send } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useState } from "react"

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission here
    console.log("Form submitted:", formData)
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const contactMethods = [
    {
      icon: Mail,
      title: "Email Support",
      description: "Get help via email",
      contact: "support@avoxhosting.com",
      action: "mailto:support@avoxhosting.com",
    },
    {
      icon: MessageCircle,
      title: "Live Chat",
      description: "Chat with our team",
      contact: "Available 24/7",
      action: "https://client.avoxhosting.site/",
    },
    {
      icon: Phone,
      title: "Phone Support",
      description: "Call us directly",
      contact: "+1 (555) 123-4567",
      action: "tel:+15551234567",
    },
    {
      icon: MapPin,
      title: "Office Location",
      description: "Visit our headquarters",
      contact: "123 Tech Street, Digital City",
      action: "#",
    },
  ]

  return (
    <div className="min-h-screen bg-slate-950 text-white overflow-x-hidden">
      <SimpleSnowSystem />
      <ResponsiveHeader />

      <main className="relative z-10 pt-8 sm:pt-12 md:pt-16 lg:pt-20">
        {/* Hero Section */}
        <section className="py-12 sm:py-16 md:py-20 lg:py-24">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-4xl mx-auto mb-12 sm:mb-16">
              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black mb-4 sm:mb-6">
                <span className="bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">
                  Contact Us
                </span>
              </h1>
              <p className="text-lg sm:text-xl md:text-2xl text-slate-300 leading-relaxed">
                Get in touch with our expert team for support, sales, or any questions
              </p>
            </div>

            {/* Contact Methods Grid */}
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8 mb-12 sm:mb-16">
              {contactMethods.map((method, index) => (
                <Card
                  key={index}
                  className="bg-slate-900/50 border-slate-800/50 backdrop-blur-sm hover:border-blue-500/30 transition-all duration-300 group"
                >
                  <CardContent className="p-6 text-center">
                    <div className="w-12 h-12 sm:w-16 sm:h-16 mx-auto mb-4 sm:mb-6 rounded-full bg-blue-500/20 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                      <method.icon className="w-6 h-6 sm:w-8 sm:h-8 text-blue-400" />
                    </div>
                    <h3 className="text-lg sm:text-xl font-bold text-white mb-2">{method.title}</h3>
                    <p className="text-sm text-slate-400 mb-3">{method.description}</p>
                    <p className="text-sm sm:text-base text-blue-400 font-medium">{method.contact}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Contact Form and Info */}
            <div className="grid lg:grid-cols-2 gap-8 sm:gap-12 max-w-6xl mx-auto">
              {/* Contact Form */}
              <Card className="bg-slate-900/50 border-slate-800/50 backdrop-blur-sm">
                <CardContent className="p-6 sm:p-8">
                  <h2 className="text-2xl sm:text-3xl font-bold text-white mb-6 sm:mb-8">Send us a Message</h2>

                  <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="name" className="block text-sm font-medium text-slate-300 mb-2">
                          Name
                        </label>
                        <Input
                          id="name"
                          name="name"
                          type="text"
                          required
                          value={formData.name}
                          onChange={handleChange}
                          className="bg-slate-800/50 border-slate-700 text-white placeholder-slate-400 focus:border-blue-500"
                          placeholder="Your name"
                        />
                      </div>
                      <div>
                        <label htmlFor="email" className="block text-sm font-medium text-slate-300 mb-2">
                          Email
                        </label>
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          required
                          value={formData.email}
                          onChange={handleChange}
                          className="bg-slate-800/50 border-slate-700 text-white placeholder-slate-400 focus:border-blue-500"
                          placeholder="your@email.com"
                        />
                      </div>
                    </div>

                    <div>
                      <label htmlFor="subject" className="block text-sm font-medium text-slate-300 mb-2">
                        Subject
                      </label>
                      <Input
                        id="subject"
                        name="subject"
                        type="text"
                        required
                        value={formData.subject}
                        onChange={handleChange}
                        className="bg-slate-800/50 border-slate-700 text-white placeholder-slate-400 focus:border-blue-500"
                        placeholder="How can we help?"
                      />
                    </div>

                    <div>
                      <label htmlFor="message" className="block text-sm font-medium text-slate-300 mb-2">
                        Message
                      </label>
                      <Textarea
                        id="message"
                        name="message"
                        required
                        rows={6}
                        value={formData.message}
                        onChange={handleChange}
                        className="bg-slate-800/50 border-slate-700 text-white placeholder-slate-400 focus:border-blue-500 resize-none"
                        placeholder="Tell us more about your inquiry..."
                      />
                    </div>

                    <Button
                      type="submit"
                      className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-bold py-3 px-6 rounded-lg transition-all duration-300 shadow-lg hover:shadow-xl hover:shadow-blue-500/30"
                    >
                      <Send className="w-5 h-5 mr-2" />
                      Send Message
                    </Button>
                  </form>
                </CardContent>
              </Card>

              {/* Contact Information */}
              <div className="space-y-6 sm:space-y-8">
                <Card className="bg-slate-900/50 border-slate-800/50 backdrop-blur-sm">
                  <CardContent className="p-6 sm:p-8">
                    <h3 className="text-xl sm:text-2xl font-bold text-white mb-4 sm:mb-6">Support Hours</h3>
                    <div className="space-y-3 sm:space-y-4">
                      <div className="flex items-center space-x-3">
                        <Clock className="w-5 h-5 text-blue-400" />
                        <div>
                          <p className="text-white font-medium">24/7 Technical Support</p>
                          <p className="text-sm text-slate-400">Always available for critical issues</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <MessageCircle className="w-5 h-5 text-blue-400" />
                        <div>
                          <p className="text-white font-medium">Live Chat</p>
                          <p className="text-sm text-slate-400">Monday - Sunday, 24/7</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Mail className="w-5 h-5 text-blue-400" />
                        <div>
                          <p className="text-white font-medium">Email Support</p>
                          <p className="text-sm text-slate-400">Response within 1 hour</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-blue-900/30 to-blue-800/30 border-blue-500/30 backdrop-blur-sm">
                  <CardContent className="p-6 sm:p-8 text-center">
                    <h3 className="text-xl sm:text-2xl font-bold text-white mb-4">Need Immediate Help?</h3>
                    <p className="text-slate-300 mb-6">
                      For urgent technical issues, contact our emergency support line
                    </p>
                    <Button
                      asChild
                      className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-6 rounded-lg transition-all duration-300"
                    >
                      <a href="https://client.avoxhosting.site/" target="_blank" rel="noopener noreferrer">
                        Emergency Support
                      </a>
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
