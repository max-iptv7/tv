"use client"

import { useEffect, useState } from "react"
import { Zap, Server, Globe, Shield } from "lucide-react"
import Image from "next/image"

interface OptimizedLoadingScreenProps {
  onLoadingComplete: () => void
}

export function OptimizedLoadingScreen({ onLoadingComplete }: OptimizedLoadingScreenProps) {
  const [progress, setProgress] = useState(0)
  const [currentStep, setCurrentStep] = useState(0)

  const loadingSteps = [
    { icon: <Server className="w-8 h-8" />, text: "Initializing Servers", color: "text-orange-400" },
    { icon: <Globe className="w-8 h-8" />, text: "Connecting Network", color: "text-red-400" },
    { icon: <Shield className="w-8 h-8" />, text: "Security Check", color: "text-orange-400" },
    { icon: <Zap className="w-8 h-8" />, text: "Ready to Launch", color: "text-red-400" },
  ]

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        const newProgress = prev + 1.5

        const stepIndex = Math.floor((newProgress / 100) * loadingSteps.length)
        setCurrentStep(Math.min(stepIndex, loadingSteps.length - 1))

        if (newProgress >= 100) {
          clearInterval(timer)
          setTimeout(onLoadingComplete, 500)
          return 100
        }
        return newProgress
      })
    }, 30)

    return () => clearInterval(timer)
  }, [onLoadingComplete, loadingSteps.length])

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center z-50">
      <div className="text-center relative z-10 max-w-md mx-auto px-6">
        {/* Logo */}
        <div className="mb-8">
          <div className="w-24 h-24 mx-auto relative">
            <Image
              src="/images/avox-logo.png"
              alt="Avox Hosting"
              width={96}
              height={96}
              className="w-full h-full object-contain"
            />
          </div>
        </div>

        {/* Brand Name */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">
            <span className="bg-gradient-to-r from-orange-400 to-red-500 bg-clip-text text-transparent">
              Avox Hosting
            </span>
          </h1>
          <p className="text-slate-400 text-lg">Premium Gaming Servers</p>
        </div>

        {/* Loading Step */}
        <div className="mb-8">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className={`${loadingSteps[currentStep]?.color || "text-orange-400"} transition-colors duration-300`}>
              {loadingSteps[currentStep]?.icon}
            </div>
            <div className="text-white font-medium text-lg">{loadingSteps[currentStep]?.text || "Loading..."}</div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mb-6">
          <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-orange-500 to-red-500 transition-all duration-300 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex justify-between items-center mt-2">
            <span className="text-slate-400 text-sm">Loading...</span>
            <span className="text-xl font-bold bg-gradient-to-r from-orange-400 to-red-500 bg-clip-text text-transparent">
              {Math.round(progress)}%
            </span>
          </div>
        </div>

        {/* Status */}
        <div className="flex items-center justify-center space-x-2">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
          <span className="text-green-400 text-sm">Secure Connection</span>
        </div>
      </div>
    </div>
  )
}
