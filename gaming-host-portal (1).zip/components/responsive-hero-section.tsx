"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Cpu, HardDrive, Zap, Globe, ArrowRight, Play, Shield, Rocket, Server, Activity, Wifi } from "lucide-react"
import { useEffect, useRef, useState } from "react"
import Link from "next/link"
import Image from "next/image"

export function ResponsiveHeroSection() {
  const [isVisible, setIsVisible] = useState(false)
  const [activeMetric, setActiveMetric] = useState(0)
  const heroRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    setIsVisible(true)

    // Cycle through metrics
    const metricTimer = setInterval(() => {
      setActiveMetric((prev) => (prev + 1) % 3)
    }, 2000)

    return () => {
      clearInterval(metricTimer)
    }
  }, [])

  const metrics = [
    { label: "CPU Performance", value: 98, color: "from-blue-400 to-blue-500", icon: <Cpu className="w-4 h-4" /> },
    { label: "Network Speed", value: 95, color: "from-red-400 to-red-500", icon: <Wifi className="w-4 h-4" /> },
    { label: "Server Uptime", value: 99.9, color: "from-blue-400 to-red-500", icon: <Activity className="w-4 h-4" /> },
  ]

  return (
    <section
      ref={heroRef}
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20 sm:pt-24 md:pt-32 px-4 sm:px-6 lg:px-8"
    >
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/10 via-red-900/10 to-blue-900/10" />

        {/* Grid Pattern */}
        <div
          className="absolute inset-0 opacity-5"
          style={{
            backgroundImage: `
              linear-gradient(rgba(59, 130, 246, 0.5) 1px, transparent 1px),
              linear-gradient(90deg, rgba(59, 130, 246, 0.5) 1px, transparent 1px)
            `,
            backgroundSize: "50px 50px",
          }}
        />
      </div>

      <div className="container mx-auto relative z-10">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center">
          {/* Content */}
          <div
            className={`space-y-6 sm:space-y-8 md:space-y-10 text-center lg:text-left transition-all duration-1000 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
          >
            {/* Trust Badges */}
            <div className="flex flex-wrap justify-center lg:justify-start gap-2 sm:gap-3 md:gap-4">
              <Badge className="bg-gradient-to-r from-blue-500/20 to-blue-500/20 text-blue-300 border-blue-500/30 px-3 sm:px-4 py-1 sm:py-2 text-xs sm:text-sm font-bold">
                <Shield className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                99.9% UPTIME
              </Badge>
              <Badge className="bg-gradient-to-r from-red-500/20 to-red-500/20 text-red-300 border-red-500/30 px-3 sm:px-4 py-1 sm:py-2 text-xs sm:text-sm font-bold">
                <Zap className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                INSTANT DEPLOY
              </Badge>
              <Badge className="bg-gradient-to-r from-white/20 to-white/20 text-white border-white/30 px-3 sm:px-4 py-1 sm:py-2 text-xs sm:text-sm font-bold">
                <Server className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                PREMIUM
              </Badge>
            </div>

            {/* Main Title */}
            <div className="space-y-4 sm:space-y-6">
              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-black leading-tight">
                <span className="block text-white mb-2 sm:mb-3">PREMIUM</span>
                <span className="block bg-gradient-to-r from-blue-400 via-red-500 to-blue-400 bg-clip-text text-transparent mb-2 sm:mb-3">
                  GAMING
                </span>
                <span className="block bg-gradient-to-r from-red-500 via-blue-500 to-red-500 bg-clip-text text-transparent">
                  SERVERS
                </span>
              </h1>

              <p className="text-base sm:text-lg md:text-xl lg:text-2xl text-slate-300 leading-relaxed max-w-2xl mx-auto lg:mx-0 font-medium">
                Experience the power of{" "}
                <span className="bg-gradient-to-r from-blue-400 to-red-500 bg-clip-text text-transparent font-black">
                  AVOX HOSTING
                </span>{" "}
                — lightning-fast servers, military-grade security, and 24/7 expert support for the ultimate gaming
                experience.
              </p>
            </div>

            {/* Performance Features */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 md:gap-6 py-4 sm:py-6 md:py-8">
              {[
                {
                  icon: <Shield className="w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6" />,
                  text: "DDoS PROTECTED",
                  color: "text-blue-400",
                  bg: "from-blue-500/10 to-blue-500/10",
                  border: "border-blue-500/20",
                },
                {
                  icon: <Zap className="w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6" />,
                  text: "INSTANT SETUP",
                  color: "text-red-400",
                  bg: "from-red-500/10 to-red-500/10",
                  border: "border-red-500/20",
                },
                {
                  icon: <Globe className="w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6" />,
                  text: "GLOBAL NETWORK",
                  color: "text-white",
                  bg: "from-white/10 to-white/10",
                  border: "border-white/20",
                },
              ].map((feature, index) => (
                <div
                  key={index}
                  className={`flex items-center justify-center lg:justify-start space-x-2 sm:space-x-3 bg-gradient-to-r ${feature.bg} border ${feature.border} px-3 sm:px-4 md:px-6 py-2 sm:py-3 md:py-4 rounded-lg sm:rounded-xl backdrop-blur-sm hover:scale-105 transition-all duration-300 group`}
                >
                  <div className={`${feature.color} group-hover:scale-110 transition-transform duration-300`}>
                    {feature.icon}
                  </div>
                  <span className="text-slate-300 font-black text-xs sm:text-sm">{feature.text}</span>
                </div>
              ))}
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 sm:gap-6 justify-center lg:justify-start">
              <Button
                size="lg"
                className="group bg-gradient-to-r from-blue-500 via-red-500 to-blue-500 hover:from-blue-600 hover:via-red-600 hover:to-blue-600 text-white text-base sm:text-lg md:text-xl font-black px-6 sm:px-8 md:px-10 py-3 sm:py-4 md:py-6 rounded-lg sm:rounded-xl shadow-xl hover:shadow-blue-500/30 transition-all duration-300 transform hover:scale-105"
                asChild
              >
                <Link href="https://billing.avoxhosting.com/cart.php">
                  <Rocket className="mr-2 sm:mr-3 md:mr-4 w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6 group-hover:rotate-12 transition-transform duration-300" />
                  <span>GET STARTED</span>
                  <ArrowRight className="ml-2 sm:ml-3 md:ml-4 w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6 group-hover:translate-x-2 transition-transform duration-300" />
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="group border-2 border-slate-600 text-slate-300 hover:text-white hover:bg-slate-800/50 text-base sm:text-lg md:text-xl font-black px-6 sm:px-8 md:px-10 py-3 sm:py-4 md:py-6 rounded-lg sm:rounded-xl backdrop-blur-sm hover:border-blue-500/50 transition-all duration-300 bg-transparent"
                asChild
              >
                <Link href="#demo">
                  <Play className="mr-2 sm:mr-3 md:mr-4 w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6 group-hover:scale-110 transition-transform duration-300" />
                  <span>VIEW DEMO</span>
                </Link>
              </Button>
            </div>

            {/* Live Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 md:gap-8 pt-6 sm:pt-8 md:pt-10 border-t border-slate-800/50">
              {[
                {
                  value: "99.9%",
                  label: "UPTIME SLA",
                  color: "from-blue-400 to-blue-500",
                  icon: <Shield className="w-3 h-3 sm:w-4 sm:h-4 md:w-5 md:h-5" />,
                },
                {
                  value: "250K+",
                  label: "SERVERS DEPLOYED",
                  color: "from-red-400 to-red-500",
                  icon: <Server className="w-3 h-3 sm:w-4 sm:h-4 md:w-5 md:h-5" />,
                },
                {
                  value: "<15s",
                  label: "SETUP TIME",
                  color: "from-white to-white",
                  icon: <Zap className="w-3 h-3 sm:w-4 sm:h-4 md:w-5 md:h-5" />,
                },
              ].map((stat, index) => (
                <div key={index} className="text-center group">
                  <div className="flex items-center justify-center space-x-2 sm:space-x-3 mb-2 sm:mb-3">
                    <div className={`bg-gradient-to-r ${stat.color} bg-clip-text text-transparent`}>{stat.icon}</div>
                    <div
                      className={`text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-black bg-gradient-to-r ${stat.color} bg-clip-text text-transparent`}
                    >
                      {stat.value}
                    </div>
                  </div>
                  <div className="text-xs sm:text-sm text-slate-400 group-hover:text-slate-300 transition-colors font-bold tracking-wider">
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Server Panel */}
          <div
            className={`relative transition-all duration-1000 delay-300 ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-10"}`}
          >
            <div className="relative w-full max-w-lg mx-auto lg:max-w-2xl">
              {/* Main Server Panel */}
              <div className="relative bg-gradient-to-br from-slate-900/95 to-slate-800/95 backdrop-blur-xl rounded-2xl sm:rounded-3xl p-4 sm:p-6 md:p-8 lg:p-10 border border-slate-700/50 shadow-2xl">
                {/* Header */}
                <div className="flex items-center justify-between mb-4 sm:mb-6 md:mb-8">
                  <div className="flex items-center space-x-2 sm:space-x-3 md:space-x-4">
                    <div className="w-8 h-8 sm:w-12 sm:h-12 md:w-16 md:h-16 relative">
                      <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-red-500 rounded-lg sm:rounded-xl md:rounded-2xl blur-sm sm:blur-lg opacity-60" />
                      <div className="relative w-full h-full bg-slate-900 rounded-lg sm:rounded-xl md:rounded-2xl border border-blue-500/40 flex items-center justify-center">
                        <Image
                          src="/images/avox-logo.png"
                          alt="Avox Hosting"
                          width={40}
                          height={40}
                          className="w-5 h-5 sm:w-7 sm:h-7 md:w-10 md:h-10 object-contain"
                        />
                      </div>
                    </div>
                    <div>
                      <h3 className="font-black text-white text-sm sm:text-lg md:text-xl lg:text-2xl">AVOX GAMING</h3>
                      <p className="text-slate-400 font-medium text-xs sm:text-sm md:text-base">
                        Premium Infrastructure
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-1 sm:space-x-2 md:space-x-3">
                    <div className="w-2 h-2 sm:w-3 sm:h-3 md:w-4 md:h-4 bg-blue-400 rounded-full animate-pulse" />
                    <span className="text-blue-400 font-bold text-xs sm:text-sm md:text-base lg:text-lg">ONLINE</span>
                  </div>
                </div>

                {/* Server Specs */}
                <div className="grid grid-cols-2 gap-2 sm:gap-3 md:gap-4 lg:gap-6 mb-4 sm:mb-6 md:mb-8">
                  {[
                    {
                      icon: <Cpu className="w-3 h-3 sm:w-4 sm:h-4 md:w-5 md:h-5 lg:w-6 lg:h-6 text-blue-400" />,
                      label: "AMD RYZEN™ 9",
                      value: "7950X3D",
                      gradient: "from-blue-500 to-blue-500",
                    },
                    {
                      icon: <HardDrive className="w-3 h-3 sm:w-4 sm:h-4 md:w-5 md:h-5 lg:w-6 lg:h-6 text-red-400" />,
                      label: "NVME SSD",
                      value: "UP TO 16TB",
                      gradient: "from-red-500 to-red-500",
                    },
                    {
                      icon: <Zap className="w-3 h-3 sm:w-4 sm:h-4 md:w-5 md:h-5 lg:w-6 lg:h-6 text-white" />,
                      label: "DDR5 RAM",
                      value: "UP TO 256GB",
                      gradient: "from-white to-white",
                    },
                    {
                      icon: <Globe className="w-3 h-3 sm:w-4 sm:h-4 md:w-5 md:h-5 lg:w-6 lg:h-6 text-blue-400" />,
                      label: "NETWORK",
                      value: "10 GBPS",
                      gradient: "from-blue-500 to-red-500",
                    },
                  ].map((spec, index) => (
                    <div
                      key={index}
                      className={`bg-gradient-to-br ${spec.gradient}/10 border border-slate-700/30 rounded-lg sm:rounded-xl md:rounded-2xl p-2 sm:p-3 md:p-4 lg:p-6 hover:scale-105 transition-all duration-300 group`}
                    >
                      <div className="flex items-center space-x-1 sm:space-x-2 md:space-x-3 mb-1 sm:mb-2 md:mb-3">
                        <div className="group-hover:scale-110 transition-transform duration-300">{spec.icon}</div>
                        <span className="text-xs sm:text-xs md:text-xs text-slate-400 font-bold tracking-wider">
                          {spec.label}
                        </span>
                      </div>
                      <div className="text-xs sm:text-sm md:text-sm font-black text-white">{spec.value}</div>
                    </div>
                  ))}
                </div>

                {/* Live Metrics */}
                <div className="space-y-3 sm:space-y-4 md:space-y-6">
                  {metrics.map((metric, index) => (
                    <div
                      key={index}
                      className={`transition-all duration-500 ${activeMetric === index ? "scale-105" : "scale-100"}`}
                    >
                      <div className="flex justify-between items-center text-xs sm:text-sm mb-1 sm:mb-2 md:mb-3">
                        <div className="flex items-center space-x-1 sm:space-x-2">
                          <div className={`bg-gradient-to-r ${metric.color} bg-clip-text text-transparent`}>
                            {metric.icon}
                          </div>
                          <span className="text-slate-400 font-bold">{metric.label}</span>
                        </div>
                        <span className="text-white font-black text-sm sm:text-base md:text-lg">{metric.value}%</span>
                      </div>
                      <div className="w-full bg-slate-700/50 rounded-full h-2 sm:h-3 overflow-hidden">
                        <div
                          className={`bg-gradient-to-r ${metric.color} h-2 sm:h-3 rounded-full transition-all duration-1000 relative overflow-hidden ${activeMetric === index ? "animate-pulse" : ""}`}
                          style={{ width: `${metric.value}%` }}
                        >
                          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-pulse" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Glow Effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 via-red-600/20 to-blue-600/20 rounded-2xl sm:rounded-3xl blur-2xl sm:blur-3xl -z-10 animate-pulse" />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
