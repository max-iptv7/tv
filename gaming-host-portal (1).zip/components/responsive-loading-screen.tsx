"use client"

import { useEffect, useState } from "react"
import Image from "next/image"
import { Zap, Shield, Globe, Server, Rocket, Crown } from "lucide-react"

interface ResponsiveLoadingScreenProps {
  onLoadingComplete: () => void
}

export function ResponsiveLoadingScreen({ onLoadingComplete }: ResponsiveLoadingScreenProps) {
  const [progress, setProgress] = useState(0)
  const [currentStep, setCurrentStep] = useState(0)
  const [isComplete, setIsComplete] = useState(false)

  const steps = [
    {
      icon: <Server className="w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6" />,
      text: "Initializing Servers",
      color: "text-blue-400",
    },
    {
      icon: <Shield className="w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6" />,
      text: "Securing Connection",
      color: "text-red-400",
    },
    {
      icon: <Globe className="w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6" />,
      text: "Connecting Network",
      color: "text-white",
    },
    {
      icon: <Zap className="w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6" />,
      text: "Optimizing Performance",
      color: "text-blue-400",
    },
    {
      icon: <Rocket className="w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6" />,
      text: "Ready to Launch",
      color: "text-red-400",
    },
  ]

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        const newProgress = prev + 2

        // Update current step based on progress
        const stepIndex = Math.floor((newProgress / 100) * steps.length)
        setCurrentStep(Math.min(stepIndex, steps.length - 1))

        if (newProgress >= 100) {
          setIsComplete(true)
          setTimeout(() => {
            onLoadingComplete()
          }, 800)
          clearInterval(timer)
          return 100
        }
        return newProgress
      })
    }, 50)

    return () => clearInterval(timer)
  }, [onLoadingComplete, steps.length])

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center overflow-hidden">
      {/* Enhanced Professional Background */}
      <div className="absolute inset-0">
        {/* Base gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950" />

        {/* Animated color layers */}
        <div className="absolute inset-0">
          <div className="absolute top-0 left-0 w-96 h-96 bg-gradient-radial from-blue-500/15 via-blue-500/8 to-transparent rounded-full blur-3xl animate-pulse" />
          <div
            className="absolute top-1/3 right-0 w-80 h-80 bg-gradient-radial from-red-500/12 via-red-500/6 to-transparent rounded-full blur-3xl animate-pulse"
            style={{ animationDelay: "1s" }}
          />
          <div
            className="absolute bottom-0 left-1/3 w-72 h-72 bg-gradient-radial from-blue-500/10 via-blue-500/5 to-transparent rounded-full blur-3xl animate-pulse"
            style={{ animationDelay: "2s" }}
          />
        </div>

        {/* Professional grid pattern */}
        <div
          className="absolute inset-0 opacity-[0.05]"
          style={{
            backgroundImage: `
              linear-gradient(rgba(59, 130, 246, 0.8) 1px, transparent 1px),
              linear-gradient(90deg, rgba(59, 130, 246, 0.8) 1px, transparent 1px)
            `,
            backgroundSize: "60px 60px",
          }}
        />

        {/* Floating shapes */}
        <div className="absolute inset-0 overflow-hidden">
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              className="absolute opacity-[0.08]"
              style={{
                width: `${15 + Math.random() * 25}px`,
                height: `${15 + Math.random() * 25}px`,
                background:
                  i % 2 === 0 ? "linear-gradient(45deg, #3B82F6, #1D4ED8)" : "linear-gradient(45deg, #EF4444, #DC2626)",
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                borderRadius: i % 3 === 0 ? "50%" : "6px",
                animation: `float ${6 + Math.random() * 3}s ease-in-out infinite`,
                animationDelay: `${Math.random() * 3}s`,
              }}
            />
          ))}
        </div>
      </div>

      {/* Loading Content */}
      <div className="relative z-10 text-center px-4 sm:px-6 md:px-8">
        {/* Logo */}
        <div className="mb-6 sm:mb-8 md:mb-12">
          <div className="relative w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 lg:w-32 lg:h-32 mx-auto">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-red-500 to-blue-500 rounded-2xl sm:rounded-3xl blur-lg opacity-60 animate-pulse" />
            <div className="relative w-full h-full bg-slate-900 rounded-2xl sm:rounded-3xl border-2 border-blue-500/40 flex items-center justify-center overflow-hidden">
              <Image
                src="/images/avox-logo.png"
                alt="Avox Hosting"
                width={80}
                height={80}
                className="w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 lg:w-16 lg:h-16 object-contain"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-pulse" />
            </div>
          </div>
        </div>

        {/* Brand */}
        <div className="mb-6 sm:mb-8 md:mb-10">
          <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-black mb-2 sm:mb-3 md:mb-4">
            <span className="bg-gradient-to-r from-blue-400 via-red-500 to-blue-400 bg-clip-text text-transparent">
              AVOX HOSTING
            </span>
          </h1>
          <p className="text-sm sm:text-base md:text-lg text-slate-400 font-medium">Premium Gaming Infrastructure</p>
        </div>

        {/* Progress Bar */}
        <div className="mb-6 sm:mb-8 md:mb-10 max-w-xs sm:max-w-sm md:max-w-md mx-auto">
          <div className="w-full bg-slate-800/50 rounded-full h-2 sm:h-3 md:h-4 overflow-hidden backdrop-blur-sm border border-slate-700/30">
            <div
              className="bg-gradient-to-r from-blue-500 via-red-500 to-blue-500 h-full rounded-full transition-all duration-300 relative overflow-hidden"
              style={{ width: `${progress}%` }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-pulse" />
            </div>
          </div>
          <div className="flex justify-between items-center mt-2 sm:mt-3 md:mt-4">
            <span className="text-xs sm:text-sm md:text-base text-slate-400 font-medium">Loading...</span>
            <span className="text-xs sm:text-sm md:text-base text-white font-bold">{progress}%</span>
          </div>
        </div>

        {/* Current Step */}
        <div className="space-y-3 sm:space-y-4 md:space-y-6">
          <div className="flex items-center justify-center space-x-2 sm:space-x-3 md:space-x-4">
            <div className={`${steps[currentStep]?.color || "text-blue-400"} animate-pulse`}>
              {steps[currentStep]?.icon}
            </div>
            <span className="text-sm sm:text-base md:text-lg text-slate-300 font-medium">
              {steps[currentStep]?.text || "Loading..."}
            </span>
          </div>

          {/* Step Indicators */}
          <div className="flex justify-center space-x-1 sm:space-x-2 md:space-x-3">
            {steps.map((_, index) => (
              <div
                key={index}
                className={`w-2 h-2 sm:w-3 sm:h-3 md:w-4 md:h-4 rounded-full transition-all duration-300 ${
                  index <= currentStep
                    ? index % 2 === 0
                      ? "bg-blue-500 shadow-lg shadow-blue-500/50"
                      : "bg-red-500 shadow-lg shadow-red-500/50"
                    : "bg-slate-700"
                }`}
              />
            ))}
          </div>
        </div>

        {/* Completion Animation */}
        {isComplete && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 bg-gradient-to-r from-blue-500 to-red-500 rounded-full flex items-center justify-center animate-ping">
              <Crown className="w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 text-white" />
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
