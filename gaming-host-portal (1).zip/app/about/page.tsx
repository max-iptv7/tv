"use client"

import { ResponsiveHeader } from "@/components/responsive-header"
import { Footer } from "@/components/footer"
import { SimpleSnowSystem } from "@/components/simple-snow-system"
import { Shield, Users, Award, Clock, Server, Globe, Zap, Lock } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"

export default function AboutPage() {
  const teamMembers = [
    {
      name: "Ayoub C",
      role: "CEO & Co-Founder",
      description:
        "Cybersecurity expert specializing in DDoS mitigation, network security, and cloud architecture. Leading Avox Hosting with 8+ years of experience in enterprise hosting solutions.",
      skills: ["DDoS Protection", "Network Security", "Cloud Architecture", "Enterprise Solutions"],
      avatar: "/placeholder.svg?height=120&width=120",
    },
    {
      name: "Brahim",
      role: "CTO & Co-Founder",
      description:
        "Full-stack developer and systems architect specializing in high-performance computing, server optimization, and database management. Expert in gaming server infrastructure.",
      skills: ["High-Performance Computing", "Server Optimization", "Database Management", "Gaming Infrastructure"],
      avatar: "/placeholder.svg?height=120&width=120",
    },
  ]

  const protectionFeatures = [
    {
      icon: Shield,
      title: "20Tbps DDoS Protection",
      description: "Industry-leading protection against the largest DDoS attacks",
      highlight: true,
    },
    {
      icon: Zap,
      title: "Real-time Mitigation",
      description: "Instant threat detection and automated response systems",
    },
    {
      icon: Globe,
      title: "Global Network",
      description: "Distributed infrastructure across multiple continents",
    },
    {
      icon: Lock,
      title: "Advanced Filtering",
      description: "Multi-layer security with intelligent traffic analysis",
    },
  ]

  const stats = [
    { label: "Years of Experience", value: "8+", icon: Clock },
    { label: "Servers Protected", value: "10,000+", icon: Server },
    { label: "Happy Clients", value: "5,000+", icon: Users },
    { label: "Uptime Guarantee", value: "99.9%", icon: Award },
  ]

  return (
    <div className="min-h-screen bg-slate-950 text-white overflow-x-hidden">
      <SimpleSnowSystem />
      <ResponsiveHeader />

      <main className="relative z-10 pt-8 sm:pt-12 md:pt-16 lg:pt-20">
        {/* Hero Section */}
        <section className="py-12 sm:py-16 md:py-20 lg:py-24">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-4xl mx-auto">
              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black mb-4 sm:mb-6">
                <span className="bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">
                  About Avox Hosting
                </span>
              </h1>
              <p className="text-lg sm:text-xl md:text-2xl text-slate-300 mb-8 sm:mb-12 leading-relaxed">
                Premium gaming hosting solutions powered by cutting-edge technology and unmatched expertise
              </p>

              {/* Stats Grid */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 md:gap-8">
                {stats.map((stat, index) => (
                  <Card key={index} className="bg-slate-900/50 border-slate-800/50 backdrop-blur-sm">
                    <CardContent className="p-4 sm:p-6 text-center">
                      <stat.icon className="w-6 h-6 sm:w-8 sm:h-8 text-blue-400 mx-auto mb-2 sm:mb-3" />
                      <div className="text-xl sm:text-2xl md:text-3xl font-bold text-white mb-1">{stat.value}</div>
                      <div className="text-xs sm:text-sm text-slate-400">{stat.label}</div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Leadership Team */}
        <section className="py-12 sm:py-16 md:py-20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12 sm:mb-16">
              <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-black mb-4 sm:mb-6">
                <span className="bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">
                  Leadership Team
                </span>
              </h2>
              <p className="text-lg sm:text-xl text-slate-300 max-w-3xl mx-auto">
                Meet the experts behind Avox Hosting's success
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 sm:gap-12 max-w-6xl mx-auto">
              {teamMembers.map((member, index) => (
                <Card
                  key={index}
                  className="bg-gradient-to-br from-slate-900/80 to-slate-800/80 border-slate-700/50 backdrop-blur-sm hover:border-blue-500/30 transition-all duration-300 group"
                >
                  <CardContent className="p-6 sm:p-8">
                    <div className="flex flex-col sm:flex-row items-center sm:items-start space-y-4 sm:space-y-0 sm:space-x-6">
                      <div className="relative">
                        <div className="w-24 h-24 sm:w-28 sm:h-28 md:w-32 md:h-32 rounded-full overflow-hidden border-4 border-blue-500/30 group-hover:border-blue-400/50 transition-colors duration-300">
                          <img
                            src={member.avatar || "/placeholder.svg"}
                            alt={member.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                          <Users className="w-4 h-4 text-white" />
                        </div>
                      </div>

                      <div className="flex-1 text-center sm:text-left">
                        <h3 className="text-xl sm:text-2xl font-bold text-white mb-1">{member.name}</h3>
                        <p className="text-blue-400 font-semibold mb-3 sm:mb-4">{member.role}</p>
                        <p className="text-slate-300 text-sm sm:text-base leading-relaxed mb-4 sm:mb-6">
                          {member.description}
                        </p>

                        <div className="flex flex-wrap gap-2 justify-center sm:justify-start">
                          {member.skills.map((skill, skillIndex) => (
                            <Badge
                              key={skillIndex}
                              className="bg-blue-500/20 text-blue-300 border-blue-500/30 text-xs px-2 py-1"
                            >
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Avox Shield v2 Protection */}
        <section className="py-12 sm:py-16 md:py-20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12 sm:mb-16">
              <div className="inline-flex items-center space-x-2 bg-blue-500/10 border border-blue-500/20 rounded-full px-4 py-2 mb-4 sm:mb-6">
                <Shield className="w-5 h-5 text-blue-400" />
                <span className="text-blue-400 font-semibold text-sm sm:text-base">Avox Shield v2</span>
              </div>
              <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-black mb-4 sm:mb-6">
                <span className="bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">
                  20Tbps DDoS Protection
                </span>
              </h2>
              <p className="text-lg sm:text-xl text-slate-300 max-w-3xl mx-auto">
                Industry-leading protection powered by our advanced Avox Shield v2 technology
              </p>
            </div>

            {/* 20Tbps Highlight */}
            <div className="max-w-4xl mx-auto mb-12 sm:mb-16">
              <Card className="bg-gradient-to-r from-blue-900/30 via-blue-800/30 to-blue-900/30 border-blue-500/30 backdrop-blur-sm">
                <CardContent className="p-8 sm:p-12 text-center">
                  <div className="text-6xl sm:text-7xl md:text-8xl lg:text-9xl font-black mb-4 sm:mb-6">
                    <span className="bg-gradient-to-r from-blue-400 via-blue-500 to-blue-600 bg-clip-text text-transparent">
                      20
                    </span>
                    <span className="text-white">Tbps</span>
                  </div>
                  <p className="text-xl sm:text-2xl md:text-3xl text-blue-300 font-bold mb-2 sm:mb-4">
                    Maximum Protection Capacity
                  </p>
                  <p className="text-base sm:text-lg text-slate-300">
                    Defending against the largest DDoS attacks in the industry
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Protection Features */}
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
              {protectionFeatures.map((feature, index) => (
                <Card
                  key={index}
                  className={`${
                    feature.highlight
                      ? "bg-gradient-to-br from-blue-900/50 to-blue-800/50 border-blue-500/50"
                      : "bg-slate-900/50 border-slate-800/50"
                  } backdrop-blur-sm hover:border-blue-500/30 transition-all duration-300 group`}
                >
                  <CardContent className="p-6 text-center">
                    <div
                      className={`w-12 h-12 sm:w-16 sm:h-16 mx-auto mb-4 sm:mb-6 rounded-full flex items-center justify-center ${
                        feature.highlight ? "bg-blue-500/20" : "bg-slate-800/50"
                      } group-hover:scale-110 transition-transform duration-300`}
                    >
                      <feature.icon
                        className={`w-6 h-6 sm:w-8 sm:h-8 ${feature.highlight ? "text-blue-400" : "text-slate-400"}`}
                      />
                    </div>
                    <h3 className="text-lg sm:text-xl font-bold text-white mb-2 sm:mb-3">{feature.title}</h3>
                    <p className="text-sm sm:text-base text-slate-300">{feature.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Mission Statement */}
        <section className="py-12 sm:py-16 md:py-20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <Card className="bg-gradient-to-br from-slate-900/80 to-slate-800/80 border-slate-700/50 backdrop-blur-sm max-w-4xl mx-auto">
              <CardContent className="p-8 sm:p-12 text-center">
                <h2 className="text-2xl sm:text-3xl md:text-4xl font-black mb-6 sm:mb-8">
                  <span className="bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">
                    Our Mission
                  </span>
                </h2>
                <p className="text-lg sm:text-xl text-slate-300 leading-relaxed">
                  At Avox Hosting, we're committed to providing the most reliable, secure, and high-performance gaming
                  hosting solutions. Our mission is to empower gaming communities worldwide with cutting-edge
                  infrastructure, unmatched protection, and exceptional support that keeps your servers running 24/7.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
