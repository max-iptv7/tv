"use client"

import { Button } from "@/components/ui/button"
import { Cpu, HardDrive, Zap, Globe, ArrowRight, Play } from "lucide-react"
import { useEffect, useRef, useState } from "react"

export function Hero3DSection() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const heroRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (heroRef.current) {
        const rect = heroRef.current.getBoundingClientRect()
        setMousePosition({
          x: (e.clientX - rect.left) / rect.width,
          y: (e.clientY - rect.top) / rect.height,
        })
      }
    }

    const heroElement = heroRef.current
    if (heroElement) {
      heroElement.addEventListener("mousemove", handleMouseMove)
      return () => heroElement.removeEventListener("mousemove", handleMouseMove)
    }
  }, [])

  return (
    <section
      ref={heroRef}
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
      style={{
        background: `
          radial-gradient(circle at ${mousePosition.x * 100}% ${mousePosition.y * 100}%, 
          rgba(59, 130, 246, 0.15) 0%, 
          rgba(147, 51, 234, 0.1) 25%, 
          transparent 50%),
          linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%)
        `,
      }}
    >
      {/* Animated Background Grid */}
      <div className="absolute inset-0 opacity-20">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `
              linear-gradient(rgba(59, 130, 246, 0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(59, 130, 246, 0.1) 1px, transparent 1px)
            `,
            backgroundSize: "50px 50px",
            transform: `translate(${mousePosition.x * 20}px, ${mousePosition.y * 20}px)`,
            transition: "transform 0.3s ease-out",
          }}
        />
      </div>

      {/* Floating 3D Elements */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(15)].map((_, i) => (
          <div
            key={i}
            className="absolute w-4 h-4 bg-gradient-to-br from-blue-400 to-purple-600 rounded-full opacity-60"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `float ${3 + Math.random() * 4}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 2}s`,
              transform: `translateZ(${Math.random() * 100}px)`,
            }}
          />
        ))}
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8 text-center lg:text-left">
            <div className="space-y-6">
              <div className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-full border border-blue-500/30 backdrop-blur-sm">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse mr-2" />
                <span className="text-sm text-blue-300 font-medium">Next-Gen Gaming Infrastructure</span>
              </div>

              <h1 className="text-5xl lg:text-7xl font-black leading-tight">
                <span className="block text-white">Premium</span>
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 animate-gradient">
                  Multi-Game
                </span>
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 animate-gradient">
                  Hosting
                </span>
              </h1>

              <p className="text-xl text-slate-300 leading-relaxed max-w-2xl">
                Experience the future of gaming with{" "}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500 font-semibold">
                  Avox Hosting
                </span>
                . Premium infrastructure for SAMP, MTA, Minecraft, FiveM, Discord Bots, VPS & RDP with cutting-edge
                performance and 24/7 support.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button
                size="lg"
                className="group bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-lg px-8 py-4 rounded-xl shadow-2xl hover:shadow-blue-500/25 transition-all duration-300 transform hover:scale-105"
              >
                <span>Explore Services</span>
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="group border-2 border-slate-700 text-white hover:bg-slate-800/50 text-lg px-8 py-4 rounded-xl backdrop-blur-sm hover:border-blue-500/50 transition-all duration-300 bg-transparent"
              >
                <Play className="mr-2 w-5 h-5" />
                <span>Watch Demo</span>
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 pt-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-white">99.9%</div>
                <div className="text-sm text-slate-400">Uptime</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-white">24/7</div>
                <div className="text-sm text-slate-400">Support</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-white">10K+</div>
                <div className="text-sm text-slate-400">Servers</div>
              </div>
            </div>
          </div>

          {/* 3D Server Visualization */}
          <div className="relative">
            <div className="relative w-full max-w-lg mx-auto">
              {/* Main 3D Server Card */}
              <div
                className="relative bg-gradient-to-br from-slate-900/80 to-slate-800/80 backdrop-blur-xl rounded-3xl p-8 border border-slate-700/50 shadow-2xl transform-gpu"
                style={{
                  transform: `
                    perspective(1000px) 
                    rotateX(${mousePosition.y * 10 - 5}deg) 
                    rotateY(${mousePosition.x * 10 - 5}deg)
                    translateZ(20px)
                  `,
                  transition: "transform 0.3s ease-out",
                }}
              >
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
                        <Cpu className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="font-bold text-white">AMD Ryzen™ 9</h3>
                        <p className="text-sm text-slate-400">7950X3D Gaming</p>
                      </div>
                    </div>
                    <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse" />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/30">
                      <div className="flex items-center space-x-2 mb-2">
                        <HardDrive className="w-4 h-4 text-purple-400" />
                        <span className="text-sm text-slate-300">Storage</span>
                      </div>
                      <div className="text-lg font-bold text-white">NVMe SSD</div>
                      <div className="text-xs text-slate-400">Up to 8TB</div>
                    </div>

                    <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/30">
                      <div className="flex items-center space-x-2 mb-2">
                        <Zap className="w-4 h-4 text-green-400" />
                        <span className="text-sm text-slate-300">Memory</span>
                      </div>
                      <div className="text-lg font-bold text-white">DDR5 RAM</div>
                      <div className="text-xs text-slate-400">Up to 128GB</div>
                    </div>

                    <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/30 col-span-2">
                      <div className="flex items-center space-x-2 mb-2">
                        <Globe className="w-4 h-4 text-orange-400" />
                        <span className="text-sm text-slate-300">Network</span>
                      </div>
                      <div className="text-lg font-bold text-white">10 Gbps Unmetered</div>
                      <div className="text-xs text-slate-400">Global Infrastructure</div>
                    </div>
                  </div>

                  {/* Performance Bars */}
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-slate-300">CPU Performance</span>
                        <span className="text-blue-400">98%</span>
                      </div>
                      <div className="w-full bg-slate-700 rounded-full h-2">
                        <div className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full w-[98%] animate-pulse" />
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-slate-300">Network Speed</span>
                        <span className="text-green-400">99%</span>
                      </div>
                      <div className="w-full bg-slate-700 rounded-full h-2">
                        <div className="bg-gradient-to-r from-green-500 to-emerald-500 h-2 rounded-full w-[99%] animate-pulse" />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Floating Elements */}
                <div className="absolute -top-4 -right-4 w-8 h-8 bg-gradient-to-br from-pink-500 to-red-500 rounded-full animate-bounce" />
                <div className="absolute -bottom-2 -left-2 w-6 h-6 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-full animate-pulse" />
              </div>

              {/* Background Glow */}
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-3xl blur-3xl -z-10 animate-pulse" />
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes float {
          0%,
          100% {
            transform: translateY(0px) translateZ(0px);
          }
          50% {
            transform: translateY(-20px) translateZ(10px);
          }
        }
        @keyframes gradient {
          0%,
          100% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
        }
        .animate-gradient {
          background-size: 200% 200%;
          animation: gradient 3s ease infinite;
        }
      `}</style>
    </section>
  )
}
