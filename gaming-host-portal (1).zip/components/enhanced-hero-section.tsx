"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Cpu, HardDrive, Zap, Globe, ArrowRight, Play, Star, Shield, Clock, Users, Award, Rocket } from "lucide-react"
import { useEffect, useRef, useState } from "react"
import Link from "next/link"

export function EnhancedHeroSection() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const [scrollY, setScrollY] = useState(0)
  const heroRef = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)

    const handleScroll = () => setScrollY(window.scrollY)
    const handleMouseMove = (e: MouseEvent) => {
      if (heroRef.current) {
        const rect = heroRef.current.getBoundingClientRect()
        setMousePosition({
          x: (e.clientX - rect.left) / rect.width,
          y: (e.clientY - rect.top) / rect.height,
        })
      }
    }

    window.addEventListener("scroll", handleScroll)
    const heroElement = heroRef.current
    if (heroElement) {
      heroElement.addEventListener("mousemove", handleMouseMove)
    }

    return () => {
      window.removeEventListener("scroll", handleScroll)
      if (heroElement) {
        heroElement.removeEventListener("mousemove", handleMouseMove)
      }
    }
  }, [])

  return (
    <section
      ref={heroRef}
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20 px-4 sm:px-6 lg:px-8"
      style={{
        background: `
          radial-gradient(circle at ${mousePosition.x * 100}% ${mousePosition.y * 100}%, 
          rgba(59, 130, 246, 0.15) 0%, 
          rgba(147, 51, 234, 0.1) 25%, 
          rgba(236, 72, 153, 0.08) 50%,
          transparent 70%),
          linear-gradient(135deg, #0f172a 0%, #1e293b 30%, #0f172a 70%, #1e293b 100%)
        `,
        transform: `translateY(${scrollY * 0.3}px)`,
      }}
    >
      {/* Simplified Background Grid */}
      <div className="absolute inset-0 opacity-20">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `
              linear-gradient(rgba(59, 130, 246, 0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(59, 130, 246, 0.1) 1px, transparent 1px)
            `,
            backgroundSize: "60px 60px",
            transform: `translate(${mousePosition.x * 20}px, ${mousePosition.y * 20}px)`,
            transition: "transform 0.3s ease-out",
          }}
        />
      </div>

      {/* Floating Elements */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(15)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full opacity-60"
            style={{
              width: `${6 + Math.random() * 12}px`,
              height: `${6 + Math.random() * 12}px`,
              background: `linear-gradient(45deg, 
                ${["#3b82f6", "#8b5cf6", "#ec4899", "#10b981"][Math.floor(Math.random() * 4)]}, 
                ${["#1d4ed8", "#7c3aed", "#db2777", "#059669"][Math.floor(Math.random() * 4)]})`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `float ${4 + Math.random() * 6}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 3}s`,
              boxShadow: `0 0 20px ${["#3b82f6", "#8b5cf6", "#ec4899", "#10b981"][Math.floor(Math.random() * 4)]}40`,
            }}
          />
        ))}
      </div>

      <div className="container mx-auto relative z-10">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 xl:gap-20 items-center">
          <div
            className={`space-y-6 sm:space-y-8 text-center lg:text-left transition-all duration-1000 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
          >
            {/* Trust Badge */}
            <div className="flex flex-wrap justify-center lg:justify-start gap-2 sm:gap-3">
              <Badge className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 text-green-300 border-green-500/30 px-3 py-1.5 text-xs sm:text-sm">
                <Star className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                5-Star Rated
              </Badge>
              <Badge className="bg-gradient-to-r from-blue-500/20 to-cyan-500/20 text-blue-300 border-blue-500/30 px-3 py-1.5 text-xs sm:text-sm">
                <Users className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                50K+ Customers
              </Badge>
              <Badge className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 text-purple-300 border-purple-500/30 px-3 py-1.5 text-xs sm:text-sm">
                <Award className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                Industry Leader
              </Badge>
            </div>

            {/* Main Title */}
            <div className="space-y-3 sm:space-y-4">
              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-black leading-tight">
                <span className="block text-white mb-2">Premium</span>
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 mb-2">
                  Gaming Hosting
                </span>
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-purple-500 via-pink-500 to-red-500">
                  Solutions
                </span>
              </h1>

              <p className="text-base sm:text-lg md:text-xl lg:text-2xl text-slate-300 leading-relaxed max-w-2xl mx-auto lg:mx-0">
                Experience next-generation gaming infrastructure with{" "}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500 font-semibold">
                  Avox Hosting
                </span>
                . Enterprise-grade performance, 24/7 support, and instant deployment for all your gaming needs.
              </p>
            </div>

            {/* Key Features */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 py-4 sm:py-6">
              {[
                { icon: <Shield className="w-4 h-4 sm:w-5 sm:h-5" />, text: "99.99% Uptime", color: "text-green-400" },
                { icon: <Zap className="w-4 h-4 sm:w-5 sm:h-5" />, text: "Instant Setup", color: "text-blue-400" },
                { icon: <Clock className="w-4 h-4 sm:w-5 sm:h-5" />, text: "24/7 Support", color: "text-purple-400" },
              ].map((feature, index) => (
                <div
                  key={index}
                  className="flex items-center justify-center lg:justify-start space-x-2 bg-slate-800/30 px-3 sm:px-4 py-2 sm:py-3 rounded-lg sm:rounded-xl backdrop-blur-sm border border-slate-700/30"
                >
                  <div className={feature.color}>{feature.icon}</div>
                  <span className="text-slate-300 font-medium text-sm sm:text-base">{feature.text}</span>
                </div>
              ))}
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center lg:justify-start">
              <Button
                size="lg"
                className="group bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 hover:from-blue-700 hover:via-purple-700 hover:to-pink-700 text-white text-base sm:text-lg px-6 sm:px-8 py-3 sm:py-4 rounded-lg sm:rounded-xl shadow-2xl hover:shadow-blue-500/25 transition-all duration-300 transform hover:scale-105"
                asChild
              >
                <Link href="https://billing.avoxhosting.com/cart.php">
                  <Rocket className="mr-2 sm:mr-3 w-4 h-4 sm:w-5 sm:h-5" />
                  <span>Start Now</span>
                  <ArrowRight className="ml-2 sm:ml-3 w-4 h-4 sm:w-5 sm:h-5 group-hover:translate-x-1 transition-transform duration-300" />
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="group border-2 border-slate-600 text-slate-300 hover:text-white hover:bg-slate-800/50 text-base sm:text-lg px-6 sm:px-8 py-3 sm:py-4 rounded-lg sm:rounded-xl backdrop-blur-sm hover:border-blue-500/50 transition-all duration-300 bg-transparent"
                asChild
              >
                <Link href="#demo">
                  <Play className="mr-2 sm:mr-3 w-4 h-4 sm:w-5 sm:h-5" />
                  <span>View Demo</span>
                </Link>
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 pt-6 sm:pt-8 border-t border-slate-800/50">
              {[
                { value: "99.99%", label: "Uptime SLA", color: "from-green-400 to-emerald-500" },
                { value: "50K+", label: "Active Servers", color: "from-blue-400 to-cyan-500" },
                { value: "<60s", label: "Setup Time", color: "from-purple-400 to-pink-500" },
              ].map((stat, index) => (
                <div key={index} className="text-center">
                  <div
                    className={`text-2xl sm:text-3xl md:text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r ${stat.color} mb-1 sm:mb-2`}
                  >
                    {stat.value}
                  </div>
                  <div className="text-xs sm:text-sm text-slate-400">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Server Visualization */}
          <div
            className={`relative transition-all duration-1000 delay-300 ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-10"}`}
          >
            <div className="relative w-full max-w-lg mx-auto">
              {/* Main Server Card */}
              <div
                className="relative bg-gradient-to-br from-slate-900/90 to-slate-800/90 backdrop-blur-xl rounded-xl sm:rounded-2xl p-6 sm:p-8 border border-slate-700/50 shadow-2xl"
                style={{
                  transform: `
                    perspective(1000px) 
                    rotateX(${mousePosition.y * 10 - 5}deg) 
                    rotateY(${mousePosition.x * 10 - 5}deg)
                  `,
                  transition: "transform 0.3s ease-out",
                }}
              >
                {/* Header */}
                <div className="flex items-center justify-between mb-4 sm:mb-6">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg sm:rounded-xl flex items-center justify-center">
                      <Cpu className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="font-bold text-white text-sm sm:text-base">AMD Ryzen™ 9</h3>
                      <p className="text-slate-400 text-xs sm:text-sm">Gaming Processor</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 sm:w-3 sm:h-3 bg-green-400 rounded-full animate-pulse" />
                    <span className="text-green-400 text-xs sm:text-sm font-medium">Online</span>
                  </div>
                </div>

                {/* Specs */}
                <div className="grid grid-cols-2 gap-3 sm:gap-4 mb-4 sm:mb-6">
                  {[
                    {
                      icon: <HardDrive className="w-3 h-3 sm:w-4 sm:h-4 text-purple-400" />,
                      label: "NVMe SSD",
                      value: "Up to 8TB",
                    },
                    {
                      icon: <Zap className="w-3 h-3 sm:w-4 sm:h-4 text-green-400" />,
                      label: "DDR5 RAM",
                      value: "Up to 128GB",
                    },
                    {
                      icon: <Globe className="w-3 h-3 sm:w-4 sm:h-4 text-orange-400" />,
                      label: "Network",
                      value: "10 Gbps",
                    },
                    {
                      icon: <Shield className="w-3 h-3 sm:w-4 sm:h-4 text-blue-400" />,
                      label: "DDoS Shield",
                      value: "17Tbps",
                    },
                  ].map((spec, index) => (
                    <div key={index} className="bg-slate-800/50 rounded-lg p-2 sm:p-3 border border-slate-700/30">
                      <div className="flex items-center space-x-1 sm:space-x-2 mb-1">
                        {spec.icon}
                        <span className="text-xs text-slate-400">{spec.label}</span>
                      </div>
                      <div className="text-xs sm:text-sm font-semibold text-white">{spec.value}</div>
                    </div>
                  ))}
                </div>

                {/* Performance Metrics */}
                <div className="space-y-2 sm:space-y-3">
                  {[
                    { label: "CPU Usage", value: 23, color: "from-blue-500 to-purple-500" },
                    { label: "Memory", value: 67, color: "from-green-500 to-emerald-500" },
                    { label: "Network", value: 45, color: "from-orange-500 to-red-500" },
                  ].map((metric, index) => (
                    <div key={index}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-slate-400">{metric.label}</span>
                        <span className="text-slate-300">{metric.value}%</span>
                      </div>
                      <div className="w-full bg-slate-700/50 rounded-full h-1.5 sm:h-2">
                        <div
                          className={`bg-gradient-to-r ${metric.color} h-1.5 sm:h-2 rounded-full transition-all duration-1000`}
                          style={{ width: `${metric.value}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Floating Elements */}
              <div className="absolute -top-3 -right-3 sm:-top-4 sm:-right-4 w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-br from-pink-500 to-red-500 rounded-lg animate-bounce" />
              <div className="absolute -bottom-2 -left-2 sm:-bottom-3 sm:-left-3 w-4 h-4 sm:w-6 sm:h-6 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-lg animate-pulse" />

              {/* Glow Effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 via-purple-600/20 to-pink-600/20 rounded-xl sm:rounded-2xl blur-2xl -z-10" />
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes float {
          0%, 100% {
            transform: translateY(0px) rotate(0deg);
          }
          50% {
            transform: translateY(-20px) rotate(180deg);
          }
        }
      `}</style>
    </section>
  )
}
