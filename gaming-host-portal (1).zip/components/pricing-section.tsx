import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, Server } from "lucide-react"

export function PricingSection() {
  const plans = [
    {
      name: "Minecraft Server",
      service: "Minecraft Hosting",
      specs: "2GB RAM • 2 vCPU • 20GB SSD",
      players: "Up to 20 Players",
      price: "€4.99",
      period: "/mo",
      popular: false,
      features: [
        "All Minecraft Versions",
        "Plugin Support",
        "Automatic Backups",
        "DDoS Protection",
        "24/7 Support",
        "Instant Setup",
      ],
    },
    {
      name: "FiveM Server",
      service: "GTA V Roleplay",
      specs: "4GB RAM • 4 vCPU • 40GB SSD",
      players: "Up to 64 Players",
      price: "€8.99",
      period: "/mo",
      popular: true,
      features: [
        "ESX/QBCore Ready",
        "txAdmin Panel",
        "Custom Resources",
        "Database Included",
        "24/7 Support",
        "Instant Setup",
      ],
    },
    {
      name: "Premium VPS",
      service: "Multi-Purpose Server",
      specs: "8GB RAM • 6 vCPU • 80GB NVMe",
      players: "Unlimited Usage",
      price: "€24.99",
      period: "/mo",
      popular: false,
      features: [
        "Full Root Access",
        "Multiple OS Support",
        "DDoS Protection",
        "NVMe SSD Storage",
        "24/7 Support",
        "Instant Setup",
      ],
    },
  ]

  return (
    <section id="pricing" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4 text-white">Popular Gaming Plans</h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto mb-6"></div>
          <p className="text-xl text-slate-300 max-w-4xl mx-auto">
            Choose from our most popular gaming server plans. All plans include DDoS protection, 24/7 support, and
            instant setup.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <Card
              key={index}
              className={`relative bg-slate-900/50 border-slate-800 hover:border-slate-700 transition-all duration-300 ${
                plan.popular ? "ring-2 ring-blue-500 scale-105" : ""
              }`}
            >
              {plan.popular && (
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-green-600 text-white">
                  Available
                </Badge>
              )}

              <CardHeader className="text-center">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Server className="w-6 h-6 text-white" />
                </div>
                <CardTitle className="text-white text-xl">{plan.name}</CardTitle>
                <p className="text-slate-400">{plan.service}</p>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="text-center py-4">
                  <span className="text-3xl font-bold text-white">{plan.price}</span>
                  <span className="text-slate-400">{plan.period}</span>
                </div>

                <div className="text-center space-y-2">
                  <p className="text-slate-300 font-semibold">{plan.specs}</p>
                  <p className="text-slate-400 text-sm">{plan.players}</p>
                </div>

                <div className="space-y-2 pt-4">
                  {plan.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-center space-x-2">
                      <Check className="w-4 h-4 text-green-400" />
                      <span className="text-slate-300 text-sm">{feature}</span>
                    </div>
                  ))}
                </div>
              </CardContent>

              <CardFooter>
                <Button className="w-full bg-blue-600 hover:bg-blue-700">Order Now</Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
