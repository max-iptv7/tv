import Link from "next/link"

export function Footer() {
  return (
    <footer className="bg-slate-950 border-t border-slate-800 py-16">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-8">
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">AH</span>
              </div>
              <span className="font-bold text-xl text-white">Avox Hosting</span>
            </div>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4 border-b border-blue-600 pb-2 inline-block">Services</h3>
            <ul className="space-y-2 text-slate-400">
              <li>
                <Link href="/samp" className="hover:text-blue-400 transition-colors">
                  SA-MP Servers
                </Link>
              </li>
              <li>
                <Link href="/minecraft" className="hover:text-blue-400 transition-colors">
                  Minecraft Servers
                </Link>
              </li>
              <li>
                <Link href="/fivem" className="hover:text-blue-400 transition-colors">
                  FiveM Servers
                </Link>
              </li>
              <li>
                <Link href="/vps" className="hover:text-blue-400 transition-colors">
                  VPS Hosting
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4 border-b border-blue-600 pb-2 inline-block">Company</h3>
            <ul className="space-y-2 text-slate-400">
              <li>
                <Link href="/about" className="hover:text-blue-400 transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-blue-400 transition-colors">
                  Contact
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-blue-400 transition-colors">
                  Careers
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-blue-400 transition-colors">
                  News
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4 border-b border-blue-600 pb-2 inline-block">Support</h3>
            <ul className="space-y-2 text-slate-400">
              <li>
                <Link
                  href="https://billing.avoxhosting.com/contact.php"
                  className="hover:text-blue-400 transition-colors"
                >
                  Open Ticket
                </Link>
              </li>
              <li>
                <Link href="mailto:support@avoxhosting.com" className="hover:text-blue-400 transition-colors">
                  Email Us
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-blue-400 transition-colors">
                  Discord
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-blue-400 transition-colors">
                  Knowledge Base
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4 border-b border-blue-600 pb-2 inline-block">Legal</h3>
            <ul className="space-y-2 text-slate-400">
              <li>
                <Link href="#" className="hover:text-blue-400 transition-colors">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-blue-400 transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-blue-400 transition-colors">
                  Refund Policy
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-blue-400 transition-colors">
                  SLA
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-slate-800">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-slate-400 text-sm">© 2025 Avox Hosting. All rights reserved.</p>

            <div className="text-center">
              <p className="text-white font-semibold mb-3">We Accept</p>
              <div className="flex items-center space-x-4">
                <div className="bg-slate-800 px-3 py-2 rounded text-white text-sm font-semibold">VISA</div>
                <div className="bg-blue-600 px-3 py-2 rounded text-white text-sm font-semibold">PayPal</div>
                <div className="bg-gradient-to-r from-orange-500 to-red-500 px-3 py-2 rounded text-white text-sm font-semibold">
                  mastercard
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
