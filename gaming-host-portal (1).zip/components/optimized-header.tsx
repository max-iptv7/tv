"use client"

import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import Link from "next/link"
import Image from "next/image"
import { Menu, X, ChevronDown, Shield, Clock, User, Gamepad2 } from "lucide-react"
import { useState, useEffect } from "react"

export function OptimizedHeader() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const services = [
    { name: "SA-MP Servers", href: "/samp", icon: "🏎️" },
    { name: "MTA Servers", href: "/mta", icon: "🎮" },
    { name: "Minecraft Servers", href: "/minecraft", icon: "⛏️" },
    { name: "FiveM Servers", href: "/fivem", icon: "🚗" },
    { name: "Discord Bots", href: "/discord-bots", icon: "🤖" },
    { name: "VPS Hosting", href: "/vps", icon: "💻" },
    { name: "RDP Servers", href: "/rdp", icon: "🖥️" },
  ]

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-slate-950/95 backdrop-blur-md border-b border-slate-800/50" : "bg-transparent"
      }`}
    >
      <div className="container mx-auto px-4">
        {/* Top Status Bar - Desktop Only */}
        <div className="hidden md:flex items-center justify-between py-2 text-xs border-b border-slate-800/30">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-400 rounded-full" />
              <span className="text-green-400">All Systems Online</span>
            </div>
            <div className="flex items-center space-x-2">
              <Shield className="w-3 h-3 text-orange-400" />
              <span className="text-slate-400">99.9% Uptime</span>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="w-3 h-3 text-red-400" />
              <span className="text-slate-400">24/7 Support</span>
            </div>
          </div>
          <div className="flex items-center space-x-4 text-slate-400">
            <Link href="#" className="hover:text-orange-400 transition-colors">
              Status
            </Link>
            <Link href="#" className="hover:text-orange-400 transition-colors">
              Support
            </Link>
            <Link href="#" className="hover:text-orange-400 transition-colors">
              Docs
            </Link>
          </div>
        </div>

        {/* Main Header */}
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-3">
            <div className="w-10 h-10 relative">
              <Image
                src="/images/avox-logo.png"
                alt="Avox Hosting"
                width={40}
                height={40}
                className="w-full h-full object-contain"
              />
            </div>
            <div className="hidden sm:block">
              <div className="font-bold text-xl bg-gradient-to-r from-orange-400 to-red-500 bg-clip-text text-transparent">
                Avox Hosting
              </div>
              <div className="text-xs text-slate-400 -mt-1">Premium Gaming</div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-6">
            <Link href="/" className="text-white hover:text-orange-400 transition-colors font-medium">
              Home
            </Link>

            <DropdownMenu>
              <DropdownMenuTrigger className="flex items-center space-x-1 text-slate-300 hover:text-white transition-colors font-medium">
                <span>Services</span>
                <ChevronDown className="w-4 h-4" />
              </DropdownMenuTrigger>
              <DropdownMenuContent className="bg-slate-900/95 backdrop-blur-md border-slate-700 shadow-xl rounded-lg p-2 min-w-[280px]">
                {services.map((service) => (
                  <DropdownMenuItem key={service.href} asChild>
                    <Link
                      href={service.href}
                      className="flex items-center space-x-3 px-3 py-2 text-slate-300 hover:text-white hover:bg-slate-800/50 rounded-md transition-colors"
                    >
                      <span className="text-lg">{service.icon}</span>
                      <span>{service.name}</span>
                    </Link>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <Link href="#pricing" className="text-slate-300 hover:text-white transition-colors font-medium">
              Pricing
            </Link>
            <Link href="/about" className="text-slate-300 hover:text-white transition-colors font-medium">
              About
            </Link>
            <Link href="/contact" className="text-slate-300 hover:text-white transition-colors font-medium">
              Contact
            </Link>
          </nav>

          {/* Login Dropdown */}
          <div className="hidden lg:flex items-center">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-medium px-4">
                  <User className="w-4 h-4 mr-2" />
                  Login
                  <ChevronDown className="w-4 h-4 ml-2" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="bg-slate-900/95 backdrop-blur-md border-slate-700 shadow-xl rounded-lg p-2 min-w-[200px]">
                <DropdownMenuItem asChild>
                  <Link
                    href="https://billing.avoxhosting.com/clientarea.php"
                    className="flex items-center space-x-3 px-3 py-3 text-slate-300 hover:text-white hover:bg-slate-800/50 rounded-md transition-colors"
                  >
                    <User className="w-4 h-4 text-orange-400" />
                    <div>
                      <div className="font-medium">Client Area</div>
                      <div className="text-xs text-slate-400">Billing & Support</div>
                    </div>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link
                    href="https://panel.avoxhosting.com"
                    className="flex items-center space-x-3 px-3 py-3 text-slate-300 hover:text-white hover:bg-slate-800/50 rounded-md transition-colors"
                  >
                    <Gamepad2 className="w-4 h-4 text-red-400" />
                    <div>
                      <div className="font-medium">Game Panel</div>
                      <div className="text-xs text-slate-400">Server Management</div>
                    </div>
                  </Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden text-white p-2 hover:bg-slate-800/50 rounded-lg transition-colors"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="lg:hidden bg-slate-950/98 backdrop-blur-md border-t border-slate-800/50 absolute top-full left-0 right-0">
          <div className="px-6 py-6">
            {/* Navigation */}
            <div className="space-y-2 mb-6">
              <Link
                href="/"
                className="block py-2 px-3 text-white font-medium hover:bg-slate-800/50 rounded-lg transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Home
              </Link>
              <Link
                href="#pricing"
                className="block py-2 px-3 text-slate-300 hover:bg-slate-800/50 rounded-lg transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Pricing
              </Link>
              <Link
                href="/about"
                className="block py-2 px-3 text-slate-300 hover:bg-slate-800/50 rounded-lg transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                About
              </Link>
              <Link
                href="/contact"
                className="block py-2 px-3 text-slate-300 hover:bg-slate-800/50 rounded-lg transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Contact
              </Link>
            </div>

            {/* Services */}
            <div className="mb-6">
              <h3 className="text-slate-400 text-sm font-medium mb-3">Services</h3>
              <div className="space-y-2">
                {services.map((service) => (
                  <Link
                    key={service.href}
                    href={service.href}
                    className="flex items-center space-x-3 p-3 rounded-lg bg-slate-900/50 border border-slate-800/50 hover:border-orange-500/30 transition-colors"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    <span className="text-xl">{service.icon}</span>
                    <span className="text-white font-medium">{service.name}</span>
                  </Link>
                ))}
              </div>
            </div>

            {/* Login Options */}
            <div className="space-y-3 pt-4 border-t border-slate-800">
              <Link
                href="https://billing.avoxhosting.com/clientarea.php"
                className="flex items-center space-x-3 p-3 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-lg font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                <User className="w-5 h-5" />
                <div>
                  <div>Client Area</div>
                  <div className="text-xs opacity-90">Billing & Support</div>
                </div>
              </Link>
              <Link
                href="https://panel.avoxhosting.com"
                className="flex items-center space-x-3 p-3 bg-slate-800 text-white rounded-lg font-medium hover:bg-slate-700 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                <Gamepad2 className="w-5 h-5" />
                <div>
                  <div>Game Panel</div>
                  <div className="text-xs text-slate-400">Server Management</div>
                </div>
              </Link>
            </div>
          </div>
        </div>
      )}
    </header>
  )
}
