"use client"

import { ResponsiveHeader } from "@/components/responsive-header"
import { ResponsiveHeroSection } from "@/components/responsive-hero-section"
import { ServicesSection } from "@/components/services-section"
import { FeaturesSection } from "@/components/features-section"
import { PricingSection } from "@/components/pricing-section"
import { Footer } from "@/components/footer"
import { ResponsiveLoadingScreen } from "@/components/responsive-loading-screen"
import { SimpleSnowSystem } from "@/components/simple-snow-system"
import { useState, useEffect } from "react"

export default function HomePage() {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 2000)

    return () => clearTimeout(timer)
  }, [])

  if (isLoading) {
    return <ResponsiveLoadingScreen />
  }

  return (
    <div className="min-h-screen bg-slate-950 text-white overflow-x-hidden">
      <SimpleSnowSystem />
      <ResponsiveHeader />

      <main className="relative z-10">
        <ResponsiveHeroSection />
        <ServicesSection />
        <FeaturesSection />
        <PricingSection />
      </main>

      <Footer />
    </div>
  )
}
