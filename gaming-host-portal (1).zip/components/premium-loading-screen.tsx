"use client"

import { useEffect, useState } from "react"
import { Zap, Server, Globe, Shield, Crown } from "lucide-react"

interface PremiumLoadingScreenProps {
  onLoadingComplete: () => void
}

export function PremiumLoadingScreen({ onLoadingComplete }: PremiumLoadingScreenProps) {
  const [progress, setProgress] = useState(0)
  const [currentStep, setCurrentStep] = useState(0)
  const [showLogo, setShowLogo] = useState(false)

  const loadingSteps = [
    { icon: <Server className="w-10 h-10" />, text: "Initializing Premium Infrastructure", color: "text-blue-400" },
    { icon: <Globe className="w-10 h-10" />, text: "Connecting Global Network", color: "text-emerald-400" },
    { icon: <Shield className="w-10 h-10" />, text: "Activating Security Protocols", color: "text-purple-400" },
    { icon: <Zap className="w-10 h-10" />, text: "Optimizing Performance", color: "text-amber-400" },
  ]

  useEffect(() => {
    setShowLogo(true)

    const timer = setInterval(() => {
      setProgress((prev) => {
        const newProgress = prev + 0.8

        const stepIndex = Math.floor((newProgress / 100) * loadingSteps.length)
        setCurrentStep(Math.min(stepIndex, loadingSteps.length - 1))

        if (newProgress >= 100) {
          clearInterval(timer)
          setTimeout(onLoadingComplete, 1000)
          return 100
        }
        return newProgress
      })
    }, 40)

    return () => clearInterval(timer)
  }, [onLoadingComplete, loadingSteps.length])

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center z-50 overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 via-purple-600/10 to-pink-600/10 animate-pulse" />

        {/* Floating Orbs */}
        {[...Array(12)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full opacity-20 animate-pulse"
            style={{
              width: `${20 + Math.random() * 40}px`,
              height: `${20 + Math.random() * 40}px`,
              background: `radial-gradient(circle, ${
                ["#3b82f6", "#8b5cf6", "#ec4899", "#10b981", "#f59e0b"][Math.floor(Math.random() * 5)]
              }, transparent)`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${3 + Math.random() * 4}s`,
            }}
          />
        ))}
      </div>

      <div className="text-center relative z-10 max-w-md mx-auto px-6">
        {/* Premium Logo */}
        <div
          className={`relative mb-12 transition-all duration-1000 ${showLogo ? "opacity-100 scale-100" : "opacity-0 scale-95"}`}
        >
          <div className="relative">
            <div className="w-32 h-32 mx-auto relative">
              {/* Rotating Ring */}
              <div
                className="absolute inset-0 rounded-full border-2 border-gradient-to-r from-blue-500 via-purple-500 to-pink-500 animate-spin"
                style={{ animationDuration: "3s" }}
              />

              {/* Inner Logo */}
              <div className="absolute inset-4 bg-gradient-to-br from-blue-600 to-purple-700 rounded-full flex items-center justify-center shadow-2xl">
                <Crown className="w-12 h-12 text-white" />
              </div>

              {/* Glow Effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600/30 to-purple-600/30 rounded-full blur-xl animate-pulse" />
            </div>
          </div>
        </div>

        {/* Brand Name */}
        <div className="mb-8">
          <h1 className="text-4xl font-black mb-2">
            <span className="bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
              Avox Hosting
            </span>
          </h1>
          <p className="text-slate-400 text-lg font-medium">Premium Gaming Infrastructure</p>
        </div>

        {/* Loading Step */}
        <div className="mb-12">
          <div className="flex items-center justify-center space-x-4 mb-6">
            <div className={`${loadingSteps[currentStep]?.color || "text-blue-400"} transition-all duration-500`}>
              {loadingSteps[currentStep]?.icon}
            </div>
            <div>
              <div className="text-white font-semibold text-xl">{loadingSteps[currentStep]?.text || "Loading..."}</div>
              <div className="text-slate-400 text-sm">Please wait...</div>
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="relative">
            <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 transition-all duration-300 ease-out relative"
                style={{ width: `${progress}%` }}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-pulse" />
              </div>
            </div>
            <div
              className="absolute -top-1 -bottom-1 bg-gradient-to-r from-blue-500/50 to-purple-500/50 rounded-full blur-sm"
              style={{ width: `${progress}%`, transition: "width 0.3s ease-out" }}
            />
          </div>

          <div className="flex justify-between items-center mt-3">
            <span className="text-slate-400 text-sm">Loading...</span>
            <span className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              {Math.round(progress)}%
            </span>
          </div>
        </div>

        {/* Loading Dots */}
        <div className="flex justify-center space-x-2">
          {[...Array(3)].map((_, i) => (
            <div
              key={i}
              className="w-3 h-3 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full animate-bounce"
              style={{ animationDelay: `${i * 0.2}s` }}
            />
          ))}
        </div>

        {/* Status */}
        <div className="mt-8 flex items-center justify-center space-x-2">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
          <span className="text-green-400 text-sm font-medium">Secure Connection Established</span>
        </div>
      </div>
    </div>
  )
}
