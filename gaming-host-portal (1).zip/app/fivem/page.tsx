import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, Users, Zap, Database, Settings, Car } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import Link from "next/link"

export default function FiveMPage() {
  const plans = [
    {
      name: "FiveM Starter",
      players: "32 Players",
      ram: "2 GB",
      cpu: "2 vCPU",
      storage: "20 GB SSD",
      price: "€8.99",
      popular: false,
      productId: "31",
      features: [
        "ESX/QBCore Ready",
        "txAdmin Panel",
        "DDoS Protection",
        "24/7 Support",
        "MySQL Database",
        "Auto Restart",
      ],
    },
    {
      name: "FiveM Basic",
      players: "48 Players",
      ram: "4 GB",
      cpu: "3 vCPU",
      storage: "40 GB SSD",
      price: "€14.99",
      popular: false,
      productId: "32",
      features: [
        "ESX/QBCore Ready",
        "txAdmin Panel",
        "DDoS Protection",
        "24/7 Support",
        "MySQL Database",
        "Auto Restart",
        "Custom Resources",
      ],
    },
    {
      name: "FiveM Standard",
      players: "64 Players",
      ram: "6 GB",
      cpu: "4 vCPU",
      storage: "60 GB SSD",
      price: "€22.99",
      popular: true,
      productId: "33",
      features: [
        "ESX/QBCore Ready",
        "txAdmin Panel",
        "DDoS Protection",
        "24/7 Support",
        "MySQL Database",
        "Auto Restart",
        "Custom Resources",
        "Priority Support",
      ],
    },
    {
      name: "FiveM Advanced",
      players: "96 Players",
      ram: "8 GB",
      cpu: "5 vCPU",
      storage: "80 GB SSD",
      price: "€32.99",
      popular: false,
      productId: "34",
      features: [
        "ESX/QBCore Ready",
        "txAdmin Panel",
        "DDoS Protection",
        "24/7 Support",
        "MySQL Database",
        "Auto Restart",
        "Custom Resources",
        "Priority Support",
        "Dedicated IP",
      ],
    },
    {
      name: "FiveM Professional",
      players: "128 Players",
      ram: "12 GB",
      cpu: "6 vCPU",
      storage: "120 GB SSD",
      price: "€44.99",
      popular: false,
      productId: "35",
      features: [
        "ESX/QBCore Ready",
        "txAdmin Panel",
        "DDoS Protection",
        "24/7 Support",
        "MySQL Database",
        "Auto Restart",
        "Custom Resources",
        "Priority Support",
        "Dedicated IP",
        "Custom Setup",
      ],
    },
    {
      name: "FiveM Enterprise",
      players: "200 Players",
      ram: "16 GB",
      cpu: "8 vCPU",
      storage: "160 GB SSD",
      price: "€64.99",
      popular: false,
      productId: "36",
      features: [
        "ESX/QBCore Ready",
        "txAdmin Panel",
        "DDoS Protection",
        "24/7 Support",
        "MySQL Database",
        "Auto Restart",
        "Custom Resources",
        "Priority Support",
        "Dedicated IP",
        "Custom Setup",
        "Dedicated Support",
      ],
    },
  ]

  const features = [
    {
      icon: <Car className="w-6 h-6 sm:w-8 sm:h-8 text-purple-400" />,
      title: "Framework Ready",
      description: "Pre-configured with ESX, QBCore, and other popular frameworks for instant roleplay setup.",
    },
    {
      icon: <Settings className="w-6 h-6 sm:w-8 sm:h-8 text-blue-400" />,
      title: "txAdmin Panel",
      description:
        "Full txAdmin control panel for easy server management, player administration, and resource control.",
    },
    {
      icon: <Database className="w-6 h-6 sm:w-8 sm:h-8 text-green-400" />,
      title: "Database Included",
      description: "MySQL database included with all plans for storing player data, vehicles, and server information.",
    },
    {
      icon: <Zap className="w-6 h-6 sm:w-8 sm:h-8 text-yellow-400" />,
      title: "Custom Resources",
      description: "Support for custom scripts, maps, vehicles, and resources to create unique roleplay experiences.",
    },
  ]

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <Header />

      <main className="pt-16">
        {/* Hero Section */}
        <section className="py-12 sm:py-20 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12 sm:mb-16">
              <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Users className="w-8 h-8 sm:w-10 sm:h-10 text-white" />
              </div>
              <h1 className="text-3xl sm:text-4xl lg:text-6xl font-bold mb-6">
                FiveM <span className="text-purple-400">Server Hosting</span>
              </h1>
              <p className="text-base sm:text-xl text-slate-300 max-w-4xl mx-auto leading-relaxed px-4">
                Premium FiveM server hosting optimized for GTA V roleplay communities. Pre-configured with ESX, QBCore,
                and txAdmin panel for easy management. Perfect for serious roleplay servers with custom resources,
                vehicles, and scripts. Get your FiveM server online with high performance, MySQL database, and 24/7
                support.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 max-w-6xl mx-auto">
              {features.map((feature, index) => (
                <Card
                  key={index}
                  className="bg-slate-900/50 border-slate-800 hover:border-purple-500/50 transition-all duration-300"
                >
                  <CardHeader className="text-center p-4 sm:p-6">
                    <div className="mb-3 sm:mb-4">{feature.icon}</div>
                    <CardTitle className="text-white text-base sm:text-lg">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="p-4 sm:p-6 pt-0">
                    <p className="text-slate-300 text-sm text-center">{feature.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Pricing Section */}
        <section className="py-12 sm:py-20">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12 sm:mb-16">
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold mb-4">FiveM Hosting Plans</h2>
              <div className="w-24 h-1 bg-purple-500 mx-auto mb-6"></div>
              <p className="text-base sm:text-xl text-slate-300 max-w-3xl mx-auto px-4">
                Choose the perfect FiveM hosting plan for your roleplay server. All plans include txAdmin, MySQL
                database, and framework support.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
              {plans.map((plan, index) => (
                <Card
                  key={index}
                  className={`relative bg-slate-900/50 border-slate-800 hover:border-slate-700 transition-all duration-300 ${
                    plan.popular ? "ring-2 ring-purple-500 scale-105" : ""
                  }`}
                >
                  {plan.popular && (
                    <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-purple-600 text-white text-xs sm:text-sm">
                      Most Popular
                    </Badge>
                  )}

                  <CardHeader className="text-center p-4 sm:p-6">
                    <CardTitle className="text-white text-lg sm:text-xl">{plan.name}</CardTitle>
                    <div className="text-2xl sm:text-3xl font-bold text-white mt-4">
                      {plan.price}
                      <span className="text-slate-400 text-base sm:text-lg font-normal">/month</span>
                    </div>
                    <p className="text-purple-400 font-semibold text-sm sm:text-base">{plan.players}</p>
                  </CardHeader>

                  <CardContent className="space-y-4 p-4 sm:p-6">
                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div>
                        <p className="text-slate-400 text-xs">RAM</p>
                        <p className="text-white font-semibold text-xs sm:text-sm">{plan.ram}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-xs">CPU</p>
                        <p className="text-white font-semibold text-xs sm:text-sm">{plan.cpu}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-xs">Storage</p>
                        <p className="text-white font-semibold text-xs sm:text-sm">{plan.storage}</p>
                      </div>
                    </div>

                    <div className="space-y-2 pt-4">
                      {plan.features.map((feature, featureIndex) => (
                        <div key={featureIndex} className="flex items-center space-x-2">
                          <Check className="w-3 h-3 sm:w-4 sm:h-4 text-green-400 flex-shrink-0" />
                          <span className="text-slate-300 text-xs sm:text-sm">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>

                  <CardFooter className="p-4 sm:p-6">
                    <Button className="w-full bg-purple-600 hover:bg-purple-700 py-3 text-sm sm:text-base" asChild>
                      <Link href={`https://billing.avoxhosting.com/cart.php?a=add&pid=${plan.productId}`}>
                        Order Now
                      </Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
