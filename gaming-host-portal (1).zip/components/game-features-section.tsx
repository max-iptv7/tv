import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Shield, Zap, Clock, Headphones, Server, Globe, Database, Settings, Users } from "lucide-react"

export function GameFeaturesSection() {
  const features = [
    {
      icon: <Shield className="w-12 h-12 text-red-400" />,
      title: "Advanced DDoS Protection",
      description:
        "Enterprise-level protection against DDoS attacks up to 17Tbps, keeping your game servers online 24/7.",
      borderColor: "border-red-500/30",
    },
    {
      icon: <Zap className="w-12 h-12 text-yellow-400" />,
      title: "High-Performance Hardware",
      description:
        "AMD Ryzen 9 processors with NVMe SSD storage and DDR5 RAM for lightning-fast game server performance.",
      borderColor: "border-yellow-500/30",
    },
    {
      icon: <Clock className="w-12 h-12 text-green-400" />,
      title: "Instant Deployment",
      description:
        "Get your game servers up and running within minutes of payment confirmation with our automated setup.",
      borderColor: "border-green-500/30",
    },
    {
      icon: <Headphones className="w-12 h-12 text-blue-400" />,
      title: "24/7 Expert Support",
      description:
        "Our gaming specialists are available around the clock to help with any technical issues or questions.",
      borderColor: "border-blue-500/30",
    },
    {
      icon: <Database className="w-12 h-12 text-purple-400" />,
      title: "Automatic Backups",
      description: "Daily automated backups ensure your game data is always safe and can be restored when needed.",
      borderColor: "border-purple-500/30",
    },
    {
      icon: <Settings className="w-12 h-12 text-orange-400" />,
      title: "Full Control Panel",
      description: "Easy-to-use control panels for managing your servers, installing mods, and configuring settings.",
      borderColor: "border-orange-500/30",
    },
    {
      icon: <Globe className="w-12 h-12 text-cyan-400" />,
      title: "Global Locations",
      description: "Multiple server locations worldwide to ensure low latency for players in different regions.",
      borderColor: "border-cyan-500/30",
    },
    {
      icon: <Users className="w-12 h-12 text-pink-400" />,
      title: "Scalable Solutions",
      description: "Easily upgrade your server resources as your community grows without any downtime.",
      borderColor: "border-pink-500/30",
    },
    {
      icon: <Server className="w-12 h-12 text-indigo-400" />,
      title: "99.9% Uptime Guarantee",
      description: "Reliable infrastructure with redundant systems ensuring maximum uptime for your game servers.",
      borderColor: "border-indigo-500/30",
    },
  ]

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4 text-white">Why Choose Leora-Host for Gaming?</h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto mb-6"></div>
          <p className="text-xl text-slate-300 max-w-4xl mx-auto">
            We specialize in gaming server hosting with features designed specifically for gamers and server
            administrators
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card
              key={index}
              className={`bg-slate-900/30 border ${feature.borderColor} hover:bg-slate-900/50 transition-all duration-300 group`}
            >
              <CardHeader>
                <div className="mb-4 group-hover:scale-110 transition-transform duration-300">{feature.icon}</div>
                <CardTitle className="text-white text-xl">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-300 leading-relaxed">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
