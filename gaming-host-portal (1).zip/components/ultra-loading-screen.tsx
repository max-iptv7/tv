"use client"

import { useEffect, useState } from "react"
import { Server, Zap, Shield, Globe, Crown } from "lucide-react"
import Image from "next/image"

interface UltraLoadingScreenProps {
  onLoadingComplete: () => void
}

export function UltraLoadingScreen({ onLoadingComplete }: UltraLoadingScreenProps) {
  const [progress, setProgress] = useState(0)
  const [currentPhase, setCurrentPhase] = useState(0)
  const [glitchEffect, setGlitchEffect] = useState(false)

  const phases = [
    { icon: <Server className="w-10 h-10" />, text: "Initializing Gaming Servers", color: "text-cyan-400" },
    { icon: <Shield className="w-10 h-10" />, text: "Activating DDoS Protection", color: "text-emerald-400" },
    { icon: <Globe className="w-10 h-10" />, text: "Connecting Global Network", color: "text-blue-400" },
    { icon: <Zap className="w-10 h-10" />, text: "Optimizing Performance", color: "text-yellow-400" },
    { icon: <Crown className="w-10 h-10" />, text: "Welcome to Premium Gaming", color: "text-purple-400" },
  ]

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        const newProgress = prev + 2

        // Update phase based on progress
        const phaseIndex = Math.floor((newProgress / 100) * phases.length)
        setCurrentPhase(Math.min(phaseIndex, phases.length - 1))

        // Add glitch effect near completion
        if (newProgress > 85 && newProgress < 95) {
          setGlitchEffect(true)
          setTimeout(() => setGlitchEffect(false), 200)
        }

        if (newProgress >= 100) {
          clearInterval(timer)
          setTimeout(onLoadingComplete, 800)
          return 100
        }
        return newProgress
      })
    }, 50)

    return () => clearInterval(timer)
  }, [onLoadingComplete, phases.length])

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center z-50 overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-r from-orange-500/10 via-red-500/10 to-purple-500/10 animate-pulse" />

        {/* Floating Particles */}
        {[...Array(30)].map((_, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 bg-gradient-to-r from-orange-400 to-red-500 rounded-full opacity-60"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `float ${3 + Math.random() * 4}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 2}s`,
            }}
          />
        ))}

        {/* Grid Pattern */}
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `
              linear-gradient(rgba(249, 115, 22, 0.5) 1px, transparent 1px),
              linear-gradient(90deg, rgba(249, 115, 22, 0.5) 1px, transparent 1px)
            `,
            backgroundSize: "40px 40px",
            animation: "gridMove 20s linear infinite",
          }}
        />
      </div>

      <div className="relative z-10 text-center max-w-md mx-auto px-6">
        {/* Logo with Glow Effect */}
        <div className="mb-8 relative">
          <div className="w-32 h-32 mx-auto relative">
            <div className="absolute inset-0 bg-gradient-to-r from-orange-500 to-red-500 rounded-full blur-2xl opacity-50 animate-pulse" />
            <div className="relative w-full h-full bg-slate-900 rounded-full border-4 border-gradient-to-r from-orange-500 to-red-500 flex items-center justify-center">
              <Image
                src="/images/avox-logo.png"
                alt="Avox Hosting"
                width={80}
                height={80}
                className={`w-20 h-20 object-contain transition-all duration-300 ${glitchEffect ? "filter hue-rotate-180" : ""}`}
              />
            </div>
          </div>
        </div>

        {/* Brand Name with Glitch Effect */}
        <div className="mb-12">
          <h1
            className={`text-4xl font-black mb-3 transition-all duration-200 ${glitchEffect ? "transform skew-x-2" : ""}`}
          >
            <span className="bg-gradient-to-r from-orange-400 via-red-500 to-purple-500 bg-clip-text text-transparent">
              AVOX HOSTING
            </span>
          </h1>
          <p className="text-slate-400 text-xl font-medium">
            <span className="text-cyan-400">PREMIUM</span> GAMING INFRASTRUCTURE
          </p>
        </div>

        {/* Current Phase */}
        <div className="mb-8">
          <div className="flex items-center justify-center space-x-4 mb-4">
            <div
              className={`${phases[currentPhase]?.color || "text-orange-400"} transition-all duration-500 transform ${glitchEffect ? "scale-110" : "scale-100"}`}
            >
              {phases[currentPhase]?.icon}
            </div>
            <div className="text-white font-bold text-xl">{phases[currentPhase]?.text || "Loading..."}</div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
            <div
              className="h-full bg-gradient-to-r from-orange-500 via-red-500 to-purple-500 transition-all duration-300 ease-out relative"
              style={{ width: `${progress}%` }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-pulse" />
              <div className="absolute right-0 top-0 w-4 h-full bg-white/50 blur-sm" />
            </div>
          </div>
          <div className="flex justify-between items-center mt-3">
            <span className="text-slate-400 text-sm font-medium">Initializing...</span>
            <span className="text-2xl font-black bg-gradient-to-r from-orange-400 to-red-500 bg-clip-text text-transparent">
              {Math.round(progress)}%
            </span>
          </div>
        </div>

        {/* Status Indicators */}
        <div className="flex justify-center space-x-6">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse" />
            <span className="text-green-400 text-sm font-medium">Secure</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-blue-400 rounded-full animate-pulse" />
            <span className="text-blue-400 text-sm font-medium">Fast</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-purple-400 rounded-full animate-pulse" />
            <span className="text-purple-400 text-sm font-medium">Premium</span>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-20px) rotate(180deg); }
        }
        @keyframes gridMove {
          0% { transform: translate(0, 0); }
          100% { transform: translate(40px, 40px); }
        }
      `}</style>
    </div>
  )
}
