"use client"

import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import Link from "next/link"
import { Menu, X, ChevronDown, Shield, Clock, ArrowRight } from "lucide-react"
import { useState } from "react"
import Image from "next/image"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const services = [
    { name: "SA-MP Servers", href: "/samp", icon: "🎮" },
    { name: "MTA Servers", href: "/mta", icon: "🚗" },
    { name: "Minecraft Servers", href: "/minecraft", icon: "⛏️" },
    { name: "FiveM Servers", href: "/fivem", icon: "🏎️" },
    { name: "Discord Bots", href: "/discord-bots", icon: "🤖" },
    { name: "VPS Hosting", href: "/vps", icon: "💻" },
    { name: "RDP Servers", href: "/rdp", icon: "🖥️" },
  ]

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-black/95 backdrop-blur-xl border-b border-gray-800/30">
      <div className="container mx-auto px-4">
        {/* Top Bar with Status - Desktop Only */}
        <div className="hidden md:flex items-center justify-between py-2 text-xs border-b border-gray-800/20">
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              <span className="text-green-400 font-medium">All Systems Online</span>
            </div>
            <div className="flex items-center space-x-2">
              <Shield className="w-3 h-3 text-blue-400" />
              <span className="text-gray-400">99.99% Uptime</span>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="w-3 h-3 text-blue-400" />
              <span className="text-gray-400">24/7 Support</span>
            </div>
          </div>
          <div className="flex items-center space-x-4 text-gray-400">
            <Link href="https://status.avoxhosting.com" className="hover:text-white transition-colors">
              Status
            </Link>
            <Link href="https://billing.avoxhosting.com/contact.php" className="hover:text-white transition-colors">
              Support
            </Link>
            <Link href="https://billing.avoxhosting.com/knowledgebase" className="hover:text-white transition-colors">
              Docs
            </Link>
          </div>
        </div>

        {/* Main Header */}
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-3 group">
            <div className="relative">
              <div className="w-10 h-10 rounded-lg overflow-hidden bg-white/5 border border-gray-700/50">
                <Image
                  src="/images/avox-logo.png"
                  alt="Avox Hosting"
                  width={40}
                  height={40}
                  className="w-full h-full object-contain p-1"
                  priority
                />
              </div>
            </div>
            <div className="hidden sm:block">
              <div className="font-bold text-lg text-white">Avox Hosting</div>
              <div className="text-xs text-gray-400 -mt-1">Premium Gaming</div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            <Link href="/" className="text-white hover:text-blue-400 transition-colors font-medium">
              Home
            </Link>

            <DropdownMenu>
              <DropdownMenuTrigger className="flex items-center space-x-1 text-gray-300 hover:text-white transition-colors font-medium">
                <span>Services</span>
                <ChevronDown className="w-4 h-4" />
              </DropdownMenuTrigger>
              <DropdownMenuContent className="bg-black/95 backdrop-blur-xl border-gray-800 shadow-2xl rounded-lg p-2 min-w-[280px]">
                <div className="grid gap-1">
                  {services.map((service) => (
                    <DropdownMenuItem key={service.href} asChild>
                      <Link
                        href={service.href}
                        className="flex items-center space-x-3 px-4 py-3 text-gray-300 hover:text-white hover:bg-gray-800/50 rounded-md transition-all duration-200"
                      >
                        <span className="text-base">{service.icon}</span>
                        <span className="font-medium">{service.name}</span>
                      </Link>
                    </DropdownMenuItem>
                  ))}
                </div>
                <div className="border-t border-gray-800 mt-2 pt-2">
                  <Link
                    href="https://billing.avoxhosting.com/cart.php"
                    className="flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors font-medium"
                  >
                    View All Services
                  </Link>
                </div>
              </DropdownMenuContent>
            </DropdownMenu>

            <Link href="#pricing" className="text-gray-300 hover:text-white transition-colors font-medium">
              Pricing
            </Link>

            <Link href="/about" className="text-gray-300 hover:text-white transition-colors font-medium">
              About
            </Link>

            <Link href="/contact" className="text-gray-300 hover:text-white transition-colors font-medium">
              Contact
            </Link>
          </nav>

          {/* Desktop Login Button */}
          <div className="hidden lg:flex items-center">
            <Button className="bg-blue-600 hover:bg-blue-700 text-white font-medium px-6" asChild>
              <Link href="https://billing.avoxhosting.com/clientarea.php">Login</Link>
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden text-white p-2 hover:bg-gray-800/50 rounded-lg transition-colors"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="lg:hidden bg-black absolute top-full left-0 right-0 min-h-screen">
          <div className="px-6 py-8">
            {/* Navigation */}
            <div className="space-y-1 mb-8">
              <Link href="/" className="block py-3 text-white text-lg font-medium" onClick={() => setIsMenuOpen(false)}>
                Home
              </Link>

              <Link href="#pricing" className="block py-3 text-gray-300 text-lg" onClick={() => setIsMenuOpen(false)}>
                Pricing
              </Link>

              <Link href="/about" className="block py-3 text-gray-300 text-lg" onClick={() => setIsMenuOpen(false)}>
                About
              </Link>

              <Link href="/contact" className="block py-3 text-gray-300 text-lg" onClick={() => setIsMenuOpen(false)}>
                Contact
              </Link>
            </div>

            {/* Services Section */}
            <div className="mb-8">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-gray-400 text-sm font-medium uppercase tracking-wider">Services</h3>
                <div className="h-px bg-gray-800 flex-1 ml-4"></div>
              </div>

              <div className="space-y-2">
                {services.map((service) => (
                  <Link
                    key={service.href}
                    href={service.href}
                    className="flex items-center justify-between p-4 rounded-lg border border-gray-800/50 hover:border-gray-700 hover:bg-gray-900/30 transition-all duration-200 group"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    <div className="flex items-center space-x-3">
                      <span className="text-lg">{service.icon}</span>
                      <span className="text-white font-medium">{service.name}</span>
                    </div>
                    <ArrowRight className="w-4 h-4 text-gray-500 group-hover:text-gray-300 transition-colors" />
                  </Link>
                ))}
              </div>
            </div>

            {/* Login Button */}
            <div className="pt-6 border-t border-gray-800">
              <Button
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-4 text-lg"
                asChild
                onClick={() => setIsMenuOpen(false)}
              >
                <Link href="https://billing.avoxhosting.com/clientarea.php">Login to Client Area</Link>
              </Button>
            </div>

            {/* Status */}
            <div className="mt-6 pt-6 border-t border-gray-800">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                <span className="text-green-400 text-sm font-medium">All Systems Operational</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  )
}
