import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Gamepad2, Server, Users, Bot, Monitor, Zap, Car, Pickaxe } from "lucide-react"

export function ServicesSection() {
  const services = [
    {
      title: "SA-MP Servers",
      description: "High-performance San Andreas Multiplayer hosting with custom plugins support and mod compatibility",
      icon: <Car className="w-8 h-8" />,
      color: "from-orange-500 to-red-500",
      features: ["Custom Plugins", "Anti-DDoS", "24/7 Support", "Instant Setup"],
      startingPrice: "€5.99",
      popular: false,
    },
    {
      title: "MTA Servers",
      description: "Multi Theft Auto hosting with advanced scripting capabilities and resource management",
      icon: <Gamepad2 className="w-8 h-8" />,
      color: "from-green-500 to-emerald-500",
      features: ["Lua Scripting", "Resource Manager", "Admin Panel", "Auto Backups"],
      startingPrice: "€6.99",
      popular: false,
    },
    {
      title: "Minecraft Servers",
      description: "Optimized Minecraft hosting for all versions, modpacks, and custom configurations",
      icon: <Pickaxe className="w-8 h-8" />,
      color: "from-green-600 to-lime-500",
      features: ["All Versions", "Modpack Support", "Plugin Manager", "World Backups"],
      startingPrice: "€4.99",
      popular: true,
    },
    {
      title: "FiveM Servers",
      description: "GTA V roleplay servers with custom resources, frameworks, and ESX/QBCore support",
      icon: <Users className="w-8 h-8" />,
      color: "from-purple-500 to-pink-500",
      features: ["ESX/QBCore", "Custom Resources", "Database Included", "txAdmin Panel"],
      startingPrice: "€8.99",
      popular: true,
    },
    {
      title: "Discord Bots",
      description: "24/7 Discord bot hosting with automatic restarts, monitoring, and easy deployment",
      icon: <Bot className="w-8 h-8" />,
      color: "from-indigo-500 to-purple-500",
      features: ["24/7 Uptime", "Auto Restart", "Easy Deploy", "Multiple Languages"],
      startingPrice: "€2.99",
      popular: false,
    },
    {
      title: "VPS Hosting",
      description: "Powerful virtual private servers with full root access for any application or game server",
      icon: <Server className="w-8 h-8" />,
      color: "from-blue-500 to-cyan-500",
      features: ["Full Root Access", "Multiple OS", "SSD Storage", "DDoS Protection"],
      startingPrice: "€14.99",
      popular: false,
    },
    {
      title: "RDP Servers",
      description: "Windows Remote Desktop servers for development, gaming, and business applications",
      icon: <Monitor className="w-8 h-8" />,
      color: "from-teal-500 to-blue-500",
      features: ["Windows Server", "Remote Access", "High Performance", "24/7 Available"],
      startingPrice: "€12.99",
      popular: false,
    },
    {
      title: "Custom Solutions",
      description: "Tailored hosting solutions designed specifically for your unique requirements",
      icon: <Zap className="w-8 h-8" />,
      color: "from-yellow-500 to-orange-500",
      features: ["Custom Config", "Dedicated Support", "Scalable", "Enterprise Grade"],
      startingPrice: "Contact Us",
      popular: false,
    },
  ]

  return (
    <section id="services" className="py-20 bg-slate-900/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4 text-white">Our Gaming Services</h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto mb-6"></div>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Choose from our comprehensive range of gaming and hosting solutions, each optimized for maximum performance
            and reliability
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <Card
              key={index}
              className={`relative bg-slate-900/50 border-slate-800 hover:border-slate-700 transition-all duration-300 group ${
                service.popular ? "ring-2 ring-blue-500" : ""
              }`}
            >
              {service.popular && (
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-green-600 text-white">
                  Popular
                </Badge>
              )}

              <CardHeader>
                <div
                  className={`w-16 h-16 rounded-lg bg-gradient-to-br ${service.color} flex items-center justify-center text-white mb-4 group-hover:scale-110 transition-transform`}
                >
                  {service.icon}
                </div>
                <CardTitle className="text-white">{service.title}</CardTitle>
                <CardDescription className="text-slate-400">{service.description}</CardDescription>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="space-y-2">
                  {service.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-center space-x-2">
                      <div className="w-1.5 h-1.5 bg-blue-400 rounded-full"></div>
                      <span className="text-slate-300 text-sm">{feature}</span>
                    </div>
                  ))}
                </div>

                <div className="pt-4 border-t border-slate-800">
                  <div className="text-center">
                    <span className="text-sm text-slate-400">Starting from</span>
                    <div className="text-2xl font-bold text-white">{service.startingPrice}</div>
                    {service.startingPrice !== "Contact Us" && <span className="text-slate-400 text-sm">/month</span>}
                  </div>
                </div>
              </CardContent>

              <CardFooter>
                <Button className="w-full bg-blue-600 hover:bg-blue-700">
                  {service.startingPrice === "Contact Us" ? "Contact Us" : "Order Now"}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
