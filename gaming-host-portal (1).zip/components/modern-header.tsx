"use client"

import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import Link from "next/link"
import Image from "next/image"
import { Menu, X, ChevronDown, User, Gamepad2, Shield, Zap } from "lucide-react"
import { useState, useEffect } from "react"

export function ModernHeader() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const services = [
    { name: "SA-MP Servers", href: "/samp", icon: "🏎️", desc: "San Andreas Multiplayer" },
    { name: "MTA Servers", href: "/mta", icon: "🎮", desc: "Multi Theft Auto" },
    { name: "Minecraft Servers", href: "/minecraft", icon: "⛏️", desc: "All Versions & Mods" },
    { name: "FiveM Servers", href: "/fivem", icon: "🚗", desc: "GTA V Roleplay" },
    { name: "Discord Bots", href: "/discord-bots", icon: "🤖", desc: "24/7 Bot Hosting" },
    { name: "VPS Hosting", href: "/vps", icon: "💻", desc: "Virtual Private Servers" },
    { name: "RDP Servers", href: "/rdp", icon: "🖥️", desc: "Remote Desktop" },
  ]

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-slate-950/95 backdrop-blur-xl border-b border-orange-500/20 shadow-2xl shadow-orange-500/10"
          : "bg-transparent"
      }`}
    >
      {/* Premium Status Bar */}
      <div className="hidden lg:block bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border-b border-slate-700/50">
        <div className="container mx-auto px-6">
          <div className="flex items-center justify-between py-2 text-sm">
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                <span className="text-green-400 font-medium">All Systems Operational</span>
              </div>
              <div className="flex items-center space-x-2">
                <Shield className="w-4 h-4 text-orange-400" />
                <span className="text-slate-300">DDoS Protected</span>
              </div>
              <div className="flex items-center space-x-2">
                <Zap className="w-4 h-4 text-yellow-400" />
                <span className="text-slate-300">Instant Setup</span>
              </div>
            </div>
            <div className="flex items-center space-x-4 text-slate-400">
              <Link href="#" className="hover:text-orange-400 transition-colors">
                Status
              </Link>
              <Link href="#" className="hover:text-orange-400 transition-colors">
                Support
              </Link>
              <Link href="#" className="hover:text-orange-400 transition-colors">
                Discord
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <div className="container mx-auto px-6">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-4 group">
            <div className="relative">
              <div className="w-12 h-12 relative">
                <div className="absolute inset-0 bg-gradient-to-r from-orange-500 to-red-500 rounded-xl blur-lg opacity-50 group-hover:opacity-75 transition-opacity" />
                <div className="relative w-full h-full bg-slate-900 rounded-xl border-2 border-orange-500/30 group-hover:border-orange-500/60 transition-colors flex items-center justify-center">
                  <Image
                    src="/images/avox-logo.png"
                    alt="Avox Hosting"
                    width={32}
                    height={32}
                    className="w-8 h-8 object-contain"
                  />
                </div>
              </div>
            </div>
            <div className="hidden sm:block">
              <div className="font-black text-2xl bg-gradient-to-r from-orange-400 to-red-500 bg-clip-text text-transparent">
                AVOX
              </div>
              <div className="text-xs text-slate-400 -mt-1 font-medium">PREMIUM GAMING</div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            <Link
              href="/"
              className="text-white hover:text-orange-400 transition-all duration-300 font-semibold relative group"
            >
              Home
              <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-orange-400 to-red-500 group-hover:w-full transition-all duration-300" />
            </Link>

            <DropdownMenu>
              <DropdownMenuTrigger className="flex items-center space-x-2 text-slate-300 hover:text-white transition-colors font-semibold group">
                <span>Services</span>
                <ChevronDown className="w-4 h-4 group-hover:rotate-180 transition-transform duration-300" />
              </DropdownMenuTrigger>
              <DropdownMenuContent className="bg-slate-900/98 backdrop-blur-xl border-slate-700/50 shadow-2xl rounded-2xl p-4 min-w-[400px]">
                <div className="grid grid-cols-1 gap-2">
                  {services.map((service) => (
                    <DropdownMenuItem key={service.href} asChild>
                      <Link
                        href={service.href}
                        className="flex items-center space-x-4 px-4 py-3 text-slate-300 hover:text-white hover:bg-gradient-to-r hover:from-orange-500/10 hover:to-red-500/10 rounded-xl transition-all duration-300 group"
                      >
                        <span className="text-2xl group-hover:scale-110 transition-transform duration-300">
                          {service.icon}
                        </span>
                        <div>
                          <div className="font-semibold">{service.name}</div>
                          <div className="text-xs text-slate-400">{service.desc}</div>
                        </div>
                      </Link>
                    </DropdownMenuItem>
                  ))}
                </div>
              </DropdownMenuContent>
            </DropdownMenu>

            <Link
              href="#pricing"
              className="text-slate-300 hover:text-white transition-all duration-300 font-semibold relative group"
            >
              Pricing
              <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-orange-400 to-red-500 group-hover:w-full transition-all duration-300" />
            </Link>
            <Link
              href="/about"
              className="text-slate-300 hover:text-white transition-all duration-300 font-semibold relative group"
            >
              About
              <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-orange-400 to-red-500 group-hover:w-full transition-all duration-300" />
            </Link>
            <Link
              href="/contact"
              className="text-slate-300 hover:text-white transition-all duration-300 font-semibold relative group"
            >
              Contact
              <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-orange-400 to-red-500 group-hover:w-full transition-all duration-300" />
            </Link>
          </nav>

          {/* Login Dropdown */}
          <div className="hidden lg:flex items-center">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-bold px-6 py-3 rounded-xl shadow-lg hover:shadow-orange-500/25 transition-all duration-300 group">
                  <User className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform duration-300" />
                  Login
                  <ChevronDown className="w-4 h-4 ml-2 group-hover:rotate-180 transition-transform duration-300" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="bg-slate-900/98 backdrop-blur-xl border-slate-700/50 shadow-2xl rounded-2xl p-3 min-w-[280px]">
                <DropdownMenuItem asChild>
                  <Link
                    href="https://billing.avoxhosting.com/clientarea.php"
                    className="flex items-center space-x-4 px-4 py-4 text-slate-300 hover:text-white hover:bg-gradient-to-r hover:from-orange-500/10 hover:to-red-500/10 rounded-xl transition-all duration-300 group"
                  >
                    <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                      <User className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <div className="font-bold text-lg">Client Area</div>
                      <div className="text-sm text-slate-400">Billing & Account Management</div>
                    </div>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link
                    href="https://panel.avoxhosting.com"
                    className="flex items-center space-x-4 px-4 py-4 text-slate-300 hover:text-white hover:bg-gradient-to-r hover:from-purple-500/10 hover:to-blue-500/10 rounded-xl transition-all duration-300 group"
                  >
                    <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-blue-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                      <Gamepad2 className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <div className="font-bold text-lg">Game Panel</div>
                      <div className="text-sm text-slate-400">Server Control & Management</div>
                    </div>
                  </Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden text-white p-3 hover:bg-slate-800/50 rounded-xl transition-colors"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="lg:hidden bg-slate-950/98 backdrop-blur-xl border-t border-slate-800/50 absolute top-full left-0 right-0 shadow-2xl">
          <div className="px-6 py-8">
            {/* Navigation Links */}
            <div className="space-y-3 mb-8">
              <Link
                href="/"
                className="block py-3 px-4 text-white font-semibold hover:bg-gradient-to-r hover:from-orange-500/10 hover:to-red-500/10 rounded-xl transition-all duration-300"
                onClick={() => setIsMenuOpen(false)}
              >
                Home
              </Link>
              <Link
                href="#pricing"
                className="block py-3 px-4 text-slate-300 hover:text-white hover:bg-slate-800/50 rounded-xl transition-all duration-300"
                onClick={() => setIsMenuOpen(false)}
              >
                Pricing
              </Link>
              <Link
                href="/about"
                className="block py-3 px-4 text-slate-300 hover:text-white hover:bg-slate-800/50 rounded-xl transition-all duration-300"
                onClick={() => setIsMenuOpen(false)}
              >
                About
              </Link>
              <Link
                href="/contact"
                className="block py-3 px-4 text-slate-300 hover:text-white hover:bg-slate-800/50 rounded-xl transition-all duration-300"
                onClick={() => setIsMenuOpen(false)}
              >
                Contact
              </Link>
            </div>

            {/* Services Grid */}
            <div className="mb-8">
              <h3 className="text-slate-400 text-sm font-bold mb-4 uppercase tracking-wider">Gaming Services</h3>
              <div className="grid grid-cols-1 gap-3">
                {services.map((service) => (
                  <Link
                    key={service.href}
                    href={service.href}
                    className="flex items-center space-x-4 p-4 rounded-xl bg-slate-900/50 border border-slate-800/50 hover:border-orange-500/30 hover:bg-gradient-to-r hover:from-orange-500/5 hover:to-red-500/5 transition-all duration-300"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    <span className="text-2xl">{service.icon}</span>
                    <div>
                      <div className="text-white font-semibold">{service.name}</div>
                      <div className="text-xs text-slate-400">{service.desc}</div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>

            {/* Login Options */}
            <div className="space-y-4 pt-6 border-t border-slate-800">
              <Link
                href="https://billing.avoxhosting.com/clientarea.php"
                className="flex items-center space-x-4 p-4 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-xl font-bold shadow-lg"
                onClick={() => setIsMenuOpen(false)}
              >
                <User className="w-6 h-6" />
                <div>
                  <div className="text-lg">Client Area</div>
                  <div className="text-sm opacity-90">Billing & Account</div>
                </div>
              </Link>
              <Link
                href="https://panel.avoxhosting.com"
                className="flex items-center space-x-4 p-4 bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-xl font-bold shadow-lg"
                onClick={() => setIsMenuOpen(false)}
              >
                <Gamepad2 className="w-6 h-6" />
                <div>
                  <div className="text-lg">Game Panel</div>
                  <div className="text-sm opacity-90">Server Management</div>
                </div>
              </Link>
            </div>
          </div>
        </div>
      )}
    </header>
  )
}
