"use client"

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Gamepad2, Server, Users, Bot, Monitor, Zap, Car, Pickaxe, ArrowRight, Star, TrendingUp } from "lucide-react"
import { useState } from "react"
import Link from "next/link"

export function Services3DSection() {
  const [hoveredCard, setHoveredCard] = useState<number | null>(null)

  const services = [
    {
      title: "SA-MP Servers",
      description:
        "High-performance San Andreas Multiplayer hosting with custom plugins and advanced anti-cheat systems",
      icon: <Car className="w-6 h-6" />,
      gradient: "from-orange-500 to-red-500",
      features: ["Custom Plugins", "Anti-DDoS", "24/7 Support", "Instant Setup"],
      startingPrice: "€5.99",
      popular: false,
      rating: 4.9,
      productId: "1",
    },
    {
      title: "MTA Servers",
      description: "Multi Theft Auto hosting with advanced Lua scripting and comprehensive resource management",
      icon: <Gamepad2 className="w-6 h-6" />,
      gradient: "from-green-500 to-emerald-500",
      features: ["Lua Scripting", "Resource Manager", "Admin Panel", "Auto Backups"],
      startingPrice: "€6.99",
      popular: false,
      rating: 4.8,
      productId: "2",
    },
    {
      title: "Minecraft Servers",
      description:
        "Optimized Minecraft hosting for all versions, modpacks, and custom configurations with world protection",
      icon: <Pickaxe className="w-6 h-6" />,
      gradient: "from-green-600 to-lime-500",
      features: ["All Versions", "Modpack Support", "Plugin Manager", "World Backups"],
      startingPrice: "€4.99",
      popular: true,
      rating: 4.9,
      productId: "3",
    },
    {
      title: "FiveM Servers",
      description: "GTA V roleplay servers with ESX/QBCore frameworks and unlimited custom resources",
      icon: <Users className="w-6 h-6" />,
      gradient: "from-purple-500 to-pink-500",
      features: ["ESX/QBCore", "Custom Resources", "Database Included", "txAdmin Panel"],
      startingPrice: "€8.99",
      popular: true,
      rating: 4.9,
      productId: "4",
    },
    {
      title: "Discord Bots",
      description: "24/7 Discord bot hosting with automatic scaling, monitoring, and multi-language support",
      icon: <Bot className="w-6 h-6" />,
      gradient: "from-indigo-500 to-blue-500",
      features: ["24/7 Uptime", "Auto Restart", "Easy Deploy", "Multiple Languages"],
      startingPrice: "€2.99",
      popular: false,
      rating: 4.7,
      productId: "5",
    },
    {
      title: "VPS Hosting",
      description: "Powerful virtual private servers with full root access and enterprise-grade infrastructure",
      icon: <Server className="w-6 h-6" />,
      gradient: "from-blue-500 to-cyan-500",
      features: ["Full Root Access", "Multiple OS", "NVMe Storage", "DDoS Protection"],
      startingPrice: "€14.99",
      popular: false,
      rating: 4.8,
      productId: "6",
    },
    {
      title: "RDP Servers",
      description: "Windows Remote Desktop servers for development, gaming, and professional business applications",
      icon: <Monitor className="w-6 h-6" />,
      gradient: "from-teal-500 to-blue-500",
      features: ["Windows Server", "Remote Access", "High Performance", "24/7 Available"],
      startingPrice: "€12.99",
      popular: false,
      rating: 4.6,
      productId: "7",
    },
    {
      title: "Custom Solutions",
      description: "Tailored enterprise hosting solutions with dedicated support and unlimited scalability",
      icon: <Zap className="w-6 h-6" />,
      gradient: "from-yellow-500 to-orange-500",
      features: ["Custom Config", "Dedicated Support", "Scalable", "Enterprise Grade"],
      startingPrice: "Contact Us",
      popular: false,
      rating: 5.0,
      productId: null,
    },
  ]

  return (
    <section id="services" className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(59,130,246,0.08),transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_80%,rgba(147,51,234,0.08),transparent_50%)]" />

      <div className="container mx-auto px-4 relative z-10">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 text-blue-300 border-blue-500/30 px-4 py-2 mb-6">
            <TrendingUp className="w-4 h-4 mr-2" />
            Premium Gaming Services
          </Badge>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black mb-6">
            <span className="text-white">Choose Your</span>
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500">
              Gaming Solution
            </span>
          </h2>

          <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-purple-500 mx-auto mb-6 rounded-full" />

          <p className="text-lg text-slate-300 max-w-3xl mx-auto leading-relaxed">
            Discover our comprehensive range of gaming and hosting solutions, each optimized for maximum performance
            with cutting-edge technology and 24/7 expert support.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <Card
              key={index}
              className={`group relative bg-gradient-to-br from-slate-900/80 to-slate-800/80 backdrop-blur-sm border border-slate-700/50 hover:border-slate-600/50 transition-all duration-500 transform hover:scale-105 ${
                service.popular ? "ring-2 ring-blue-500/50 shadow-lg shadow-blue-500/20" : ""
              }`}
              onMouseEnter={() => setHoveredCard(index)}
              onMouseLeave={() => setHoveredCard(null)}
            >
              {service.popular && (
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-green-500 to-emerald-500 text-white shadow-lg z-10">
                  Most Popular
                </Badge>
              )}

              {/* Glow Effect */}
              <div
                className={`absolute inset-0 bg-gradient-to-r ${service.gradient} opacity-0 group-hover:opacity-5 rounded-lg transition-opacity duration-500`}
              />

              <CardHeader className="relative pb-4">
                <div
                  className={`w-12 h-12 rounded-xl bg-gradient-to-br ${service.gradient} flex items-center justify-center text-white mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg`}
                >
                  {service.icon}
                </div>

                <CardTitle className="text-white text-lg mb-2 group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-blue-400 group-hover:to-purple-500 transition-all duration-300">
                  {service.title}
                </CardTitle>

                <CardDescription className="text-slate-400 text-sm leading-relaxed line-clamp-3">
                  {service.description}
                </CardDescription>

                {/* Rating */}
                <div className="flex items-center space-x-2 mt-3">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3 h-3 ${
                          i < Math.floor(service.rating) ? "text-yellow-400 fill-current" : "text-slate-600"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-xs text-slate-400">({service.rating})</span>
                </div>
              </CardHeader>

              <CardContent className="space-y-4 pb-4">
                <div className="space-y-2">
                  {service.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-center space-x-2">
                      <div className="w-1.5 h-1.5 bg-gradient-to-r from-blue-400 to-purple-500 rounded-full" />
                      <span className="text-slate-300 text-xs">{feature}</span>
                    </div>
                  ))}
                </div>

                <div className="pt-4 border-t border-slate-700/50">
                  <div className="text-center">
                    <span className="text-xs text-slate-400">Starting from</span>
                    <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">
                      {service.startingPrice}
                    </div>
                    {service.startingPrice !== "Contact Us" && <span className="text-slate-400 text-xs">/month</span>}
                  </div>
                </div>
              </CardContent>

              <CardFooter className="pt-0">
                <Button
                  className={`w-full bg-gradient-to-r ${service.gradient} hover:shadow-lg transition-all duration-300 group-hover:scale-105 font-medium text-sm`}
                  asChild
                >
                  <Link
                    href={
                      service.startingPrice === "Contact Us"
                        ? "https://billing.avoxhosting.com/contact.php"
                        : `https://billing.avoxhosting.com/cart.php?a=add&pid=${service.productId || "1"}`
                    }
                  >
                    <span>{service.startingPrice === "Contact Us" ? "Contact Us" : "Order Now"}</span>
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-12">
          <p className="text-slate-400 mb-6">Need help choosing the right plan?</p>
          <Button
            size="lg"
            variant="outline"
            className="border-slate-600 text-slate-300 hover:text-white hover:bg-slate-800 hover:border-blue-500/50 bg-transparent px-8 py-3 rounded-xl transition-all duration-300"
            asChild
          >
            <Link href="https://billing.avoxhosting.com/contact.php">Contact Our Experts</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
