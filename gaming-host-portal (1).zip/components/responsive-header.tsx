"use client"

import { useState, useEffect } from "react"
import { Badge } from "@/components/ui/badge"
import { Menu, X, ChevronDown, User, Settings, Activity, Wifi, Server } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export function ResponsiveHeader() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isLoginDropdownOpen, setIsLoginDropdownOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const navigation = [
    { name: "Home", href: "/" },
    { name: "Services", href: "#services" },
    { name: "About", href: "/about" },
    { name: "Contact", href: "/contact" },
  ]

  const services = [
    { name: "Minecraft", href: "/minecraft", color: "text-blue-400" },
    { name: "FiveM", href: "/fivem", color: "text-blue-400" },
    { name: "SA-MP", href: "/samp", color: "text-blue-400" },
    { name: "MTA", href: "/mta", color: "text-blue-400" },
    { name: "Discord Bots", href: "/discord-bots", color: "text-blue-400" },
    { name: "VPS", href: "/vps", color: "text-blue-400" },
    { name: "RDP", href: "/rdp", color: "text-blue-400" },
  ]

  return (
    <>
      {/* Status Bar */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-r from-blue-900/30 via-slate-900/30 to-blue-900/30 backdrop-blur-md border-b border-slate-800/50">
        <div className="container mx-auto px-3 sm:px-4 lg:px-6 xl:px-8">
          <div className="flex items-center justify-between h-7 sm:h-8 md:h-9">
            <div className="flex items-center space-x-2 sm:space-x-3 md:space-x-4 lg:space-x-6">
              <div className="flex items-center space-x-1 sm:space-x-2">
                <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-blue-400 rounded-full animate-pulse" />
                <span className="text-xs sm:text-sm text-slate-300 font-medium">System Status: Online</span>
              </div>
              <div className="hidden sm:flex items-center space-x-1 sm:space-x-2">
                <Activity className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-blue-400" />
                <span className="text-xs text-slate-400">99.9% Uptime</span>
              </div>
            </div>
            <div className="flex items-center space-x-1 sm:space-x-2 md:space-x-3">
              <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30 text-xs px-1.5 sm:px-2 py-0.5 sm:py-1">
                <Server className="w-2.5 h-2.5 sm:w-3 sm:h-3 mr-0.5 sm:mr-1" />
                <span className="hidden sm:inline">Premium</span>
              </Badge>
              <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30 text-xs px-1.5 sm:px-2 py-0.5 sm:py-1">
                <Wifi className="w-2.5 h-2.5 sm:w-3 sm:h-3 mr-0.5 sm:mr-1" />
                <span className="hidden sm:inline">24/7</span>
              </Badge>
            </div>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header
        className={`fixed top-7 sm:top-8 md:top-9 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled
            ? "bg-slate-950/98 backdrop-blur-xl border-b border-slate-800/50 shadow-2xl shadow-blue-500/10"
            : "bg-slate-950/80 backdrop-blur-lg"
        }`}
      >
        <div className="container mx-auto px-3 sm:px-4 lg:px-6 xl:px-8">
          <div className="flex items-center justify-between h-14 sm:h-16 md:h-18 lg:h-20">
            {/* Logo */}
            <Link href="/" className="flex items-center space-x-2 sm:space-x-3 group">
              <div className="relative w-7 h-7 sm:w-8 sm:h-8 md:w-10 md:h-10 lg:w-12 lg:h-12">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg sm:rounded-xl blur-sm opacity-60 group-hover:opacity-80 transition-opacity duration-300" />
                <div className="relative w-full h-full bg-slate-900 rounded-lg sm:rounded-xl border border-blue-500/40 flex items-center justify-center group-hover:border-blue-400/60 transition-colors duration-300">
                  <Image
                    src="/images/avox-logo.png"
                    alt="Avox Hosting"
                    width={32}
                    height={32}
                    className="w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6 lg:w-8 lg:h-8 object-contain"
                    priority
                  />
                </div>
              </div>
              <div className="hidden sm:block">
                <div className="text-base sm:text-lg md:text-xl lg:text-2xl font-black">
                  <span className="bg-gradient-to-r from-blue-400 to-blue-500 bg-clip-text text-transparent">AVOX</span>
                </div>
                <div className="text-xs sm:text-sm text-slate-400 font-medium -mt-0.5 sm:-mt-1">HOSTING</div>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center space-x-1 xl:space-x-2">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  href={item.href}
                  className="px-3 xl:px-4 py-2 text-sm xl:text-base font-medium text-slate-300 hover:text-white transition-colors duration-200 rounded-lg hover:bg-slate-800/50"
                >
                  {item.name}
                </Link>
              ))}

              {/* Services Dropdown */}
              <div className="relative group">
                <button className="flex items-center px-3 xl:px-4 py-2 text-sm xl:text-base font-medium text-slate-300 hover:text-white transition-colors duration-200 rounded-lg hover:bg-slate-800/50">
                  Services
                  <ChevronDown className="ml-1 w-4 h-4 group-hover:rotate-180 transition-transform duration-200" />
                </button>
                <div className="absolute top-full left-0 mt-2 w-48 bg-slate-900/98 backdrop-blur-xl border border-slate-700/50 rounded-xl shadow-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                  <div className="p-2">
                    {services.map((service) => (
                      <Link
                        key={service.name}
                        href={service.href}
                        className={`block px-3 py-2 text-sm font-medium ${service.color} hover:bg-slate-800/50 rounded-lg transition-colors duration-200`}
                      >
                        {service.name}
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            </nav>

            {/* Login Dropdown & Mobile Menu */}
            <div className="flex items-center space-x-2 sm:space-x-3">
              {/* Login Dropdown */}
              <div className="relative">
                <button
                  onClick={() => setIsLoginDropdownOpen(!isLoginDropdownOpen)}
                  className="group relative flex items-center space-x-1 sm:space-x-2 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white px-3 sm:px-4 md:px-5 lg:px-6 py-2 sm:py-2.5 md:py-3 rounded-lg sm:rounded-xl font-bold text-xs sm:text-sm md:text-base transition-all duration-300 shadow-lg hover:shadow-xl hover:shadow-blue-500/30 transform hover:scale-105"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-blue-500 rounded-lg sm:rounded-xl opacity-0 group-hover:opacity-20 transition-opacity duration-300" />
                  <User className="w-3 h-3 sm:w-4 sm:h-4 relative z-10" />
                  <span className="hidden sm:inline relative z-10">Login</span>
                  <ChevronDown
                    className={`w-3 h-3 sm:w-4 sm:h-4 relative z-10 transition-transform duration-200 ${isLoginDropdownOpen ? "rotate-180" : ""}`}
                  />
                </button>

                {isLoginDropdownOpen && (
                  <div className="absolute top-full right-0 mt-2 w-52 sm:w-60 bg-slate-900/98 backdrop-blur-xl border border-slate-700/50 rounded-xl shadow-2xl z-50 animate-in slide-in-from-top-2 duration-200">
                    <div className="p-2">
                      <Link
                        href="https://client.avoxhosting.site/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center space-x-3 px-3 py-3 text-sm font-medium text-blue-400 hover:bg-slate-800/50 rounded-lg transition-colors duration-200 group"
                        onClick={() => setIsLoginDropdownOpen(false)}
                      >
                        <User className="w-4 h-4 group-hover:scale-110 transition-transform duration-200" />
                        <div>
                          <div className="font-bold">Client Area</div>
                          <div className="text-xs text-slate-500">Billing & Support</div>
                        </div>
                      </Link>
                      <Link
                        href="https://portal.avoxhosting.site/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center space-x-3 px-3 py-3 text-sm font-medium text-blue-400 hover:bg-slate-800/50 rounded-lg transition-colors duration-200 group"
                        onClick={() => setIsLoginDropdownOpen(false)}
                      >
                        <Settings className="w-4 h-4 group-hover:scale-110 transition-transform duration-200" />
                        <div>
                          <div className="font-bold">Game Panel</div>
                          <div className="text-xs text-slate-500">Server Management</div>
                        </div>
                      </Link>
                    </div>
                  </div>
                )}
              </div>

              {/* Mobile Menu Button */}
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="lg:hidden p-2 text-slate-300 hover:text-white hover:bg-slate-800/50 rounded-lg transition-all duration-200"
              >
                {isMobileMenuOpen ? (
                  <X className="w-5 h-5 sm:w-6 sm:h-6" />
                ) : (
                  <Menu className="w-5 h-5 sm:w-6 sm:h-6" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden bg-slate-950/98 backdrop-blur-xl border-t border-slate-800/50 animate-in slide-in-from-top-2 duration-200">
            <div className="container mx-auto px-3 sm:px-4 py-4 sm:py-6">
              <nav className="space-y-1 sm:space-y-2">
                {navigation.map((item) => (
                  <Link
                    key={item.name}
                    href={item.href}
                    className="block px-3 py-2.5 sm:py-3 text-base sm:text-lg font-medium text-slate-300 hover:text-white hover:bg-slate-800/50 rounded-lg transition-colors duration-200"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    {item.name}
                  </Link>
                ))}

                {/* Mobile Services */}
                <div className="pt-3 sm:pt-4 border-t border-slate-800/50">
                  <div className="px-3 py-2 text-sm font-bold text-slate-400 uppercase tracking-wider">Services</div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 sm:gap-2">
                    {services.map((service) => (
                      <Link
                        key={service.name}
                        href={service.href}
                        className={`block px-3 py-2.5 text-sm sm:text-base font-medium ${service.color} hover:bg-slate-800/50 rounded-lg transition-colors duration-200`}
                        onClick={() => setIsMobileMenuOpen(false)}
                      >
                        {service.name}
                      </Link>
                    ))}
                  </div>
                </div>

                {/* Mobile Login Links */}
                <div className="pt-3 sm:pt-4 border-t border-slate-800/50 space-y-2">
                  <Link
                    href="https://client.avoxhosting.site/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center space-x-3 px-3 py-3 bg-blue-500/10 border border-blue-500/20 text-blue-400 hover:bg-blue-500/20 rounded-lg transition-colors duration-200"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <User className="w-5 h-5" />
                    <div>
                      <div className="font-bold text-base">Client Area</div>
                      <div className="text-xs text-slate-500">Billing & Support</div>
                    </div>
                  </Link>
                  <Link
                    href="https://portal.avoxhosting.site/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center space-x-3 px-3 py-3 bg-blue-500/10 border border-blue-500/20 text-blue-400 hover:bg-blue-500/20 rounded-lg transition-colors duration-200"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <Settings className="w-5 h-5" />
                    <div>
                      <div className="font-bold text-base">Game Panel</div>
                      <div className="text-xs text-slate-500">Server Management</div>
                    </div>
                  </Link>
                </div>
              </nav>
            </div>
          </div>
        )}
      </header>

      {/* Click outside to close dropdowns */}
      {(isLoginDropdownOpen || isMobileMenuOpen) && (
        <div
          className="fixed inset-0 z-30 bg-black/20 backdrop-blur-sm"
          onClick={() => {
            setIsLoginDropdownOpen(false)
            setIsMobileMenuOpen(false)
          }}
        />
      )}

      {/* Spacer for fixed header */}
      <div className="h-16 sm:h-18 md:h-20 lg:h-24" />
    </>
  )
}
