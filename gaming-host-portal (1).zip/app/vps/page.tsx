import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, Server, Shield, Zap, HardDrive } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import Link from "next/link"

export default function VPSPage() {
  const plans = [
    {
      name: "VPS Starter",
      ram: "2 GB",
      cpu: "1 vCPU",
      storage: "20 GB NVMe",
      bandwidth: "1 TB",
      price: "€9.99",
      popular: false,
      productId: "51",
      features: ["Full Root Access", "Multiple OS", "DDoS Protection", "24/7 Support", "99.9% Uptime", "Control Panel"],
    },
    {
      name: "VPS Basic",
      ram: "4 GB",
      cpu: "2 vCPU",
      storage: "40 GB NVMe",
      bandwidth: "2 TB",
      price: "€16.99",
      popular: false,
      productId: "52",
      features: [
        "Full Root Access",
        "Multiple OS",
        "DDoS Protection",
        "24/7 Support",
        "99.9% Uptime",
        "Control Panel",
        "Snapshots",
      ],
    },
    {
      name: "VPS Standard",
      ram: "8 GB",
      cpu: "4 vCPU",
      storage: "80 GB NVMe",
      bandwidth: "4 TB",
      price: "€29.99",
      popular: true,
      productId: "53",
      features: [
        "Full Root Access",
        "Multiple OS",
        "DDoS Protection",
        "24/7 Support",
        "99.9% Uptime",
        "Control Panel",
        "Snapshots",
        "Priority Support",
      ],
    },
    {
      name: "VPS Advanced",
      ram: "16 GB",
      cpu: "6 vCPU",
      storage: "160 GB NVMe",
      bandwidth: "6 TB",
      price: "€49.99",
      popular: false,
      productId: "54",
      features: [
        "Full Root Access",
        "Multiple OS",
        "DDoS Protection",
        "24/7 Support",
        "99.9% Uptime",
        "Control Panel",
        "Snapshots",
        "Priority Support",
        "Dedicated IP",
      ],
    },
    {
      name: "VPS Professional",
      ram: "32 GB",
      cpu: "8 vCPU",
      storage: "320 GB NVMe",
      bandwidth: "8 TB",
      price: "€79.99",
      popular: false,
      productId: "55",
      features: [
        "Full Root Access",
        "Multiple OS",
        "DDoS Protection",
        "24/7 Support",
        "99.9% Uptime",
        "Control Panel",
        "Snapshots",
        "Priority Support",
        "Dedicated IP",
        "Custom Setup",
      ],
    },
    {
      name: "VPS Enterprise",
      ram: "64 GB",
      cpu: "12 vCPU",
      storage: "640 GB NVMe",
      bandwidth: "10 TB",
      price: "€129.99",
      popular: false,
      productId: "56",
      features: [
        "Full Root Access",
        "Multiple OS",
        "DDoS Protection",
        "24/7 Support",
        "99.9% Uptime",
        "Control Panel",
        "Snapshots",
        "Dedicated Support",
        "Dedicated IP",
        "Custom Setup",
        "Managed Service",
      ],
    },
  ]

  const features = [
    {
      icon: <Server className="w-6 h-6 sm:w-8 sm:h-8 text-blue-400" />,
      title: "Full Root Access",
      description: "Complete administrative control over your virtual private server with root/administrator access.",
    },
    {
      icon: <HardDrive className="w-6 h-6 sm:w-8 sm:h-8 text-green-400" />,
      title: "NVMe SSD Storage",
      description: "Lightning-fast NVMe SSD storage for superior performance and faster data access speeds.",
    },
    {
      icon: <Shield className="w-6 h-6 sm:w-8 sm:h-8 text-red-400" />,
      title: "DDoS Protection",
      description: "Advanced DDoS protection included with all VPS plans to keep your services online.",
    },
    {
      icon: <Zap className="w-6 h-6 sm:w-8 sm:h-8 text-yellow-400" />,
      title: "High Performance",
      description: "AMD Ryzen processors with guaranteed resources for consistent high-performance computing.",
    },
  ]

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <Header />

      <main className="pt-16">
        {/* Hero Section */}
        <section className="py-12 sm:py-20 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12 sm:mb-16">
              <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Server className="w-8 h-8 sm:w-10 sm:h-10 text-white" />
              </div>
              <h1 className="text-3xl sm:text-4xl lg:text-6xl font-bold mb-6">
                VPS <span className="text-blue-400">Hosting</span>
              </h1>
              <p className="text-base sm:text-xl text-slate-300 max-w-4xl mx-auto leading-relaxed px-4">
                Powerful Virtual Private Servers with full root access, NVMe SSD storage, and guaranteed resources.
                Perfect for web hosting, application deployment, game servers, and development environments. Get
                complete control over your server with multiple operating system options and 24/7 expert support.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 max-w-6xl mx-auto">
              {features.map((feature, index) => (
                <Card
                  key={index}
                  className="bg-slate-900/50 border-slate-800 hover:border-blue-500/50 transition-all duration-300"
                >
                  <CardHeader className="text-center p-4 sm:p-6">
                    <div className="mb-3 sm:mb-4">{feature.icon}</div>
                    <CardTitle className="text-white text-base sm:text-lg">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="p-4 sm:p-6 pt-0">
                    <p className="text-slate-300 text-sm text-center">{feature.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Pricing Section */}
        <section className="py-12 sm:py-20">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12 sm:mb-16">
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold mb-4">VPS Hosting Plans</h2>
              <div className="w-24 h-1 bg-blue-500 mx-auto mb-6"></div>
              <p className="text-base sm:text-xl text-slate-300 max-w-3xl mx-auto px-4">
                Choose the perfect VPS hosting plan for your needs. All plans include full root access, DDoS protection,
                and 24/7 support.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
              {plans.map((plan, index) => (
                <Card
                  key={index}
                  className={`relative bg-slate-900/50 border-slate-800 hover:border-slate-700 transition-all duration-300 ${
                    plan.popular ? "ring-2 ring-blue-500 scale-105" : ""
                  }`}
                >
                  {plan.popular && (
                    <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-blue-600 text-white text-xs sm:text-sm">
                      Most Popular
                    </Badge>
                  )}

                  <CardHeader className="text-center p-4 sm:p-6">
                    <CardTitle className="text-white text-lg sm:text-xl">{plan.name}</CardTitle>
                    <div className="text-2xl sm:text-3xl font-bold text-white mt-4">
                      {plan.price}
                      <span className="text-slate-400 text-base sm:text-lg font-normal">/month</span>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-4 p-4 sm:p-6">
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div>
                        <p className="text-slate-400 text-xs">RAM</p>
                        <p className="text-white font-semibold text-xs sm:text-sm">{plan.ram}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-xs">CPU</p>
                        <p className="text-white font-semibold text-xs sm:text-sm">{plan.cpu}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-xs">Storage</p>
                        <p className="text-white font-semibold text-xs sm:text-sm">{plan.storage}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-xs">Bandwidth</p>
                        <p className="text-white font-semibold text-xs sm:text-sm">{plan.bandwidth}</p>
                      </div>
                    </div>

                    <div className="space-y-2 pt-4">
                      {plan.features.map((feature, featureIndex) => (
                        <div key={featureIndex} className="flex items-center space-x-2">
                          <Check className="w-3 h-3 sm:w-4 sm:h-4 text-green-400 flex-shrink-0" />
                          <span className="text-slate-300 text-xs sm:text-sm">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>

                  <CardFooter className="p-4 sm:p-6">
                    <Button className="w-full bg-blue-600 hover:bg-blue-700 py-3 text-sm sm:text-base" asChild>
                      <Link href={`https://billing.avoxhosting.com/cart.php?a=add&pid=${plan.productId}`}>
                        Order Now
                      </Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
