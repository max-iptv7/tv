"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Star, Quote, User, Shield, Zap } from "lucide-react"
import { useState, useEffect } from "react"

export function Testimonials3DSection() {
  const [activeTestimonial, setActiveTestimonial] = useState(0)
  const [isVisible, setIsVisible] = useState(false)

  const testimonials = [
    {
      name: "Alex Rodriguez",
      role: "FiveM Server Owner",
      server: "Los Santos Roleplay",
      avatar: "AR",
      rating: 5,
      text: "Avox Hosting transformed our FiveM server experience. The performance is incredible, and our 200+ players never experience lag. The txAdmin integration and 24/7 support are game-changers!",
      gradient: "from-purple-500 to-pink-500",
      stats: { players: "200+", uptime: "99.98%" },
    },
    {
      name: "Sarah Chen",
      role: "Minecraft Community Manager",
      server: "CraftWorld Network",
      avatar: "SC",
      rating: 5,
      text: "We've been running our Minecraft network on Avox for 2 years. The modpack support, automatic backups, and instant scaling have been perfect for our growing community of 500+ players.",
      gradient: "from-green-500 to-emerald-500",
      stats: { players: "500+", uptime: "99.99%" },
    },
    {
      name: "Marcus Johnson",
      role: "SA-MP Developer",
      server: "Street Racing SA",
      avatar: "MJ",
      rating: 5,
      text: "The custom plugin support and server optimization on Avox is unmatched. Our racing server runs flawlessly with complex scripts and high player counts. Best hosting decision we ever made!",
      gradient: "from-orange-500 to-red-500",
      stats: { players: "150+", uptime: "99.97%" },
    },
    {
      name: "Emma Thompson",
      role: "Discord Bot Developer",
      server: "Gaming Hub Bots",
      avatar: "ET",
      rating: 5,
      text: "Running 15+ Discord bots on Avox has been seamless. The 24/7 uptime, easy deployment, and multi-language support make it perfect for our bot development business.",
      gradient: "from-blue-500 to-cyan-500",
      stats: { bots: "15+", uptime: "100%" },
    },
    {
      name: "David Kim",
      role: "VPS Administrator",
      server: "TechStart Solutions",
      avatar: "DK",
      rating: 5,
      text: "The VPS performance is outstanding. Full root access, NVMe storage, and the control panel make server management effortless. Perfect for our web applications and game servers.",
      gradient: "from-indigo-500 to-purple-500",
      stats: { servers: "8", uptime: "99.99%" },
    },
    {
      name: "Lisa Wang",
      role: "MTA Server Owner",
      server: "Vice City Roleplay",
      avatar: "LW",
      rating: 5,
      text: "The Lua scripting environment and resource management tools are incredible. Our MTA roleplay server has never been more stable, and the support team knows their stuff!",
      gradient: "from-teal-500 to-green-500",
      stats: { players: "300+", uptime: "99.96%" },
    },
  ]

  useEffect(() => {
    setIsVisible(true)
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length)
    }, 5000)
    return () => clearInterval(interval)
  }, [testimonials.length])

  return (
    <section className="py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_30%,rgba(59,130,246,0.1),transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_70%,rgba(147,51,234,0.1),transparent_50%)]" />

      <div className="container mx-auto px-4 relative z-10">
        {/* Header */}
        <div className="text-center mb-20">
          <div className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-yellow-500/20 to-orange-500/20 rounded-full border border-yellow-500/30 backdrop-blur-sm mb-8">
            <Star className="w-5 h-5 text-yellow-400 mr-2" />
            <span className="text-yellow-300 font-semibold">5-Star Reviews • 10,000+ Happy Customers</span>
          </div>

          <h2 className="text-4xl lg:text-6xl font-black mb-6">
            <span className="text-white">What Our</span>
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500">
              Customers Say
            </span>
          </h2>
          <div className="w-32 h-1 bg-gradient-to-r from-blue-500 to-purple-500 mx-auto mb-8 rounded-full" />
          <p className="text-xl text-slate-300 max-w-4xl mx-auto leading-relaxed">
            Don't just take our word for it. Here's what gaming communities worldwide say about Avox Hosting.
          </p>
        </div>

        {/* Main Testimonial */}
        <div className="max-w-6xl mx-auto mb-16">
          <Card
            className={`relative bg-gradient-to-br from-slate-900/90 to-slate-800/90 backdrop-blur-xl border border-slate-700/50 shadow-2xl transform-gpu transition-all duration-700 ${
              isVisible ? "opacity-100 scale-100" : "opacity-0 scale-95"
            }`}
            style={{
              transform: `perspective(1000px) rotateX(2deg) rotateY(2deg) translateZ(20px)`,
            }}
          >
            {/* Glow Effect */}
            <div
              className={`absolute inset-0 bg-gradient-to-r ${testimonials[activeTestimonial].gradient} opacity-10 rounded-lg blur-xl`}
            />

            <CardContent className="p-12 relative">
              <div className="grid lg:grid-cols-3 gap-12 items-center">
                {/* Quote */}
                <div className="lg:col-span-2">
                  <Quote className="w-12 h-12 text-blue-400 mb-6 opacity-50" />
                  <blockquote className="text-2xl lg:text-3xl text-white leading-relaxed font-medium mb-8">
                    "{testimonials[activeTestimonial].text}"
                  </blockquote>

                  {/* Rating */}
                  <div className="flex items-center space-x-2 mb-6">
                    {[...Array(testimonials[activeTestimonial].rating)].map((_, i) => (
                      <Star key={i} className="w-6 h-6 text-yellow-400 fill-current" />
                    ))}
                    <span className="text-slate-400 ml-2">({testimonials[activeTestimonial].rating}.0/5.0)</span>
                  </div>

                  {/* Author */}
                  <div className="flex items-center space-x-4">
                    <div
                      className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${testimonials[activeTestimonial].gradient} flex items-center justify-center text-white font-bold text-xl shadow-lg`}
                    >
                      {testimonials[activeTestimonial].avatar}
                    </div>
                    <div>
                      <div className="text-white font-bold text-xl">{testimonials[activeTestimonial].name}</div>
                      <div className="text-slate-400">{testimonials[activeTestimonial].role}</div>
                      <div className="text-slate-500 text-sm">{testimonials[activeTestimonial].server}</div>
                    </div>
                  </div>
                </div>

                {/* Stats */}
                <div className="space-y-6">
                  <h3 className="text-white font-bold text-xl mb-6">Server Stats</h3>
                  {Object.entries(testimonials[activeTestimonial].stats).map(([key, value], index) => (
                    <div key={index} className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700/30">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400 capitalize">{key}</span>
                        <span
                          className={`text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r ${testimonials[activeTestimonial].gradient}`}
                        >
                          {value}
                        </span>
                      </div>
                    </div>
                  ))}

                  {/* Verification Badge */}
                  <div className="bg-green-500/10 border border-green-500/30 rounded-2xl p-4 flex items-center space-x-3">
                    <Shield className="w-6 h-6 text-green-400" />
                    <div>
                      <div className="text-green-400 font-semibold">Verified Customer</div>
                      <div className="text-green-300 text-sm">Active since 2022</div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Testimonial Navigation */}
        <div className="flex justify-center space-x-4 mb-16">
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => setActiveTestimonial(index)}
              className={`w-4 h-4 rounded-full transition-all duration-300 ${
                index === activeTestimonial
                  ? `bg-gradient-to-r ${testimonials[index].gradient} scale-125`
                  : "bg-slate-600 hover:bg-slate-500"
              }`}
            />
          ))}
        </div>

        {/* Customer Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.slice(0, 6).map((testimonial, index) => (
            <Card
              key={index}
              className={`group bg-gradient-to-br from-slate-900/80 to-slate-800/80 backdrop-blur-xl border border-slate-700/50 hover:border-slate-600/50 transition-all duration-500 transform-gpu hover:scale-105 cursor-pointer ${
                index === activeTestimonial ? `ring-2 ring-blue-500/50` : ""
              }`}
              onClick={() => setActiveTestimonial(index)}
            >
              {/* Glow Effect */}
              <div
                className={`absolute inset-0 bg-gradient-to-r ${testimonial.gradient} opacity-0 group-hover:opacity-10 rounded-lg blur-xl transition-opacity duration-500`}
              />

              <CardContent className="p-6 relative">
                <div className="flex items-center space-x-4 mb-4">
                  <div
                    className={`w-12 h-12 rounded-xl bg-gradient-to-br ${testimonial.gradient} flex items-center justify-center text-white font-bold shadow-lg`}
                  >
                    {testimonial.avatar}
                  </div>
                  <div>
                    <div className="text-white font-bold">{testimonial.name}</div>
                    <div className="text-slate-400 text-sm">{testimonial.role}</div>
                  </div>
                </div>

                <div className="flex items-center space-x-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                  ))}
                </div>

                <p className="text-slate-300 text-sm leading-relaxed line-clamp-3">{testimonial.text}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Trust Indicators */}
        <div className="mt-20 text-center">
          <div className="grid md:grid-cols-4 gap-8 max-w-4xl mx-auto">
            {[
              { icon: <Star className="w-8 h-8 text-yellow-400" />, value: "4.9/5", label: "Average Rating" },
              { icon: <User className="w-8 h-8 text-blue-400" />, value: "10K+", label: "Happy Customers" },
              { icon: <Shield className="w-8 h-8 text-green-400" />, value: "100%", label: "Verified Reviews" },
              { icon: <Zap className="w-8 h-8 text-purple-400" />, value: "24/7", label: "Support Rating" },
            ].map((stat, index) => (
              <div key={index} className="text-center">
                <div className="mb-4">{stat.icon}</div>
                <div className="text-3xl font-bold text-white mb-2">{stat.value}</div>
                <div className="text-slate-400 text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
