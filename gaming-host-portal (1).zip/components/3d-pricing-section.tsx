"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, Server, Crown, Zap, ArrowRight, Star, Flame } from "lucide-react"
import { useState } from "react"
import Link from "next/link"

export function Pricing3DSection() {
  const [hoveredPlan, setHoveredPlan] = useState<number | null>(null)

  const plans = [
    {
      name: "Minecraft Pro",
      service: "Minecraft Hosting",
      specs: "4GB RAM • 4 vCPU • 40GB NVMe",
      players: "Up to 50 Players",
      price: "€12.99",
      originalPrice: "€19.99",
      period: "/mo",
      popular: false,
      gradient: "from-green-500 to-emerald-500",
      icon: <Server className="w-5 h-5" />,
      productId: "3",
      features: [
        "All Minecraft Versions",
        "Plugin Support & Manager",
        "Automatic World Backups",
        "Advanced DDoS Protection",
        "24/7 Priority Support",
        "One-Click Modpack Install",
        "Custom Server Properties",
        "Real-time Performance Monitor",
      ],
      savings: "35%",
    },
    {
      name: "FiveM Ultimate",
      service: "GTA V Roleplay",
      specs: "8GB RAM • 6 vCPU • 80GB NVMe",
      players: "Up to 128 Players",
      price: "€24.99",
      originalPrice: "€39.99",
      period: "/mo",
      popular: true,
      gradient: "from-purple-500 to-pink-500",
      icon: <Crown className="w-5 h-5" />,
      productId: "4",
      features: [
        "ESX/QBCore Pre-installed",
        "txAdmin Control Panel",
        "Unlimited Custom Resources",
        "MySQL Database Included",
        "24/7 Dedicated Support",
        "Auto Server Optimization",
        "Advanced Security Features",
        "Custom Framework Setup",
      ],
      savings: "38%",
    },
    {
      name: "VPS Enterprise",
      service: "Virtual Private Server",
      specs: "16GB RAM • 8 vCPU • 160GB NVMe",
      players: "Unlimited Usage",
      price: "€49.99",
      originalPrice: "€79.99",
      period: "/mo",
      popular: false,
      gradient: "from-blue-500 to-cyan-500",
      icon: <Zap className="w-5 h-5" />,
      productId: "6",
      features: [
        "Full Root Access",
        "Multiple OS Support",
        "Advanced DDoS Protection",
        "NVMe SSD Storage",
        "24/7 Expert Support",
        "Instant Provisioning",
        "99.99% Uptime SLA",
        "Free Server Management",
      ],
      savings: "37%",
    },
  ]

  return (
    <section id="pricing" className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(59,130,246,0.08),transparent_50%)]" />

      <div className="container mx-auto px-4 relative z-10">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 text-green-300 border-green-500/30 px-4 py-2 mb-6">
            <Flame className="w-4 h-4 mr-2" />
            Limited Time Offer - Save up to 38%
          </Badge>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black mb-6">
            <span className="text-white">Choose Your</span>
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500">
              Perfect Plan
            </span>
          </h2>

          <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-purple-500 mx-auto mb-6 rounded-full" />

          <p className="text-lg text-slate-300 max-w-3xl mx-auto leading-relaxed">
            Select from our most popular gaming server plans with enterprise-grade features, guaranteed performance, and
            24/7 expert support. All plans include advanced DDoS protection and instant setup.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <Card
              key={index}
              className={`group relative bg-gradient-to-br from-slate-900/80 to-slate-800/80 backdrop-blur-sm border transition-all duration-500 transform hover:scale-105 ${
                plan.popular
                  ? "ring-2 ring-purple-500/50 scale-105 shadow-2xl shadow-purple-500/20"
                  : "border-slate-700/50 hover:border-slate-600/50"
              }`}
              onMouseEnter={() => setHoveredPlan(index)}
              onMouseLeave={() => setHoveredPlan(null)}
            >
              {/* Glow Effect */}
              <div
                className={`absolute inset-0 bg-gradient-to-r ${plan.gradient} opacity-0 group-hover:opacity-5 rounded-lg transition-opacity duration-500`}
              />

              {plan.popular && (
                <>
                  <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg px-4 py-1 text-sm font-bold z-10">
                    🔥 MOST POPULAR
                  </Badge>
                </>
              )}

              {/* Savings Badge */}
              <div className="absolute top-4 right-4 bg-gradient-to-r from-green-500 to-emerald-500 text-white px-2 py-1 rounded-full text-xs font-bold">
                Save {plan.savings}
              </div>

              <CardHeader className="text-center relative pt-8">
                <div
                  className={`w-14 h-14 rounded-xl bg-gradient-to-br ${plan.gradient} flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-all duration-300 shadow-lg`}
                >
                  {plan.icon}
                </div>

                <CardTitle className="text-white text-xl mb-2">{plan.name}</CardTitle>
                <p className="text-slate-400 mb-4 text-sm">{plan.service}</p>

                <div className="space-y-2">
                  <div className="flex items-center justify-center space-x-2">
                    <span className="text-base text-slate-400 line-through">{plan.originalPrice}</span>
                    <span className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">
                      {plan.price}
                    </span>
                    <span className="text-slate-400">{plan.period}</span>
                  </div>
                  <p className="text-sm text-green-400 font-medium">Limited Time Offer!</p>
                </div>
              </CardHeader>

              <CardContent className="space-y-6">
                <div className="text-center space-y-1 p-3 bg-slate-800/50 rounded-lg border border-slate-700/30">
                  <p className="text-slate-300 font-medium text-sm">{plan.specs}</p>
                  <p className="text-xs text-slate-400">{plan.players}</p>
                </div>

                <div className="space-y-2">
                  {plan.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-center space-x-3">
                      <Check className="w-4 h-4 text-green-400 flex-shrink-0" />
                      <span className="text-slate-300 text-sm">{feature}</span>
                    </div>
                  ))}
                </div>

                {/* Rating */}
                <div className="flex items-center justify-center space-x-2 pt-2">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-3 h-3 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <span className="text-xs text-slate-400">(4.9/5)</span>
                </div>
              </CardContent>

              <CardFooter>
                <Button
                  className={`w-full bg-gradient-to-r ${plan.gradient} hover:shadow-lg transition-all duration-300 group-hover:scale-105 font-medium py-3 rounded-lg`}
                  asChild
                >
                  <Link href={`https://billing.avoxhosting.com/cart.php?a=add&pid=${plan.productId}`}>
                    <span>Get Started Now</span>
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-12">
          <div className="bg-gradient-to-br from-slate-900/80 to-slate-800/80 backdrop-blur-sm rounded-2xl p-8 border border-slate-700/50 shadow-xl max-w-3xl mx-auto">
            <h3 className="text-xl font-bold text-white mb-4">
              Need a Custom Solution?{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">
                We've Got You Covered
              </span>
            </h3>
            <p className="text-slate-300 mb-6">
              Contact our experts for enterprise solutions, bulk discounts, and custom configurations tailored to your
              specific needs.
            </p>
            <Button
              size="lg"
              variant="outline"
              className="border-slate-600 text-slate-300 hover:text-white hover:bg-slate-800 hover:border-blue-500/50 bg-transparent px-8 py-3 rounded-xl transition-all duration-300"
              asChild
            >
              <Link href="https://billing.avoxhosting.com/contact.php">Contact Sales Team</Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
