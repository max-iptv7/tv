"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Cpu,
  HardDrive,
  Zap,
  Globe,
  ArrowRight,
  Play,
  Star,
  Shield,
  Rocket,
  Crown,
  Sparkles,
  Server,
  Activity,
  Wifi,
} from "lucide-react"
import { useEffect, useRef, useState } from "react"
import Link from "next/link"
import Image from "next/image"

export function FuturisticHeroSection() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const [isVisible, setIsVisible] = useState(false)
  const [activeMetric, setActiveMetric] = useState(0)
  const heroRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    setIsVisible(true)

    const handleMouseMove = (e: MouseEvent) => {
      if (heroRef.current) {
        const rect = heroRef.current.getBoundingClientRect()
        setMousePosition({
          x: (e.clientX - rect.left) / rect.width,
          y: (e.clientY - rect.top) / rect.height,
        })
      }
    }

    const heroElement = heroRef.current
    if (heroElement) {
      heroElement.addEventListener("mousemove", handleMouseMove)
    }

    // Cycle through metrics
    const metricTimer = setInterval(() => {
      setActiveMetric((prev) => (prev + 1) % 3)
    }, 2000)

    return () => {
      if (heroElement) {
        heroElement.removeEventListener("mousemove", handleMouseMove)
      }
      clearInterval(metricTimer)
    }
  }, [])

  const metrics = [
    { label: "CPU Performance", value: 98, color: "from-cyan-400 to-blue-500", icon: <Cpu className="w-5 h-5" /> },
    { label: "Network Speed", value: 95, color: "from-green-400 to-emerald-500", icon: <Wifi className="w-5 h-5" /> },
    {
      label: "Server Uptime",
      value: 99.9,
      color: "from-orange-400 to-red-500",
      icon: <Activity className="w-5 h-5" />,
    },
  ]

  return (
    <section
      ref={heroRef}
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-32 px-4 sm:px-6 lg:px-8"
    >
      {/* Dynamic Background */}
      <div className="absolute inset-0">
        {/* Gradient Base */}
        <div
          className="absolute inset-0 transition-all duration-1000"
          style={{
            background: `
              radial-gradient(circle at ${mousePosition.x * 100}% ${mousePosition.y * 100}%, 
              rgba(249, 115, 22, 0.15) 0%, 
              rgba(239, 68, 68, 0.1) 25%, 
              rgba(147, 51, 234, 0.08) 50%,
              transparent 70%),
              linear-gradient(135deg, #0f172a 0%, #1e293b 30%, #0f172a 70%, #1e293b 100%)
            `,
          }}
        />

        {/* Animated Grid */}
        <div
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: `
              linear-gradient(rgba(249, 115, 22, 0.3) 1px, transparent 1px),
              linear-gradient(90deg, rgba(249, 115, 22, 0.3) 1px, transparent 1px)
            `,
            backgroundSize: "80px 80px",
            transform: `translate(${mousePosition.x * 20}px, ${mousePosition.y * 20}px)`,
            transition: "transform 0.5s ease-out",
          }}
        />

        {/* Floating Elements */}
        {[...Array(15)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full opacity-60"
            style={{
              width: `${12 + Math.random() * 20}px`,
              height: `${12 + Math.random() * 20}px`,
              background: `radial-gradient(circle, 
                ${["#f97316", "#ef4444", "#8b5cf6", "#06b6d4", "#10b981"][Math.floor(Math.random() * 5)]}, 
                transparent)`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `float ${8 + Math.random() * 12}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 5}s`,
              boxShadow: `0 0 40px ${["#f97316", "#ef4444", "#8b5cf6", "#06b6d4", "#10b981"][Math.floor(Math.random() * 5)]}60`,
            }}
          />
        ))}
      </div>

      <div className="container mx-auto relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-24 items-center">
          {/* Content */}
          <div
            className={`space-y-10 text-center lg:text-left transition-all duration-1000 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
          >
            {/* Trust Badges */}
            <div className="flex flex-wrap justify-center lg:justify-start gap-4">
              <Badge className="bg-gradient-to-r from-emerald-500/20 to-green-500/20 text-emerald-300 border-emerald-500/30 px-5 py-2 text-sm font-bold">
                <Shield className="w-4 h-4 mr-2" />
                99.9% UPTIME
              </Badge>
              <Badge className="bg-gradient-to-r from-orange-500/20 to-red-500/20 text-orange-300 border-orange-500/30 px-5 py-2 text-sm font-bold">
                <Zap className="w-4 h-4 mr-2" />
                INSTANT DEPLOY
              </Badge>
              <Badge className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 text-purple-300 border-purple-500/30 px-5 py-2 text-sm font-bold">
                <Crown className="w-4 h-4 mr-2" />
                PREMIUM TIER
              </Badge>
            </div>

            {/* Main Title */}
            <div className="space-y-6">
              <h1 className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl font-black leading-none">
                <span className="block text-white mb-3">NEXT-GEN</span>
                <span className="block bg-gradient-to-r from-orange-400 via-red-500 to-purple-500 bg-clip-text text-transparent mb-3">
                  GAMING
                </span>
                <span className="block bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 bg-clip-text text-transparent">
                  SERVERS
                </span>
              </h1>

              <p className="text-xl sm:text-2xl md:text-3xl text-slate-300 leading-relaxed max-w-3xl mx-auto lg:mx-0 font-medium">
                Unleash the power of{" "}
                <span className="bg-gradient-to-r from-orange-400 to-red-500 bg-clip-text text-transparent font-black">
                  AVOX HOSTING
                </span>{" "}
                — where cutting-edge technology meets unparalleled gaming performance. Experience lightning-fast
                servers, military-grade security, and 24/7 expert support.
              </p>
            </div>

            {/* Performance Metrics */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 py-8">
              {[
                {
                  icon: <Shield className="w-6 h-6" />,
                  text: "DDoS PROTECTED",
                  color: "text-emerald-400",
                  bg: "from-emerald-500/10 to-green-500/10",
                  border: "border-emerald-500/20",
                },
                {
                  icon: <Zap className="w-6 h-6" />,
                  text: "INSTANT SETUP",
                  color: "text-orange-400",
                  bg: "from-orange-500/10 to-red-500/10",
                  border: "border-orange-500/20",
                },
                {
                  icon: <Globe className="w-6 h-6" />,
                  text: "GLOBAL NETWORK",
                  color: "text-blue-400",
                  bg: "from-blue-500/10 to-cyan-500/10",
                  border: "border-blue-500/20",
                },
              ].map((feature, index) => (
                <div
                  key={index}
                  className={`flex items-center justify-center lg:justify-start space-x-3 bg-gradient-to-r ${feature.bg} border ${feature.border} px-6 py-4 rounded-2xl backdrop-blur-sm hover:scale-105 transition-all duration-300 group`}
                >
                  <div className={`${feature.color} group-hover:scale-110 transition-transform duration-300`}>
                    {feature.icon}
                  </div>
                  <span className="text-slate-300 font-black text-sm">{feature.text}</span>
                </div>
              ))}
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-6 justify-center lg:justify-start">
              <Button
                size="lg"
                className="group bg-gradient-to-r from-orange-500 via-red-500 to-purple-500 hover:from-orange-600 hover:via-red-600 hover:to-purple-600 text-white text-xl font-black px-10 py-6 rounded-2xl shadow-2xl hover:shadow-orange-500/30 transition-all duration-300 transform hover:scale-105"
                asChild
              >
                <Link href="https://billing.avoxhosting.com/cart.php">
                  <Rocket className="mr-4 w-6 h-6 group-hover:rotate-12 transition-transform duration-300" />
                  <span>LAUNCH NOW</span>
                  <ArrowRight className="ml-4 w-6 h-6 group-hover:translate-x-2 transition-transform duration-300" />
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="group border-3 border-slate-600 text-slate-300 hover:text-white hover:bg-slate-800/50 text-xl font-black px-10 py-6 rounded-2xl backdrop-blur-sm hover:border-orange-500/50 transition-all duration-300 bg-transparent"
                asChild
              >
                <Link href="#demo">
                  <Play className="mr-4 w-6 h-6 group-hover:scale-110 transition-transform duration-300" />
                  <span>WATCH DEMO</span>
                </Link>
              </Button>
            </div>

            {/* Live Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 pt-10 border-t border-slate-800/50">
              {[
                {
                  value: "99.9%",
                  label: "UPTIME SLA",
                  color: "from-emerald-400 to-green-500",
                  icon: <Shield className="w-5 h-5" />,
                },
                {
                  value: "250K+",
                  label: "SERVERS DEPLOYED",
                  color: "from-orange-400 to-red-500",
                  icon: <Server className="w-5 h-5" />,
                },
                {
                  value: "<15s",
                  label: "SETUP TIME",
                  color: "from-purple-400 to-pink-500",
                  icon: <Zap className="w-5 h-5" />,
                },
              ].map((stat, index) => (
                <div key={index} className="text-center group">
                  <div className="flex items-center justify-center space-x-3 mb-3">
                    <div className={`bg-gradient-to-r ${stat.color} bg-clip-text text-transparent`}>{stat.icon}</div>
                    <div
                      className={`text-4xl sm:text-5xl font-black bg-gradient-to-r ${stat.color} bg-clip-text text-transparent`}
                    >
                      {stat.value}
                    </div>
                  </div>
                  <div className="text-sm text-slate-400 group-hover:text-slate-300 transition-colors font-bold tracking-wider">
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Server Visualization */}
          <div
            className={`relative transition-all duration-1000 delay-500 ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-10"}`}
          >
            <div className="relative w-full max-w-2xl mx-auto">
              {/* Main Server Panel */}
              <div
                className="relative bg-gradient-to-br from-slate-900/95 to-slate-800/95 backdrop-blur-2xl rounded-3xl p-10 border border-slate-700/50 shadow-2xl"
                style={{
                  transform: `
                    perspective(1200px) 
                    rotateX(${mousePosition.y * 10 - 5}deg) 
                    rotateY(${mousePosition.x * 10 - 5}deg)
                  `,
                  transition: "transform 0.3s ease-out",
                }}
              >
                {/* Header */}
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center space-x-4">
                    <div className="w-16 h-16 relative">
                      <div className="absolute inset-0 bg-gradient-to-r from-orange-500 to-red-500 rounded-2xl blur-lg opacity-60" />
                      <div className="relative w-full h-full bg-slate-900 rounded-2xl border-2 border-orange-500/40 flex items-center justify-center">
                        <Image
                          src="/images/avox-logo.png"
                          alt="Avox Hosting"
                          width={40}
                          height={40}
                          className="w-10 h-10 object-contain"
                        />
                      </div>
                    </div>
                    <div>
                      <h3 className="font-black text-white text-2xl">AVOX GAMING</h3>
                      <p className="text-slate-400 font-medium">Premium Infrastructure</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-4 h-4 bg-emerald-400 rounded-full animate-pulse" />
                    <span className="text-emerald-400 font-bold text-lg">ONLINE</span>
                  </div>
                </div>

                {/* Server Specs */}
                <div className="grid grid-cols-2 gap-6 mb-8">
                  {[
                    {
                      icon: <Cpu className="w-6 h-6 text-cyan-400" />,
                      label: "AMD RYZEN™ 9",
                      value: "7950X3D GAMING",
                      gradient: "from-cyan-500 to-blue-500",
                    },
                    {
                      icon: <HardDrive className="w-6 h-6 text-purple-400" />,
                      label: "NVME SSD",
                      value: "UP TO 16TB",
                      gradient: "from-purple-500 to-pink-500",
                    },
                    {
                      icon: <Zap className="w-6 h-6 text-emerald-400" />,
                      label: "DDR5 RAM",
                      value: "UP TO 256GB",
                      gradient: "from-emerald-500 to-green-500",
                    },
                    {
                      icon: <Globe className="w-6 h-6 text-orange-400" />,
                      label: "NETWORK",
                      value: "10 GBPS",
                      gradient: "from-orange-500 to-red-500",
                    },
                  ].map((spec, index) => (
                    <div
                      key={index}
                      className={`bg-gradient-to-br ${spec.gradient}/10 border border-slate-700/30 rounded-2xl p-6 hover:scale-105 transition-all duration-300 group`}
                    >
                      <div className="flex items-center space-x-3 mb-3">
                        <div className="group-hover:scale-110 transition-transform duration-300">{spec.icon}</div>
                        <span className="text-xs text-slate-400 font-bold tracking-wider">{spec.label}</span>
                      </div>
                      <div className="text-sm font-black text-white">{spec.value}</div>
                    </div>
                  ))}
                </div>

                {/* Live Metrics */}
                <div className="space-y-6">
                  {metrics.map((metric, index) => (
                    <div
                      key={index}
                      className={`transition-all duration-500 ${activeMetric === index ? "scale-105" : "scale-100"}`}
                    >
                      <div className="flex justify-between items-center text-sm mb-3">
                        <div className="flex items-center space-x-2">
                          <div className={`bg-gradient-to-r ${metric.color} bg-clip-text text-transparent`}>
                            {metric.icon}
                          </div>
                          <span className="text-slate-400 font-bold">{metric.label}</span>
                        </div>
                        <span className="text-white font-black text-lg">{metric.value}%</span>
                      </div>
                      <div className="w-full bg-slate-700/50 rounded-full h-3 overflow-hidden">
                        <div
                          className={`bg-gradient-to-r ${metric.color} h-3 rounded-full transition-all duration-1000 relative overflow-hidden ${activeMetric === index ? "animate-pulse" : ""}`}
                          style={{ width: `${metric.value}%` }}
                        >
                          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-pulse" />
                          <div className="absolute right-0 top-0 w-6 h-full bg-white/60 blur-sm" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Floating Elements */}
              <div className="absolute -top-6 -right-6 w-12 h-12 bg-gradient-to-br from-pink-500 to-red-500 rounded-2xl animate-bounce flex items-center justify-center shadow-2xl">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div className="absolute -bottom-4 -left-4 w-10 h-10 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-2xl animate-pulse flex items-center justify-center shadow-2xl">
                <Star className="w-5 h-5 text-white fill-current" />
              </div>

              {/* Glow Effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-orange-600/20 via-red-600/20 to-purple-600/20 rounded-3xl blur-3xl -z-10 animate-pulse" />
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes float {
          0%, 100% {
            transform: translateY(0px) rotate(0deg);
          }
          50% {
            transform: translateY(-40px) rotate(180deg);
          }
        }
      `}</style>
    </section>
  )
}
