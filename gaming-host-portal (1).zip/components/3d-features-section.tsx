"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { HardDrive, Shield, Clock, Star, Cpu, Headphones, Zap, Award } from "lucide-react"
import { useState, useEffect } from "react"

export function Features3DSection() {
  const [activeFeature, setActiveFeature] = useState(0)

  const features = [
    {
      icon: <HardDrive className="w-8 h-8 text-blue-400" />,
      title: "NVMe SSD Storage",
      description:
        "Lightning-fast NVMe SSD technology delivering up to 7GB/s read speeds for instant data access and seamless performance.",
      gradient: "from-blue-500 to-cyan-500",
      stats: "Up to 7GB/s",
    },
    {
      icon: <Shield className="w-8 h-8 text-red-400" />,
      title: "Advanced DDoS Protection",
      description:
        "Enterprise-level security with 17Tbps DDoS protection capacity, ensuring your servers remain online during attacks.",
      gradient: "from-red-500 to-pink-500",
      stats: "17Tbps Protection",
    },
    {
      icon: <Clock className="w-8 h-8 text-green-400" />,
      title: "Instant Deployment",
      description:
        "Automated server provisioning system deploys your gaming servers within 60 seconds of payment confirmation.",
      gradient: "from-green-500 to-emerald-500",
      stats: "< 60 Seconds",
    },
    {
      icon: <Star className="w-8 h-8 text-yellow-400" />,
      title: "5-Star Rated Service",
      description: "Consistently rated 5 stars by our gaming community with 99.9% customer satisfaction rate.",
      gradient: "from-yellow-500 to-orange-500",
      stats: "99.9% Satisfaction",
    },
    {
      icon: <Cpu className="w-8 h-8 text-purple-400" />,
      title: "AMD Ryzen™ 9 Processors",
      description:
        "Latest AMD Ryzen™ 9 7950X3D gaming processors with 3D V-Cache technology for unmatched performance.",
      gradient: "from-purple-500 to-indigo-500",
      stats: "32 Cores / 64 Threads",
    },
    {
      icon: <Headphones className="w-8 h-8 text-orange-400" />,
      title: "24/7 Expert Support",
      description:
        "Dedicated gaming specialists available around the clock with average response time under 2 minutes.",
      gradient: "from-orange-500 to-red-500",
      stats: "< 2min Response",
    },
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveFeature((prev) => (prev + 1) % features.length)
    }, 4000)
    return () => clearInterval(interval)
  }, [features.length])

  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_50%,rgba(59,130,246,0.08),transparent_70%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(147,51,234,0.08),transparent_70%)]" />

      <div className="container mx-auto px-4 relative z-10">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 text-blue-300 border-blue-500/30 px-4 py-2 mb-6">
            <Award className="w-4 h-4 mr-2" />
            Why Choose Avox Hosting?
          </Badge>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black mb-6">
            <span className="text-white">Cutting-Edge</span>
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500">
              Gaming Infrastructure
            </span>
          </h2>

          <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-purple-500 mx-auto mb-6 rounded-full" />

          <p className="text-lg text-slate-300 max-w-3xl mx-auto leading-relaxed">
            Experience next-generation gaming hosting with enterprise-grade infrastructure, cutting-edge technology, and
            unparalleled performance optimization.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {features.map((feature, index) => (
            <Card
              key={index}
              className={`group relative bg-gradient-to-br from-slate-900/80 to-slate-800/80 backdrop-blur-sm border transition-all duration-500 transform hover:scale-105 ${
                index === activeFeature
                  ? `border-blue-500/50 shadow-xl shadow-blue-500/20 scale-105`
                  : "border-slate-700/50 hover:border-slate-600/50"
              }`}
            >
              {/* Glow Effect */}
              <div
                className={`absolute inset-0 bg-gradient-to-r ${feature.gradient} opacity-0 group-hover:opacity-5 rounded-lg transition-opacity duration-500`}
              />

              {/* Active Indicator */}
              {index === activeFeature && (
                <div className="absolute -top-2 -right-2 w-3 h-3 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full animate-ping" />
              )}

              <CardHeader className="pb-4">
                <div
                  className={`mb-4 group-hover:scale-110 transition-transform duration-300 ${index === activeFeature ? "scale-110" : ""}`}
                >
                  {feature.icon}
                </div>

                <CardTitle className="text-white text-lg mb-2 group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-blue-400 group-hover:to-purple-500 transition-all duration-300">
                  {feature.title}
                </CardTitle>

                <div className={`text-sm font-bold bg-gradient-to-r ${feature.gradient} bg-clip-text text-transparent`}>
                  {feature.stats}
                </div>
              </CardHeader>

              <CardContent>
                <p className="text-slate-300 text-sm leading-relaxed">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Feature Showcase */}
        <div className="bg-gradient-to-br from-slate-900/80 to-slate-800/80 backdrop-blur-sm rounded-2xl p-8 border border-slate-700/50 shadow-xl">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold text-white mb-4">
                Experience the{" "}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">
                  Future of Gaming
                </span>
              </h3>
              <p className="text-slate-300 leading-relaxed mb-6">
                Our infrastructure is built from the ground up for gaming, with custom optimizations, intelligent
                routing, and real-time performance monitoring.
              </p>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 bg-slate-800/50 rounded-lg">
                  <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-emerald-500">
                    10ms
                  </div>
                  <div className="text-sm text-slate-400">Average Latency</div>
                </div>
                <div className="text-center p-4 bg-slate-800/50 rounded-lg">
                  <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-500">
                    50K+
                  </div>
                  <div className="text-sm text-slate-400">Active Servers</div>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="w-full h-48 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl flex items-center justify-center backdrop-blur-sm border border-blue-500/30">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center mx-auto mb-3">
                    <Zap className="w-8 h-8 text-white" />
                  </div>
                  <div className="text-xl font-bold text-white">Real-Time Monitoring</div>
                  <div className="text-slate-400 text-sm">24/7 Performance Analytics</div>
                </div>
              </div>
              <div className="absolute -top-3 -right-3 w-6 h-6 bg-gradient-to-br from-pink-500 to-red-500 rounded-full animate-bounce" />
              <div className="absolute -bottom-3 -left-3 w-4 h-4 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-full animate-pulse" />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
