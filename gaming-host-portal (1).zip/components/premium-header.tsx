"use client"

import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import Link from "next/link"
import { Menu, X, ChevronDown, Shield, Clock, Crown, Star, Zap } from "lucide-react"
import { useState, useEffect } from "react"

export function PremiumHeader() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const services = [
    { name: "SA-MP Servers", href: "/samp", icon: "🏎️", desc: "High-performance racing servers" },
    { name: "MTA Servers", href: "/mta", icon: "🎮", desc: "Multi Theft Auto hosting" },
    { name: "Minecraft Servers", href: "/minecraft", icon: "⛏️", desc: "All versions & modpacks" },
    { name: "FiveM Servers", href: "/fivem", icon: "🚗", desc: "GTA V roleplay servers" },
    { name: "Discord Bots", href: "/discord-bots", icon: "🤖", desc: "24/7 bot hosting" },
    { name: "VPS Hosting", href: "/vps", icon: "💻", desc: "Virtual private servers" },
    { name: "RDP Servers", href: "/rdp", icon: "🖥️", desc: "Windows remote desktop" },
  ]

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-slate-950/95 backdrop-blur-xl border-b border-slate-800/50 shadow-2xl" : "bg-transparent"
      }`}
    >
      <div className="container mx-auto px-4">
        {/* Top Status Bar - Desktop Only */}
        <div className="hidden md:flex items-center justify-between py-2 text-xs border-b border-slate-800/30">
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
              <span className="text-emerald-400 font-medium">All Systems Operational</span>
            </div>
            <div className="flex items-center space-x-2">
              <Shield className="w-3 h-3 text-blue-400" />
              <span className="text-slate-400">99.99% Uptime SLA</span>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="w-3 h-3 text-purple-400" />
              <span className="text-slate-400">24/7 Expert Support</span>
            </div>
          </div>
          <div className="flex items-center space-x-4 text-slate-400">
            <Link href="https://status.avoxhosting.com" className="hover:text-blue-400 transition-colors">
              Status
            </Link>
            <Link href="https://billing.avoxhosting.com/contact.php" className="hover:text-blue-400 transition-colors">
              Support
            </Link>
            <Link
              href="https://billing.avoxhosting.com/knowledgebase"
              className="hover:text-blue-400 transition-colors"
            >
              Knowledge Base
            </Link>
          </div>
        </div>

        {/* Main Header */}
        <div className="flex items-center justify-between h-16">
          {/* Premium Logo */}
          <Link href="/" className="flex items-center space-x-3 group">
            <div className="relative">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-purple-700 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-blue-500/25 transition-all duration-300">
                <Crown className="w-6 h-6 text-white" />
              </div>
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-gradient-to-r from-amber-400 to-orange-500 rounded-full animate-pulse" />
            </div>
            <div className="hidden sm:block">
              <div className="font-black text-xl bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
                Avox Hosting
              </div>
              <div className="text-xs text-slate-400 -mt-1 flex items-center space-x-1">
                <Star className="w-3 h-3 text-amber-400" />
                <span>Premium Gaming</span>
              </div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            <Link
              href="/"
              className="relative text-white hover:text-blue-400 transition-all duration-300 font-medium group"
            >
              Home
              <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-500 to-purple-500 group-hover:w-full transition-all duration-300" />
            </Link>

            <DropdownMenu>
              <DropdownMenuTrigger className="flex items-center space-x-1 text-slate-300 hover:text-white transition-colors font-medium group">
                <span>Services</span>
                <ChevronDown className="w-4 h-4 group-hover:rotate-180 transition-transform duration-300" />
              </DropdownMenuTrigger>
              <DropdownMenuContent className="bg-slate-900/95 backdrop-blur-xl border-slate-700 shadow-2xl rounded-xl p-3 min-w-[320px]">
                <div className="grid gap-2">
                  {services.map((service) => (
                    <DropdownMenuItem key={service.href} asChild>
                      <Link
                        href={service.href}
                        className="flex items-start space-x-3 px-4 py-3 text-slate-300 hover:text-white hover:bg-slate-800/50 rounded-lg transition-all duration-200 group"
                      >
                        <span className="text-xl mt-0.5">{service.icon}</span>
                        <div>
                          <div className="font-medium">{service.name}</div>
                          <div className="text-xs text-slate-400 group-hover:text-slate-300">{service.desc}</div>
                        </div>
                      </Link>
                    </DropdownMenuItem>
                  ))}
                </div>
                <div className="border-t border-slate-700 mt-3 pt-3">
                  <Link
                    href="https://billing.avoxhosting.com/cart.php"
                    className="flex items-center justify-center px-4 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all duration-300 font-medium"
                  >
                    <Zap className="w-4 h-4 mr-2" />
                    Explore All Services
                  </Link>
                </div>
              </DropdownMenuContent>
            </DropdownMenu>

            <Link
              href="#pricing"
              className="relative text-slate-300 hover:text-white transition-all duration-300 font-medium group"
            >
              Pricing
              <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-500 to-purple-500 group-hover:w-full transition-all duration-300" />
            </Link>

            <Link
              href="/about"
              className="relative text-slate-300 hover:text-white transition-all duration-300 font-medium group"
            >
              About
              <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-500 to-purple-500 group-hover:w-full transition-all duration-300" />
            </Link>

            <Link
              href="/contact"
              className="relative text-slate-300 hover:text-white transition-all duration-300 font-medium group"
            >
              Contact
              <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-500 to-purple-500 group-hover:w-full transition-all duration-300" />
            </Link>
          </nav>

          {/* Premium Login Button */}
          <div className="hidden lg:flex items-center">
            <Button
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg hover:shadow-blue-500/25 transition-all duration-300 font-medium px-6"
              asChild
            >
              <Link href="https://billing.avoxhosting.com/clientarea.php">
                <Crown className="w-4 h-4 mr-2" />
                Client Portal
              </Link>
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden text-white p-2 hover:bg-slate-800/50 rounded-lg transition-colors duration-200"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Premium Mobile Menu */}
      {isMenuOpen && (
        <div className="lg:hidden bg-slate-950/98 backdrop-blur-xl border-t border-slate-800/50 absolute top-full left-0 right-0 shadow-2xl">
          <div className="px-6 py-8 max-h-screen overflow-y-auto">
            {/* Premium Badge */}
            <div className="flex items-center justify-center mb-8">
              <div className="bg-gradient-to-r from-blue-600/20 to-purple-600/20 border border-blue-500/30 rounded-full px-4 py-2">
                <div className="flex items-center space-x-2">
                  <Crown className="w-4 h-4 text-amber-400" />
                  <span className="text-blue-300 text-sm font-medium">Premium Gaming Infrastructure</span>
                </div>
              </div>
            </div>

            {/* Navigation */}
            <div className="space-y-2 mb-8">
              <Link
                href="/"
                className="block py-3 px-4 text-white text-lg font-semibold hover:bg-slate-800/50 rounded-lg transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Home
              </Link>
              <Link
                href="#pricing"
                className="block py-3 px-4 text-slate-300 text-lg hover:bg-slate-800/50 rounded-lg transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Pricing
              </Link>
              <Link
                href="/about"
                className="block py-3 px-4 text-slate-300 text-lg hover:bg-slate-800/50 rounded-lg transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                About
              </Link>
              <Link
                href="/contact"
                className="block py-3 px-4 text-slate-300 text-lg hover:bg-slate-800/50 rounded-lg transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Contact
              </Link>
            </div>

            {/* Services */}
            <div className="mb-8">
              <div className="flex items-center mb-4">
                <h3 className="text-slate-400 text-sm font-medium uppercase tracking-wider">Premium Services</h3>
                <div className="flex-1 h-px bg-gradient-to-r from-slate-800 to-transparent ml-4" />
              </div>

              <div className="grid gap-3">
                {services.map((service) => (
                  <Link
                    key={service.href}
                    href={service.href}
                    className="flex items-center space-x-4 p-4 rounded-xl bg-slate-900/50 border border-slate-800/50 hover:border-blue-500/30 hover:bg-slate-800/50 transition-all duration-200 group"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    <span className="text-2xl">{service.icon}</span>
                    <div className="flex-1">
                      <div className="text-white font-medium group-hover:text-blue-400 transition-colors">
                        {service.name}
                      </div>
                      <div className="text-slate-400 text-sm">{service.desc}</div>
                    </div>
                    <ChevronDown className="w-5 h-5 text-slate-400 rotate-[-90deg] group-hover:text-blue-400 transition-colors" />
                  </Link>
                ))}
              </div>
            </div>

            {/* Premium Login Button */}
            <div className="pt-6 border-t border-slate-800">
              <Button
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-medium py-4 text-lg shadow-lg"
                asChild
                onClick={() => setIsMenuOpen(false)}
              >
                <Link href="https://billing.avoxhosting.com/clientarea.php">
                  <Crown className="w-5 h-5 mr-2" />
                  Access Client Portal
                </Link>
              </Button>
            </div>

            {/* Status */}
            <div className="mt-6 pt-6 border-t border-slate-800">
              <div className="flex items-center justify-center space-x-2">
                <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
                <span className="text-emerald-400 text-sm font-medium">All Systems Operational</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  )
}
