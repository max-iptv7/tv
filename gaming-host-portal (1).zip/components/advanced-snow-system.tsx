"use client"

import { useEffect, useRef } from "react"

interface AdvancedSnowflake {
  x: number
  y: number
  size: number
  speed: number
  opacity: number
  drift: number
  rotation: number
  rotationSpeed: number
}

export function AdvancedSnowSystem() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const snowflakesRef = useRef<AdvancedSnowflake[]>([])
  const animationRef = useRef<number>()
  const windRef = useRef(0)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const resizeCanvas = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    resizeCanvas()
    window.addEventListener("resize", resizeCanvas)

    // Create advanced snowflake
    const createSnowflake = (): AdvancedSnowflake => ({
      x: Math.random() * canvas.width,
      y: -20,
      size: Math.random() * 3 + 1,
      speed: Math.random() * 2 + 1,
      opacity: Math.random() * 0.6 + 0.3,
      drift: Math.random() * 2 - 1,
      rotation: Math.random() * 360,
      rotationSpeed: Math.random() * 2 - 1,
    })

    // Initialize snowflakes
    for (let i = 0; i < 80; i++) {
      snowflakesRef.current.push({
        ...createSnowflake(),
        y: Math.random() * canvas.height,
      })
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Update wind effect
      windRef.current += 0.01
      const windForce = Math.sin(windRef.current) * 0.5

      snowflakesRef.current.forEach((snowflake, index) => {
        // Update position
        snowflake.y += snowflake.speed
        snowflake.x += snowflake.drift + windForce
        snowflake.rotation += snowflake.rotationSpeed

        // Wrap around screen
        if (snowflake.x > canvas.width + 10) snowflake.x = -10
        if (snowflake.x < -10) snowflake.x = canvas.width + 10

        // Reset if off screen
        if (snowflake.y > canvas.height + 10) {
          snowflakesRef.current[index] = createSnowflake()
        }

        // Draw snowflake
        ctx.save()
        ctx.translate(snowflake.x, snowflake.y)
        ctx.rotate((snowflake.rotation * Math.PI) / 180)
        ctx.globalAlpha = snowflake.opacity

        // Draw as a star shape
        ctx.fillStyle = "#ffffff"
        ctx.beginPath()
        for (let i = 0; i < 6; i++) {
          const angle = (i * Math.PI) / 3
          const x = Math.cos(angle) * snowflake.size
          const y = Math.sin(angle) * snowflake.size
          if (i === 0) ctx.moveTo(x, y)
          else ctx.lineTo(x, y)
        }
        ctx.closePath()
        ctx.fill()

        // Add glow effect for larger snowflakes
        if (snowflake.size > 2) {
          ctx.shadowColor = "#ffffff"
          ctx.shadowBlur = 10
          ctx.fill()
        }

        ctx.restore()
      })

      animationRef.current = requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener("resize", resizeCanvas)
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [])

  return <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none z-10 opacity-70" />
}
