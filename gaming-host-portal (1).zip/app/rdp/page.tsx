import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, Monitor, Shield, Zap, HardDrive } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import Link from "next/link"

export default function RDPPage() {
  const plans = [
    {
      name: "RDP Starter",
      ram: "2 GB",
      cpu: "1 vCPU",
      storage: "30 GB SSD",
      os: "Windows Server 2019",
      price: "€12.99",
      popular: false,
      productId: "71",
      features: ["Windows Server", "Remote Desktop", "24/7 Access", "DDoS Protection", "24/7 Support", "Admin Access"],
    },
    {
      name: "RDP Basic",
      ram: "4 GB",
      cpu: "2 vCPU",
      storage: "60 GB SSD",
      os: "Windows Server 2019/2022",
      price: "€19.99",
      popular: false,
      productId: "72",
      features: [
        "Windows Server",
        "Remote Desktop",
        "24/7 Access",
        "DDoS Protection",
        "24/7 Support",
        "Admin Access",
        "Multiple Users",
      ],
    },
    {
      name: "RDP Standard",
      ram: "8 GB",
      cpu: "4 vCPU",
      storage: "120 GB SSD",
      os: "Windows Server 2019/2022",
      price: "€34.99",
      popular: true,
      productId: "73",
      features: [
        "Windows Server",
        "Remote Desktop",
        "24/7 Access",
        "DDoS Protection",
        "24/7 Support",
        "Admin Access",
        "Multiple Users",
        "Priority Support",
      ],
    },
    {
      name: "RDP Advanced",
      ram: "16 GB",
      cpu: "6 vCPU",
      storage: "240 GB SSD",
      os: "Windows Server 2019/2022",
      price: "€54.99",
      popular: false,
      productId: "74",
      features: [
        "Windows Server",
        "Remote Desktop",
        "24/7 Access",
        "DDoS Protection",
        "24/7 Support",
        "Admin Access",
        "Multiple Users",
        "Priority Support",
        "Dedicated IP",
      ],
    },
    {
      name: "RDP Professional",
      ram: "32 GB",
      cpu: "8 vCPU",
      storage: "480 GB SSD",
      os: "Windows Server 2019/2022",
      price: "€84.99",
      popular: false,
      productId: "75",
      features: [
        "Windows Server",
        "Remote Desktop",
        "24/7 Access",
        "DDoS Protection",
        "24/7 Support",
        "Admin Access",
        "Multiple Users",
        "Priority Support",
        "Dedicated IP",
        "Custom Software",
      ],
    },
    {
      name: "RDP Enterprise",
      ram: "64 GB",
      cpu: "12 vCPU",
      storage: "960 GB SSD",
      os: "Windows Server 2019/2022",
      price: "€149.99",
      popular: false,
      productId: "76",
      features: [
        "Windows Server",
        "Remote Desktop",
        "24/7 Access",
        "DDoS Protection",
        "Dedicated Support",
        "Admin Access",
        "Multiple Users",
        "Custom Software",
        "Dedicated IP",
        "Managed Service",
        "GPU Available",
      ],
    },
  ]

  const features = [
    {
      icon: <Monitor className="w-6 h-6 sm:w-8 sm:h-8 text-teal-400" />,
      title: "Windows Server",
      description: "Latest Windows Server editions with full administrative access and remote desktop capabilities.",
    },
    {
      icon: <HardDrive className="w-6 h-6 sm:w-8 sm:h-8 text-green-400" />,
      title: "High Performance",
      description: "Fast SSD storage and powerful processors for smooth remote desktop experience and applications.",
    },
    {
      icon: <Shield className="w-6 h-6 sm:w-8 sm:h-8 text-red-400" />,
      title: "Secure Access",
      description: "Encrypted remote desktop connections with advanced security features and DDoS protection.",
    },
    {
      icon: <Zap className="w-6 h-6 sm:w-8 sm:h-8 text-yellow-400" />,
      title: "24/7 Availability",
      description: "Access your remote desktop server anytime, anywhere with guaranteed 99.9% uptime.",
    },
  ]

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <Header />

      <main className="pt-16">
        {/* Hero Section */}
        <section className="py-12 sm:py-20 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12 sm:mb-16">
              <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-blue-500 to-purple-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Monitor className="w-8 h-8 sm:w-10 sm:h-10 text-white" />
              </div>
              <h1 className="text-3xl sm:text-4xl lg:text-6xl font-bold mb-6">
                RDP <span className="text-teal-400">Server Hosting</span>
              </h1>
              <p className="text-base sm:text-xl text-slate-300 max-w-4xl mx-auto leading-relaxed px-4">
                Windows Remote Desktop servers for development, business applications, and remote work. Get full
                administrative access to Windows Server with high-performance hardware, SSD storage, and 24/7
                availability. Perfect for running Windows applications, development environments, and business software.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 max-w-6xl mx-auto">
              {features.map((feature, index) => (
                <Card
                  key={index}
                  className="bg-slate-900/50 border-slate-800 hover:border-teal-500/50 transition-all duration-300"
                >
                  <CardHeader className="text-center p-4 sm:p-6">
                    <div className="mb-3 sm:mb-4">{feature.icon}</div>
                    <CardTitle className="text-white text-base sm:text-lg">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="p-4 sm:p-6 pt-0">
                    <p className="text-slate-300 text-sm text-center">{feature.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Pricing Section */}
        <section className="py-12 sm:py-20">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12 sm:mb-16">
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold mb-4">RDP Server Plans</h2>
              <div className="w-24 h-1 bg-teal-500 mx-auto mb-6"></div>
              <p className="text-base sm:text-xl text-slate-300 max-w-3xl mx-auto px-4">
                Choose the perfect RDP server plan for your needs. All plans include Windows Server, admin access, and
                24/7 support.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
              {plans.map((plan, index) => (
                <Card
                  key={index}
                  className={`relative bg-slate-900/50 border-slate-800 hover:border-slate-700 transition-all duration-300 ${
                    plan.popular ? "ring-2 ring-teal-500 scale-105" : ""
                  }`}
                >
                  {plan.popular && (
                    <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-teal-600 text-white text-xs sm:text-sm">
                      Most Popular
                    </Badge>
                  )}

                  <CardHeader className="text-center p-4 sm:p-6">
                    <CardTitle className="text-white text-lg sm:text-xl">{plan.name}</CardTitle>
                    <div className="text-2xl sm:text-3xl font-bold text-white mt-4">
                      {plan.price}
                      <span className="text-slate-400 text-base sm:text-lg font-normal">/month</span>
                    </div>
                    <p className="text-teal-400 font-semibold text-xs sm:text-sm">{plan.os}</p>
                  </CardHeader>

                  <CardContent className="space-y-4 p-4 sm:p-6">
                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div>
                        <p className="text-slate-400 text-xs">RAM</p>
                        <p className="text-white font-semibold text-xs sm:text-sm">{plan.ram}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-xs">CPU</p>
                        <p className="text-white font-semibold text-xs sm:text-sm">{plan.cpu}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-xs">Storage</p>
                        <p className="text-white font-semibold text-xs sm:text-sm">{plan.storage}</p>
                      </div>
                    </div>

                    <div className="space-y-2 pt-4">
                      {plan.features.map((feature, featureIndex) => (
                        <div key={featureIndex} className="flex items-center space-x-2">
                          <Check className="w-3 h-3 sm:w-4 sm:h-4 text-green-400 flex-shrink-0" />
                          <span className="text-slate-300 text-xs sm:text-sm">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>

                  <CardFooter className="p-4 sm:p-6">
                    <Button className="w-full bg-teal-600 hover:bg-teal-700 py-3 text-sm sm:text-base" asChild>
                      <Link href={`https://billing.avoxhosting.com/cart.php?a=add&pid=${plan.productId}`}>
                        Order Now
                      </Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
